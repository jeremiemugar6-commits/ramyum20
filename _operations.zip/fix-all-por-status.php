<?php
/**
 * Fix All POR Status Records
 * Updates all POR records to have correct status based on receiving results
 */

require_once __DIR__ . '/config/database.php';

$db = getDB();

echo "<html><head><title>Fix All POR Status</title>";
echo "<style>
    body { font-family: Arial, sans-serif; max-width: 1200px; margin: 50px auto; padding: 20px; background: #f5f5f5; }
    table { width: 100%; border-collapse: collapse; background: white; margin: 20px 0; }
    th, td { padding: 12px; text-align: left; border: 1px solid #ddd; }
    th { background: #3B82F6; color: white; font-weight: 600; }
    .pending { background: #FEF3C7; color: #92400E; padding: 4px 8px; border-radius: 4px; }
    .passed { background: #D1FAE5; color: #065F46; padding: 4px 8px; border-radius: 4px; }
    .failed { background: #FEE2E2; color: #991B1B; padding: 4px 8px; border-radius: 4px; }
    .partial { background: #DBEAFE; color: #1E40AF; padding: 4px 8px; border-radius: 4px; }
    .info { background: #DBEAFE; padding: 15px; border-left: 4px solid #3B82F6; margin: 20px 0; }
    .success { background: #D1FAE5; padding: 15px; border-left: 4px solid #10B981; margin: 20px 0; }
    .warning { background: #FEF3C7; padding: 15px; border-left: 4px solid #F59E0B; margin: 20px 0; }
    .btn { padding: 12px 24px; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 1rem; text-decoration: none; display: inline-block; }
    .btn-primary { background: #10B981; color: white; }
    .btn-secondary { background: #6B7280; color: white; }
</style></head><body>";

echo "<h1>🔧 Fix All POR Status Records</h1>";

try {
    // Get all POR records with their items
    $stmt = $db->query("
        SELECT 
            por.id,
            por.por_number,
            por.po_number,
            por.supplier_name,
            por.inspection_status as current_status,
            por.received_by_name,
            por.receiving_date
        FROM proof_of_receiving por
        WHERE por.inspection_status != 'Archived'
        ORDER BY por.created_at DESC
    ");
    
    $allPORs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($allPORs)) {
        echo "<div class='warning'><strong>⚠️ No POR records found!</strong></div>";
        echo "</body></html>";
        exit;
    }
    
    echo "<div class='info'><strong>📋 Found {count($allPORs)} POR records to check</strong></div>";
    
    // Analyze each POR
    $needsUpdate = [];
    
    foreach ($allPORs as $por) {
        // Get items for this POR
        $stmt = $db->prepare("
            SELECT 
                SUM(ordered_quantity) as total_ordered,
                SUM(received_quantity) as total_received,
                SUM(accepted_quantity) as total_accepted,
                SUM(rejected_quantity) as total_rejected
            FROM proof_of_receiving_items
            WHERE por_id = ?
        ");
        $stmt->execute([$por['id']]);
        $totals = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $totalOrdered = (int)$totals['total_ordered'];
        $totalReceived = (int)$totals['total_received'];
        $totalAccepted = (int)$totals['total_accepted'];
        $totalRejected = (int)$totals['total_rejected'];
        
        // Calculate correct status
        $correctStatus = 'Pending';
        
        if ($totalRejected > 0) {
            $correctStatus = 'Failed';
        } elseif ($totalAccepted > 0 && $totalRejected == 0) {
            if ($totalAccepted == $totalReceived) {
                $correctStatus = 'Passed';
            } else {
                $correctStatus = 'Partial';
            }
        }
        
        // Check if needs update
        if ($correctStatus !== $por['current_status']) {
            $needsUpdate[] = [
                'id' => $por['id'],
                'por_number' => $por['por_number'],
                'po_number' => $por['po_number'],
                'supplier_name' => $por['supplier_name'],
                'current_status' => $por['current_status'],
                'correct_status' => $correctStatus,
                'total_ordered' => $totalOrdered,
                'total_received' => $totalReceived,
                'total_accepted' => $totalAccepted,
                'total_rejected' => $totalRejected,
                'received_by' => $por['received_by_name'],
                'receiving_date' => $por['receiving_date']
            ];
        }
    }
    
    if (empty($needsUpdate)) {
        echo "<div class='success'>";
        echo "<h3>✅ All POR Status Records are Correct!</h3>";
        echo "<p>All {count($allPORs)} POR records have the correct status based on their receiving results.</p>";
        echo "</div>";
    } else {
        echo "<div class='warning'>";
        echo "<h3>⚠️ Found " . count($needsUpdate) . " POR records with incorrect status</h3>";
        echo "</div>";
        
        echo "<h2>Records That Need Updates:</h2>";
        echo "<table>";
        echo "<tr>";
        echo "<th>POR #</th>";
        echo "<th>PO #</th>";
        echo "<th>Supplier</th>";
        echo "<th>Received</th>";
        echo "<th>Accepted</th>";
        echo "<th>Rejected</th>";
        echo "<th>Current Status</th>";
        echo "<th>Should Be</th>";
        echo "</tr>";
        
        foreach ($needsUpdate as $por) {
            $currentClass = strtolower($por['current_status']);
            $correctClass = strtolower($por['correct_status']);
            
            echo "<tr>";
            echo "<td><strong>{$por['por_number']}</strong></td>";
            echo "<td>{$por['po_number']}</td>";
            echo "<td>{$por['supplier_name']}</td>";
            echo "<td>{$por['total_received']}</td>";
            echo "<td style='color:#10B981; font-weight:600;'>{$por['total_accepted']}</td>";
            echo "<td style='color:#EF4444; font-weight:600;'>{$por['total_rejected']}</td>";
            echo "<td><span class='{$currentClass}'>{$por['current_status']}</span></td>";
            echo "<td><span class='{$correctClass}'><strong>{$por['correct_status']}</strong></span></td>";
            echo "</tr>";
        }
        
        echo "</table>";
        
        // Show fix button
        echo "<form method='POST' style='margin: 30px 0;'>";
        echo "<input type='hidden' name='fix_all' value='yes'>";
        echo "<button type='submit' class='btn btn-primary'>";
        echo "✓ Fix All " . count($needsUpdate) . " POR Status Records";
        echo "</button>";
        echo " ";
        echo "<a href='dashboard.php' class='btn btn-secondary'>Cancel</a>";
        echo "</form>";
    }
    
    // Handle fix request
    if ($_POST['fix_all'] ?? false) {
        echo "<div class='info'><h3>🔄 Updating POR Status Records...</h3></div>";
        
        $updated = 0;
        $errors = 0;
        
        $db->beginTransaction();
        
        try {
            foreach ($needsUpdate as $por) {
                $stmt = $db->prepare("
                    UPDATE proof_of_receiving 
                    SET inspection_status = ? 
                    WHERE id = ?
                ");
                
                if ($stmt->execute([$por['correct_status'], $por['id']])) {
                    $updated++;
                    echo "<div style='padding:8px; background:#D1FAE5; margin:4px 0;'>";
                    echo "✓ Updated {$por['por_number']}: {$por['current_status']} → <strong>{$por['correct_status']}</strong>";
                    echo "</div>";
                } else {
                    $errors++;
                    echo "<div style='padding:8px; background:#FEE2E2; margin:4px 0;'>";
                    echo "✗ Failed to update {$por['por_number']}";
                    echo "</div>";
                }
            }
            
            $db->commit();
            
            echo "<div class='success'>";
            echo "<h3>✅ Update Complete!</h3>";
            echo "<p><strong>{$updated}</strong> POR records updated successfully</p>";
            if ($errors > 0) {
                echo "<p style='color:#EF4444;'><strong>{$errors}</strong> errors occurred</p>";
            }
            echo "<p><a href='check-por-status.php' style='color:#3B82F6; font-weight:600;'>↻ Check Status Again</a></p>";
            echo "<p><a href='dashboard.php' class='btn btn-primary' style='margin-top:10px;'>→ Go to Dashboard</a></p>";
            echo "</div>";
            
        } catch (Exception $e) {
            $db->rollBack();
            echo "<div style='background:#FEE2E2; padding:20px; border-left:4px solid #EF4444; margin:20px 0;'>";
            echo "<strong>❌ Error:</strong> {$e->getMessage()}";
            echo "</div>";
        }
    }
    
} catch (Exception $e) {
    echo "<div style='background:#FEE2E2; padding:20px; border-left:4px solid #EF4444; margin:20px 0;'>";
    echo "<strong>❌ Error:</strong> {$e->getMessage()}";
    echo "</div>";
}

echo "<p style='margin-top:30px;'>";
echo "<a href='dashboard.php' class='btn btn-secondary'>← Back to Dashboard</a>";
echo "</p>";

echo "</body></html>";
?>
