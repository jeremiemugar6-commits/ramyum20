<?php
/**
 * Execute Audit Trail SQL - Quick Loader
 * Loads the comprehensive audit trail data you provided
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';

$currentUser = require_login_page();

echo "<!DOCTYPE html><html><head><title>Execute Audit Trail</title>";
echo "<style>body{font-family:system-ui;margin:40px;}.success{color:green;}.error{color:red;}.info{color:blue;}</style></head><body>";

echo "<h1>📊 Executing Audit Trail Data</h1>";

try {
    $db = getDB();
    $db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
    
    // First ensure the audit table exists
    $createAuditTable = "
    CREATE TABLE IF NOT EXISTS stock_transfer_audit (
        id            VARCHAR(40) PRIMARY KEY,
        transfer_id   VARCHAR(100) NOT NULL,
        action        VARCHAR(50) NOT NULL,
        performed_by  VARCHAR(40) NOT NULL,
        performed_by_name VARCHAR(255) NOT NULL,
        details       TEXT,
        created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_transfer_id (transfer_id),
        INDEX idx_action (action),
        INDEX idx_performed_by (performed_by),
        INDEX idx_created_at (created_at)
    ) ENGINE=InnoDB";
    
    $db->exec($createAuditTable);
    echo "<p class='success'>✅ Audit table ready</p>";
    
    // Clear existing demo audit entries
    $db->exec("DELETE FROM stock_transfer_audit WHERE transfer_id LIKE 'ST-2026-01%'");
    echo "<p class='info'>🧹 Cleared existing demo audit entries</p>";
    
    // The exact SQL from your request
    $auditSQL = "
    INSERT INTO stock_transfer_audit (id, transfer_id, action, performed_by, performed_by_name, details, created_at) VALUES
    -- ST-2026-0101: Urgent restock scenario audit trail
    ('audit_001', 'ST-2026-0101', 'CREATED', 'u2', 'Staff User', 'Transfer created for urgent Branch 1 restock', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%d %H:%i:%s')),
    ('audit_002', 'ST-2026-0101', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for manager approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%d %H:%i:%s')),
    
    -- ST-2026-0102: New product launch scenario audit trail  
    ('audit_003', 'ST-2026-0102', 'CREATED', 'u3', 'Manager User', 'Transfer created for new product distribution', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%d %H:%i:%s')),
    ('audit_004', 'ST-2026-0102', 'SUBMITTED', 'u3', 'Manager User', 'Transfer submitted for admin approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%d %H:%i:%s')),
    
    -- ST-2026-0103: Completed transfer scenario audit trail
    ('audit_005', 'ST-2026-0103', 'CREATED', 'u2', 'Staff User', 'Transfer created for inventory optimization', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%d %H:%i:%s')),
    ('audit_006', 'ST-2026-0103', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 22 HOUR), '%Y-%m-%d %H:%i:%s')),
    ('audit_007', 'ST-2026-0103', 'APPROVED', 'u1', 'Admin User', 'Transfer approved for execution', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 6 HOUR), '%Y-%m-%d %H:%i:%s')),
    ('audit_008', 'ST-2026-0103', 'COMPLETED', 'u2', 'Staff User', 'Inventory transfer completed successfully', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%d %H:%i:%s')),
    
    -- ST-2026-0104: Rejected transfer scenario audit trail
    ('audit_009', 'ST-2026-0104', 'CREATED', 'u2', 'Staff User', 'Transfer created for special customer order', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%d %H:%i:%s')),
    ('audit_010', 'ST-2026-0104', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for manager review', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 46 HOUR), '%Y-%m-%d %H:%i:%s')),
    ('audit_011', 'ST-2026-0104', 'REJECTED', 'u3', 'Manager User', 'Transfer rejected due to insufficient source inventory', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%d %H:%i:%s')),
    
    -- ST-2026-0105: Emergency transfer scenario audit trail
    ('audit_012', 'ST-2026-0105', 'CREATED', 'u3', 'Manager User', 'Emergency transfer created for stockout situation', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 HOUR), '%Y-%m-%d %H:%i:%s')),
    ('audit_013', 'ST-2026-0105', 'SUBMITTED', 'u3', 'Manager User', 'Emergency transfer submitted for immediate approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 HOUR), '%Y-%m-%d %H:%i:%s')),
    ('audit_014', 'ST-2026-0105', 'APPROVED', 'u1', 'Admin User', 'Emergency transfer approved with fast-track priority', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%d %H:%i:%s'))
    ";
    
    // Execute the audit trail insertion
    $db->exec($auditSQL);
    echo "<p class='success'>🎯 <strong>SUCCESS!</strong> All 14 audit trail entries created</p>";
    
    // Verification
    echo "<h2>📋 Verification Results</h2>";
    
    // Count total audit entries
    $stmt = $db->query("SELECT COUNT(*) as count FROM stock_transfer_audit");
    $totalCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    echo "<p class='success'>✅ Total audit entries: <strong>$totalCount</strong></p>";
    
    // Count by action type
    echo "<h3>Audit Actions Summary:</h3>";
    $stmt = $db->query("
        SELECT action, COUNT(*) as count 
        FROM stock_transfer_audit 
        WHERE transfer_id LIKE 'ST-2026-01%'
        GROUP BY action 
        ORDER BY action
    ");
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<p>• <strong>{$row['action']}</strong>: {$row['count']} entries</p>";
    }
    
    // Show workflow by transfer
    echo "<h3>🔄 Workflow by Transfer:</h3>";
    $stmt = $db->query("
        SELECT 
            transfer_id,
            COUNT(*) as steps,
            GROUP_CONCAT(action ORDER BY created_at SEPARATOR ' → ') as workflow
        FROM stock_transfer_audit 
        WHERE transfer_id LIKE 'ST-2026-01%'
        GROUP BY transfer_id 
        ORDER BY transfer_id
    ");
    
    echo "<div style='background:#f9fafb;padding:16px;border-radius:8px;margin:16px 0;'>";
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<p><strong>{$row['transfer_id']}</strong> ({$row['steps']} steps): {$row['workflow']}</p>";
    }
    echo "</div>";
    
    echo "<h2>🎉 Audit Trail Setup Complete!</h2>";
    echo "<p>Your Stock Transfer demo now has comprehensive audit trail data showing:</p>";
    echo "<ul>";
    echo "<li>🚨 <strong>ST-2026-0101</strong>: Urgent restock (CREATED → SUBMITTED)</li>";
    echo "<li>🚀 <strong>ST-2026-0102</strong>: Product launch (CREATED → SUBMITTED)</li>";
    echo "<li>✅ <strong>ST-2026-0103</strong>: Completed transfer (CREATED → SUBMITTED → APPROVED → COMPLETED)</li>";
    echo "<li>❌ <strong>ST-2026-0104</strong>: Rejected transfer (CREATED → SUBMITTED → REJECTED)</li>";
    echo "<li>⚡ <strong>ST-2026-0105</strong>: Emergency approved (CREATED → SUBMITTED → APPROVED)</li>";
    echo "</ul>";
    
    echo "<div style='text-align:center;margin:30px 0;'>";
    echo "<a href='dashboard.php' style='background:#10b981;color:white;padding:12px 24px;text-decoration:none;border-radius:6px;margin-right:10px;'>📊 View in Dashboard</a>";
    echo "<a href='test-stock-transfer-scenarios.php' style='background:#3b82f6;color:white;padding:12px 24px;text-decoration:none;border-radius:6px;'>🎭 Demo Interface</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ <strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>Please check your database connection and try again.</p>";
}

echo "</body></html>";
?>