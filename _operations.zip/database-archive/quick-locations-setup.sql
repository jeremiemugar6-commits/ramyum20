-- =====================================================================
-- Quick Locations Setup for Stock Transfer Module
-- Run this directly in MySQL/phpMyAdmin to fix the locations issue
-- =====================================================================

USE ramyum_db;

-- Create locations table
CREATE TABLE IF NOT EXISTS locations (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Insert the 4 required locations
INSERT INTO locations (id, data) VALUES
('loc1', JSON_OBJECT(
    'id', 'loc1',
    'name', 'Main Warehouse',
    'code', 'WH',
    'type', 'Warehouse',
    'address', '123 Industrial Avenue, Manila',
    'manager', 'Juan dela Cruz',
    'phone', '+63 2 8555 0001',
    'email', 'warehouse@ramyum.com',
    'status', 'Active',
    'capacity', 2000,
    'description', 'Primary storage and distribution center'
)),
('loc2', JSON_OBJECT(
    'id', 'loc2',
    'name', 'Branch 1 - Makati',
    'code', 'MKT',
    'type', 'Branch',
    'address', '456 Ayala Avenue, Makati City',
    'manager', 'Maria Santos',
    'phone', '+63 2 8555 0002',
    'email', 'makati@ramyum.com',
    'status', 'Active',
    'capacity', 500,
    'description', 'Makati retail branch with premium location'
)),
('loc3', JSON_OBJECT(
    'id', 'loc3',
    'name', 'Branch 2 - Quezon City',
    'code', 'QC',
    'type', 'Branch',
    'address', '789 Commonwealth Avenue, Quezon City',
    'manager', 'Ana Rodriguez',
    'phone', '+63 2 8555 0003',
    'email', 'qc@ramyum.com',
    'status', 'Active',
    'capacity', 400,
    'description', 'Quezon City retail branch with cold storage'
)),
('loc4', JSON_OBJECT(
    'id', 'loc4',
    'name', 'Storage Area - BGC',
    'code', 'BGC',
    'type', 'Storage',
    'address', '321 Bonifacio Global City, Taguig',
    'manager', 'Roberto Kim',
    'phone', '+63 2 8555 0004',
    'email', 'bgc@ramyum.com',
    'status', 'Active',
    'capacity', 1500,
    'description', 'Secondary storage facility for overflow inventory'
))
ON DUPLICATE KEY UPDATE data = VALUES(data);

-- Create inventory_locations table
CREATE TABLE IF NOT EXISTS inventory_locations (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Create stock_transfer_audit table
CREATE TABLE IF NOT EXISTS stock_transfer_audit (
    id            VARCHAR(40) PRIMARY KEY,
    transfer_id   VARCHAR(100) NOT NULL,
    action        VARCHAR(50) NOT NULL,
    performed_by  VARCHAR(40) NOT NULL,
    performed_by_name VARCHAR(255) NOT NULL,
    details       TEXT,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_transfer_id (transfer_id),
    INDEX idx_action (action),
    INDEX idx_performed_by (performed_by),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- Add sample inventory data
INSERT INTO inventory_locations (id, data) VALUES
('inv_p1_loc1', JSON_OBJECT(
    'id', 'inv_p1_loc1',
    'productId', 'p1',
    'locationId', 'loc1',
    'quantity', 150,
    'reservedQuantity', 0,
    'availableQuantity', 150,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p1_loc2', JSON_OBJECT(
    'id', 'inv_p1_loc2',
    'productId', 'p1',
    'locationId', 'loc2',
    'quantity', 30,
    'reservedQuantity', 0,
    'availableQuantity', 30,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p2_loc1', JSON_OBJECT(
    'id', 'inv_p2_loc1',
    'productId', 'p2',
    'locationId', 'loc1',
    'quantity', 200,
    'reservedQuantity', 0,
    'availableQuantity', 200,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p2_loc2', JSON_OBJECT(
    'id', 'inv_p2_loc2',
    'productId', 'p2',
    'locationId', 'loc2',
    'quantity', 25,
    'reservedQuantity', 0,
    'availableQuantity', 25,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
))
ON DUPLICATE KEY UPDATE data = VALUES(data);

-- Verification queries
SELECT 'Setup Complete!' as status;
SELECT 'Locations Created:' as info, COUNT(*) as count FROM locations;
SELECT 'Sample Inventory:' as info, COUNT(*) as count FROM inventory_locations;

-- Show the locations that were created
SELECT 
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.name')) as location_name,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.type')) as type,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) as status
FROM locations 
ORDER BY JSON_UNQUOTE(JSON_EXTRACT(data, '$.name'));