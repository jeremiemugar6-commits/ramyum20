-- =====================================================================
-- Update Admin Email Address
-- This script updates the admin user's email address to jeremiemugar7@gmail.com
-- =====================================================================

USE ramyum_db;

-- Update the admin user's email address
UPDATE users 
SET email = 'jeremiemugar7@gmail.com', 
    updated_at = CURRENT_TIMESTAMP 
WHERE username = 'admin' AND role = 'admin';

-- Verify the update
SELECT id, name, email, username, role 
FROM users 
WHERE username = 'admin';