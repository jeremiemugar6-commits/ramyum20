-- =====================================================================
-- STEP 3: Add Sample Inventory Data
-- Run this third in phpMyAdmin
-- =====================================================================

USE ramyum_db;

-- Add sample inventory across locations
INSERT INTO inventory_locations (id, data) VALUES
('inv_p1_loc1', JSON_OBJECT(
    'id', 'inv_p1_loc1',
    'productId', 'p1',
    'locationId', 'loc1',
    'quantity', 150,
    'reservedQuantity', 0,
    'availableQuantity', 150,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p1_loc2', JSON_OBJECT(
    'id', 'inv_p1_loc2',
    'productId', 'p1',
    'locationId', 'loc2',
    'quantity', 30,
    'reservedQuantity', 0,
    'availableQuantity', 30,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p2_loc1', JSON_OBJECT(
    'id', 'inv_p2_loc1',
    'productId', 'p2',
    'locationId', 'loc1',
    'quantity', 200,
    'reservedQuantity', 0,
    'availableQuantity', 200,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p2_loc2', JSON_OBJECT(
    'id', 'inv_p2_loc2',
    'productId', 'p2',
    'locationId', 'loc2',
    'quantity', 25,
    'reservedQuantity', 0,
    'availableQuantity', 25,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p3_loc1', JSON_OBJECT(
    'id', 'inv_p3_loc1',
    'productId', 'p3',
    'locationId', 'loc1',
    'quantity', 100,
    'reservedQuantity', 0,
    'availableQuantity', 100,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('inv_p4_loc1', JSON_OBJECT(
    'id', 'inv_p4_loc1',
    'productId', 'p4',
    'locationId', 'loc1',
    'quantity', 120,
    'reservedQuantity', 0,
    'availableQuantity', 120,
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
))
ON DUPLICATE KEY UPDATE data = VALUES(data);

-- Verify inventory was added
SELECT 'Step 3 Complete: Inventory Added' as status;
SELECT COUNT(*) as inventory_count FROM inventory_locations;