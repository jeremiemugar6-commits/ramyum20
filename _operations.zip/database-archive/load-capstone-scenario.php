<?php
/**
 * Capstone Demo Scenario Loader for RAM-YUM Pre-Oral Defense
 * This script loads the exact demonstration scenario for the capstone presentation
 */

require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');

// Check if demo mode is active
if (!DEMO_INTEGRATION_MODE) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'error' => 'Demo scenario can only be loaded when DEMO_INTEGRATION_MODE is enabled'
    ]);
    exit;
}

try {
    $db = getDB();
    
    // Read the capstone demo scenario SQL file
    $sqlFile = __DIR__ . '/capstone-demo-scenario.sql';
    if (!file_exists($sqlFile)) {
        throw new Exception('Capstone demo scenario SQL file not found');
    }
    
    $sql = file_get_contents($sqlFile);
    
    // Remove comments and split into individual statements
    $statements = array_filter(
        array_map('trim', explode(';', $sql)),
        function($stmt) {
            return !empty($stmt) && 
                   !str_starts_with($stmt, '--') && 
                   !str_starts_with($stmt, '/*') &&
                   !str_starts_with($stmt, 'SELECT') && // Skip verification queries for this loader
                   !str_starts_with($stmt, 'USE');
        }
    );
    
    $db->beginTransaction();
    
    $executed = 0;
    foreach ($statements as $statement) {
        if (trim($statement)) {
            $db->exec($statement);
            $executed++;
        }
    }
    
    $db->commit();
    
    // Get verification data
    $poCount = $db->query("SELECT COUNT(*) as count FROM purchase_orders WHERE id LIKE 'demo_po_%'")->fetch()['count'];
    $grCount = $db->query("SELECT COUNT(*) as count FROM receivings WHERE id LIKE 'demo_gr_%'")->fetch()['count'];
    $movementCount = $db->query("SELECT COUNT(*) as count FROM inventory_movements WHERE id LIKE 'demo_mov_%'")->fetch()['count'];
    
    // Get the main demo PO details
    $mainPO = $db->query("SELECT data FROM purchase_orders WHERE id = 'demo_po_001'")->fetch();
    $poData = $mainPO ? json_decode($mainPO['data'], true) : null;
    
    echo json_encode([
        'success' => true,
        'message' => 'Capstone demo scenario loaded successfully',
        'data' => [
            'statements_executed' => $executed,
            'demo_pos_created' => $poCount,
            'demo_receivings_created' => $grCount,
            'demo_movements_created' => $movementCount,
            'main_demo_po' => $poData ? [
                'poNumber' => $poData['poNumber'],
                'supplier' => $poData['supplier'],
                'status' => $poData['status'],
                'total' => $poData['total'],
                'items_count' => count($poData['items']),
                'total_items' => $poData['totalItems']
            ] : null,
            'demo_mode' => DEMO_INTEGRATION_MODE ? 'ACTIVE' : 'INACTIVE'
        ],
        'instructions' => [
            '1. Login as Admin to access all features',
            '2. Navigate to Purchase Orders to see PO-2026-0001 (Approved status)',
            '3. Navigate to Receiving to process the delivery',
            '4. Use Receiving module to demonstrate partial and full receiving',
            '5. Check Inventory to see stock updates and movements',
            '6. Show Reports with transaction history',
            '7. Demonstrate the complete workflow to panelists'
        ]
    ]);
    
} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to load capstone demo scenario: ' . $e->getMessage()
    ]);
}