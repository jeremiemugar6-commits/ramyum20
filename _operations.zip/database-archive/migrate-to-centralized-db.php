<?php
/**
 * Database Migration Script - Web Interface
 * Migrates from ramyum_db to ram_yum_inventory centralized database
 * 
 * IMPORTANT: Create a backup of your database before running this!
 * Command: mysqldump -u root -p ramyum_db > ramyum_db_backup.sql
 */

ini_set('display_errors', 1);
ini_set('error_reporting', E_ALL);
set_time_limit(300); // 5 minutes timeout

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Migration - RAMYUM</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }
        .container { background: #f9f9f9; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .success { background: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .warning { background: #fff3cd; color: #856404; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .info { background: #d1ecf1; color: #0c5460; padding: 10px; border-radius: 4px; margin: 10px 0; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 4px; overflow-x: auto; }
        .btn { background: #FF7A00; color: white; padding: 12px 24px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        .btn:hover { background: #e06600; }
        .btn-danger { background: #dc3545; }
        .btn-danger:hover { background: #c82333; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .step { margin: 20px 0; padding: 15px; border-left: 4px solid #FF7A00; }
    </style>
</head>
<body>
    <h1>🗃️ Database Migration Tool</h1>
    <h2>ramyum_db → ram_yum_inventory</h2>

    <div class="warning">
        <strong>⚠️ BACKUP WARNING:</strong> This migration will create a new database and migrate data. 
        Ensure you have backed up your current database before proceeding!
        <br><br>
        <strong>Backup command:</strong>
        <pre>mysqldump -u root -p ramyum_db > ramyum_db_backup_$(date +%Y%m%d_%H%M%S).sql</pre>
    </div>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'migrate') {
        performMigration();
    } elseif (isset($_POST['action']) && $_POST['action'] === 'check') {
        checkCurrentState();
    }
} else {
    showMigrationForm();
}

function showMigrationForm() {
    ?>
    <div class="container">
        <h3>Migration Steps</h3>
        <div class="step">
            <strong>Step 1:</strong> Check current database state
            <form method="post" style="margin-top: 10px;">
                <input type="hidden" name="action" value="check">
                <button type="submit" class="btn">🔍 Check Current State</button>
            </form>
        </div>
        
        <div class="step">
            <strong>Step 2:</strong> Perform migration (after backup!)
            <form method="post" style="margin-top: 10px;">
                <input type="hidden" name="action" value="migrate">
                <label>
                    <input type="checkbox" name="confirm" required> 
                    I have created a backup of my database
                </label><br><br>
                <button type="submit" class="btn btn-danger">🚀 Migrate to Centralized Database</button>
            </form>
        </div>
    </div>
    <?php
}

function checkCurrentState() {
    echo "<h3>🔍 Current Database State</h3>";
    
    try {
        // Check ramyum_db
        echo "<div class='container'>";
        echo "<h4>Existing Database: ramyum_db</h4>";
        
        $oldPdo = new PDO("mysql:host=localhost;dbname=ramyum_db", "root", "", [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
        
        $tables = $oldPdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        echo "<div class='success'>✅ ramyum_db exists with " . count($tables) . " tables</div>";
        
        echo "<h5>Tables in ramyum_db:</h5>";
        echo "<ul>";
        foreach ($tables as $table) {
            $count = $oldPdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
            echo "<li><strong>$table</strong>: $count records</li>";
        }
        echo "</ul>";
        
        // Check audit table structure
        if (in_array('stock_transfer_audit', $tables)) {
            echo "<h5>Stock Transfer Audit Table Structure:</h5>";
            $columns = $oldPdo->query("SHOW COLUMNS FROM stock_transfer_audit")->fetchAll();
            echo "<table><tr><th>Field</th><th>Type</th><th>Key</th></tr>";
            foreach ($columns as $col) {
                echo "<tr><td>{$col['Field']}</td><td>{$col['Type']}</td><td>{$col['Key']}</td></tr>";
            }
            echo "</table>";
            
            $hasOldStructure = $oldPdo->query("SHOW COLUMNS FROM stock_transfer_audit LIKE 'action'")->fetch();
            if ($hasOldStructure) {
                echo "<div class='warning'>⚠️ Audit table has OLD structure - will be converted during migration</div>";
            } else {
                echo "<div class='success'>✅ Audit table already has correct structure</div>";
            }
        }
        
        echo "</div>";
        
        // Check if new database exists
        echo "<div class='container'>";
        echo "<h4>Target Database: ram_yum_inventory</h4>";
        
        try {
            $newPdo = new PDO("mysql:host=localhost;dbname=ram_yum_inventory", "root", "", [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]);
            
            $newTables = $newPdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
            echo "<div class='info'>ℹ️ ram_yum_inventory already exists with " . count($newTables) . " tables</div>";
            echo "<div class='warning'>⚠️ Migration will preserve existing data and add missing records</div>";
            
        } catch (PDOException $e) {
            echo "<div class='info'>ℹ️ ram_yum_inventory does not exist - will be created during migration</div>";
        }
        echo "</div>";
        
    } catch (PDOException $e) {
        echo "<div class='error'>❌ Error checking ramyum_db: " . $e->getMessage() . "</div>";
        echo "<div class='info'>ℹ️ If ramyum_db doesn't exist, migration will create ram_yum_inventory with default data</div>";
    }
    
    showMigrationForm();
}

function performMigration() {
    echo "<h3>🚀 Performing Database Migration</h3>";
    
    if (!isset($_POST['confirm'])) {
        echo "<div class='error'>❌ Backup confirmation required!</div>";
        showMigrationForm();
        return;
    }
    
    try {
        // Read the migration SQL
        $migrationSQL = file_get_contents(__DIR__ . '/database/migrate-to-centralized.sql');
        if (!$migrationSQL) {
            throw new Exception("Migration SQL file not found!");
        }
        
        echo "<div class='step'>";
        echo "<h4>Step 1: Creating new database structure...</h4>";
        
        // Connect to MySQL (no database selected)
        $pdo = new PDO("mysql:host=localhost", "root", "", [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
        
        // Execute migration
        $statements = preg_split('/;\s*$/m', $migrationSQL);
        $executedStatements = 0;
        $errors = 0;
        
        foreach ($statements as $statement) {
            $statement = trim($statement);
            if (empty($statement) || strpos($statement, '--') === 0) {
                continue;
            }
            
            try {
                $pdo->exec($statement);
                $executedStatements++;
                
                // Show progress for key operations
                if (stripos($statement, 'CREATE DATABASE') !== false) {
                    echo "<div class='success'>✅ Created ram_yum_inventory database</div>";
                } elseif (stripos($statement, 'CREATE TABLE') !== false) {
                    preg_match('/CREATE TABLE[^`]*`([^`]+)`/', $statement, $matches);
                    $tableName = $matches[1] ?? 'unknown';
                    echo "<div class='success'>✅ Created table: $tableName</div>";
                } elseif (stripos($statement, 'INSERT') !== false && stripos($statement, 'users') !== false) {
                    echo "<div class='success'>✅ Migrated user data</div>";
                } elseif (stripos($statement, 'INSERT') !== false && stripos($statement, 'products') !== false) {
                    echo "<div class='success'>✅ Migrated product data</div>";
                } elseif (stripos($statement, 'INSERT') !== false && stripos($statement, 'stock_transfer_audit') !== false) {
                    echo "<div class='success'>✅ Migrated and converted audit data</div>";
                }
            } catch (PDOException $e) {
                $errors++;
                if (stripos($e->getMessage(), 'already exists') === false && 
                    stripos($e->getMessage(), 'Duplicate entry') === false) {
                    echo "<div class='error'>❌ Error: " . $e->getMessage() . "</div>";
                }
            }
        }
        
        echo "<div class='info'>ℹ️ Executed $executedStatements SQL statements with $errors errors (mostly expected duplicates)</div>";
        echo "</div>";
        
        // Verify migration
        echo "<div class='step'>";
        echo "<h4>Step 2: Verifying migration...</h4>";
        
        $newPdo = new PDO("mysql:host=localhost;dbname=ram_yum_inventory", "root", "", [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]);
        
        // Show record counts
        $tables = ['users', 'suppliers', 'products', 'locations', 'inventory_locations', 
                  'purchase_orders', 'receivings', 'stock_transfers', 'stock_transfer_audit', 
                  'inventory_movements', 'stock_adjustments', 'inventory_predictions'];
        
        echo "<h5>Record Counts in New Database:</h5>";
        echo "<table>";
        echo "<tr><th>Table</th><th>Records</th></tr>";
        foreach ($tables as $table) {
            try {
                $count = $newPdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
                echo "<tr><td>$table</td><td>$count</td></tr>";
            } catch (PDOException $e) {
                echo "<tr><td>$table</td><td>Error: Table not found</td></tr>";
            }
        }
        echo "</table>";
        
        // Verify audit table structure
        echo "<h5>Stock Transfer Audit Table Structure (Fixed):</h5>";
        $columns = $newPdo->query("SHOW COLUMNS FROM stock_transfer_audit")->fetchAll();
        echo "<table><tr><th>Field</th><th>Type</th><th>Key</th></tr>";
        foreach ($columns as $col) {
            echo "<tr><td>{$col['Field']}</td><td>{$col['Type']}</td><td>{$col['Key']}</td></tr>";
        }
        echo "</table>";
        
        // Show sample data
        echo "<h5>Sample Users:</h5>";
        $users = $newPdo->query("SELECT id, name, email, role FROM users LIMIT 5")->fetchAll();
        if ($users) {
            echo "<table><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th></tr>";
            foreach ($users as $user) {
                echo "<tr><td>{$user['id']}</td><td>{$user['name']}</td><td>{$user['email']}</td><td>{$user['role']}</td></tr>";
            }
            echo "</table>";
        }
        
        echo "</div>";
        
        // Show next steps
        echo "<div class='step'>";
        echo "<h4>✅ Migration Complete!</h4>";
        echo "<div class='success'>";
        echo "<strong>Next Steps:</strong><br>";
        echo "1. Update database configuration in <code>config/database.php</code><br>";
        echo "2. Change database name from 'ramyum_db' to 'ram_yum_inventory'<br>";
        echo "3. Fix undefined function calls in legacy files<br>";
        echo "4. Test all functionality<br>";
        echo "5. Remove old conflicting SQL setup files";
        echo "</div>";
        echo "</div>";
        
    } catch (Exception $e) {
        echo "<div class='error'>❌ Migration failed: " . $e->getMessage() . "</div>";
        echo "<div class='info'>Please check your database connection and try again.</div>";
    }
}
?>
    
    <div class="container">
        <h3>📋 What this migration does:</h3>
        <ul>
            <li>✅ Creates new centralized database: <strong>ram_yum_inventory</strong></li>
            <li>✅ Migrates all existing data from <strong>ramyum_db</strong></li>
            <li>✅ Fixes stock_transfer_audit table structure inconsistency</li>
            <li>✅ Preserves all user accounts, products, and transaction data</li>
            <li>✅ Converts audit data to match API expectations</li>
            <li>✅ Adds proper indexes for performance</li>
            <li>✅ Creates default data if no existing data found</li>
        </ul>
        
        <h3>📋 After migration:</h3>
        <ul>
            <li>Update <code>config/database.php</code> to use <strong>ram_yum_inventory</strong></li>
            <li>Fix undefined <code>get_database_connection()</code> function calls</li>
            <li>Test all system functionality</li>
            <li>Clean up old SQL setup files</li>
        </ul>
    </div>

</body>
</html>