-- ==========================================
-- PROOF OF RECEIVING (POR) SYSTEM MIGRATION
-- RAM-YUM Operations System
-- Date: October 3, 2026
-- ==========================================
-- This migration creates the complete POR system tables
-- that integrate with existing Purchase Order and Receiving workflows
-- ==========================================

-- ==========================================
-- TABLE: proof_of_receiving
-- Main POR table tracking official receiving records
-- ==========================================
CREATE TABLE IF NOT EXISTS `proof_of_receiving` (
  `id` varchar(40) NOT NULL PRIMARY KEY,
  `por_number` varchar(50) NOT NULL UNIQUE,
  `purchase_order_id` varchar(40) NOT NULL,
  `po_number` varchar(50) NOT NULL,
  `receiving_id` varchar(40) DEFAULT NULL,
  `supplier_id` varchar(40) NOT NULL,
  `supplier_name` varchar(255) NOT NULL,
  `received_by` varchar(40) NOT NULL,
  `received_by_name` varchar(255) NOT NULL,
  `receiving_date` datetime NOT NULL,
  `receiving_time` time NOT NULL,
  `inspection_status` enum('Pending','In Progress','Completed','Failed') DEFAULT 'Pending',
  `status` enum('Draft','Completed','Cancelled') DEFAULT 'Draft',
  `total_items` int(11) DEFAULT 0,
  `total_ordered` decimal(10,2) DEFAULT 0.00,
  `total_received` decimal(10,2) DEFAULT 0.00,
  `total_accepted` decimal(10,2) DEFAULT 0.00,
  `total_rejected` decimal(10,2) DEFAULT 0.00,
  `total_value` decimal(10,2) DEFAULT 0.00,
  `inspection_notes` text DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `evidence_files` longtext DEFAULT NULL COMMENT 'JSON array of uploaded file paths',
  `inventory_updated` tinyint(1) DEFAULT 0 COMMENT 'Prevent duplicate inventory updates',
  `inventory_updated_at` datetime DEFAULT NULL,
  `completed_by` varchar(40) DEFAULT NULL,
  `completed_by_name` varchar(255) DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `cancelled_by` varchar(40) DEFAULT NULL,
  `cancelled_by_name` varchar(255) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancellation_reason` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_por_number` (`por_number`),
  INDEX `idx_purchase_order` (`purchase_order_id`),
  INDEX `idx_po_number` (`po_number`),
  INDEX `idx_supplier` (`supplier_id`),
  INDEX `idx_status` (`status`),
  INDEX `idx_receiving_date` (`receiving_date`),
  INDEX `idx_received_by` (`received_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- TABLE: proof_of_receiving_items
-- Individual items in each POR with detailed quantity tracking
-- ==========================================
CREATE TABLE IF NOT EXISTS `proof_of_receiving_items` (
  `id` varchar(40) NOT NULL PRIMARY KEY,
  `por_id` varchar(40) NOT NULL,
  `product_id` varchar(40) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `unit` varchar(50) DEFAULT 'pcs',
  `ordered_quantity` decimal(10,2) NOT NULL,
  `received_quantity` decimal(10,2) NOT NULL,
  `accepted_quantity` decimal(10,2) NOT NULL,
  `rejected_quantity` decimal(10,2) DEFAULT 0.00,
  `damaged_quantity` decimal(10,2) DEFAULT 0.00,
  `unit_cost` decimal(10,2) DEFAULT 0.00,
  `total_cost` decimal(10,2) DEFAULT 0.00,
  `batch_number` varchar(100) DEFAULT NULL,
  `lot_number` varchar(100) DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `manufacturing_date` date DEFAULT NULL,
  `inspection_result` enum('Pass','Fail','Conditional','Pending') DEFAULT 'Pending',
  `inspection_notes` text DEFAULT NULL,
  `rejection_reason` varchar(255) DEFAULT NULL,
  `damage_type` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_por_id` (`por_id`),
  INDEX `idx_product_id` (`product_id`),
  INDEX `idx_sku` (`sku`),
  INDEX `idx_batch_number` (`batch_number`),
  INDEX `idx_expiration` (`expiration_date`),
  FOREIGN KEY (`por_id`) REFERENCES `proof_of_receiving`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- TABLE: transfer_proof
-- Proof of delivery for inter-location stock transfers
-- Separate from POR (supplier → RAM-YUM) vs (Location A → Location B)
-- ==========================================
CREATE TABLE IF NOT EXISTS `transfer_proof` (
  `id` varchar(40) NOT NULL PRIMARY KEY,
  `proof_number` varchar(50) NOT NULL UNIQUE,
  `transfer_id` varchar(40) NOT NULL,
  `transfer_number` varchar(50) NOT NULL,
  `source_location_id` varchar(40) NOT NULL,
  `source_location_name` varchar(255) NOT NULL,
  `destination_location_id` varchar(40) NOT NULL,
  `destination_location_name` varchar(255) NOT NULL,
  `transfer_date` datetime NOT NULL,
  `delivered_by` varchar(40) NOT NULL,
  `delivered_by_name` varchar(255) NOT NULL,
  `received_by` varchar(40) DEFAULT NULL,
  `received_by_name` varchar(255) DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `completion_date` datetime DEFAULT NULL,
  `status` enum('Pending','In Transit','Delivered','Completed','Cancelled') DEFAULT 'Pending',
  `total_items` int(11) DEFAULT 0,
  `total_quantity` decimal(10,2) DEFAULT 0.00,
  `delivery_notes` text DEFAULT NULL,
  `receiving_notes` text DEFAULT NULL,
  `evidence_files` longtext DEFAULT NULL COMMENT 'JSON array of uploaded file paths',
  `signature_delivered` text DEFAULT NULL COMMENT 'Base64 signature',
  `signature_received` text DEFAULT NULL COMMENT 'Base64 signature',
  `remarks` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_proof_number` (`proof_number`),
  INDEX `idx_transfer_id` (`transfer_id`),
  INDEX `idx_transfer_number` (`transfer_number`),
  INDEX `idx_source_location` (`source_location_id`),
  INDEX `idx_destination_location` (`destination_location_id`),
  INDEX `idx_status` (`status`),
  INDEX `idx_transfer_date` (`transfer_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- TABLE: transfer_proof_items
-- Items included in transfer proof
-- ==========================================
CREATE TABLE IF NOT EXISTS `transfer_proof_items` (
  `id` varchar(40) NOT NULL PRIMARY KEY,
  `proof_id` varchar(40) NOT NULL,
  `product_id` varchar(40) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `unit` varchar(50) DEFAULT 'pcs',
  `quantity_transferred` decimal(10,2) NOT NULL,
  `quantity_received` decimal(10,2) DEFAULT 0.00,
  `condition_notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_proof_id` (`proof_id`),
  INDEX `idx_product_id` (`product_id`),
  FOREIGN KEY (`proof_id`) REFERENCES `transfer_proof`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- VERIFICATION QUERIES
-- Run these after migration to verify tables exist
-- ==========================================

-- Check if POR tables exist
SELECT 
    TABLE_NAME,
    TABLE_ROWS,
    CREATE_TIME
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
AND TABLE_NAME IN ('proof_of_receiving', 'proof_of_receiving_items', 'transfer_proof', 'transfer_proof_items')
ORDER BY TABLE_NAME;

-- Show POR table structure
SHOW COLUMNS FROM proof_of_receiving;

-- Show POR items table structure
SHOW COLUMNS FROM proof_of_receiving_items;

-- Show Transfer Proof table structure
SHOW COLUMNS FROM transfer_proof;

-- ==========================================
-- SAMPLE DATA (OPTIONAL - for testing)
-- ==========================================

-- Sample POR record (Draft status)
/*
INSERT INTO proof_of_receiving (
    id, por_number, purchase_order_id, po_number, supplier_id, supplier_name,
    received_by, received_by_name, receiving_date, receiving_time,
    inspection_status, status, total_items, total_ordered, total_received,
    total_accepted, total_rejected
) VALUES (
    'por_sample_001',
    'POR-2026-0001',
    'po_123',
    'PO-2026-0001',
    's1',
    'Seoul Food Distribution',
    'u1',
    'Admin User',
    '2026-10-03 10:30:00',
    '10:30:00',
    'Completed',
    'Completed',
    3,
    100.00,
    98.00,
    95.00,
    3.00
);
*/

-- ==========================================
-- MIGRATION COMPLETE
-- ==========================================
-- Next steps:
-- 1. Run this SQL file in phpMyAdmin or MySQL command line
-- 2. Verify tables exist using verification queries
-- 3. Proceed to implement API endpoints
-- ==========================================
