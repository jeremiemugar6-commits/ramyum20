<?php
/**
 * Demo Data Loader for RAM-YUM Capstone Demonstration
 * This script safely loads the enhanced suppliers and products for the pre-oral defense
 */

require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');

try {
    $db = getDB();
    
    // Read the seed demo data SQL file
    $sqlFile = __DIR__ . '/seed-demo-data.sql';
    if (!file_exists($sqlFile)) {
        throw new Exception('Demo data SQL file not found');
    }
    
    $sql = file_get_contents($sqlFile);
    
    // Remove comments and split into individual statements
    $statements = array_filter(
        array_map('trim', explode(';', $sql)),
        function($stmt) {
            return !empty($stmt) && 
                   !str_starts_with($stmt, '--') && 
                   !str_starts_with($stmt, '/*');
        }
    );
    
    $db->beginTransaction();
    
    $executed = 0;
    foreach ($statements as $statement) {
        if (trim($statement)) {
            $db->exec($statement);
            $executed++;
        }
    }
    
    $db->commit();
    
    // Get counts to verify
    $supplierCount = $db->query("SELECT COUNT(*) as count FROM suppliers")->fetch()['count'];
    $productCount = $db->query("SELECT COUNT(*) as count FROM products")->fetch()['count'];
    
    echo json_encode([
        'success' => true,
        'message' => 'Demo data loaded successfully',
        'data' => [
            'statements_executed' => $executed,
            'suppliers_total' => $supplierCount,
            'products_total' => $productCount,
            'demo_mode' => DEMO_INTEGRATION_MODE ? 'ACTIVE' : 'INACTIVE'
        ]
    ]);
    
} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to load demo data: ' . $e->getMessage()
    ]);
}