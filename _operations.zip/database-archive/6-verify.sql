-- =====================================================================
-- STEP 6: Final Verification
-- Run this last to verify everything is set up correctly
-- =====================================================================

USE ramyum_db;

SELECT '==================== FINAL VERIFICATION ====================' as info;

-- Check locations
SELECT 'LOCATIONS:' as table_name, COUNT(*) as record_count FROM locations;
SELECT 
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.name')) as location_name,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.type')) as location_type,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) as status
FROM locations 
ORDER BY JSON_UNQUOTE(JSON_EXTRACT(data, '$.name'));

-- Check inventory
SELECT 'INVENTORY:' as table_name, COUNT(*) as record_count FROM inventory_locations;

-- Check stock transfers  
SELECT 'STOCK TRANSFERS:' as table_name, COUNT(*) as record_count FROM stock_transfers;
SELECT 
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.transferNumber')) as transfer_number,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) as status,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.priority')) as priority
FROM stock_transfers 
WHERE id LIKE 'st_demo_%'
ORDER BY JSON_UNQUOTE(JSON_EXTRACT(data, '$.transferNumber'));

-- Check audit trail
SELECT 'AUDIT TRAIL:' as table_name, COUNT(*) as record_count FROM stock_transfer_audit;
SELECT 
    transfer_id,
    COUNT(*) as audit_entries,
    GROUP_CONCAT(action ORDER BY created_at SEPARATOR ' → ') as workflow
FROM stock_transfer_audit 
WHERE transfer_id LIKE 'ST-2026-01%'
GROUP BY transfer_id 
ORDER BY transfer_id;

SELECT '==================== SETUP COMPLETE! ====================' as status;
SELECT 'Go to: Dashboard → Stock Transfer → Create Transfer' as next_step;
SELECT 'Dropdowns should show 4 locations!' as expected_result;