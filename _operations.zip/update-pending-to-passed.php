<?php
/**
 * Update ALL Pending POR Records to Passed
 * Simple script to change status from "Pending" to "Passed" for Admin User records
 */

require_once __DIR__ . '/config/database.php';

$db = getDB();

try {
    // Start transaction
    $db->beginTransaction();
    
    // Count records before update
    $stmt = $db->prepare("
        SELECT COUNT(*) as count 
        FROM proof_of_receiving 
        WHERE inspection_status IN ('Pending', 'Pending Inspection')
          AND received_by_name = 'Admin User'
    ");
    $stmt->execute();
    $beforeCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    echo "<h2>Update Pending → Passed Status</h2>";
    echo "<p>Found <strong>{$beforeCount}</strong> Pending records by Admin User</p>";
    
    if ($beforeCount == 0) {
        echo "<p style='color:orange;'>No Pending records found.</p>";
        $db->rollBack();
        
        // Show current status summary
        $stmt = $db->query("SELECT inspection_status, COUNT(*) as count FROM proof_of_receiving GROUP BY inspection_status");
        echo "<h3>Current Status Summary:</h3>";
        echo "<ul>";
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<li><strong>{$row['inspection_status']}:</strong> {$row['count']}</li>";
        }
        echo "</ul>";
        exit;
    }
    
    // Get list of records that will be updated
    $stmt = $db->prepare("
        SELECT por_number, inspection_status, total_accepted, total_rejected 
        FROM proof_of_receiving 
        WHERE inspection_status IN ('Pending', 'Pending Inspection')
          AND received_by_name = 'Admin User'
        ORDER BY created_at DESC
        LIMIT 20
    ");
    $stmt->execute();
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>Records to Update (showing first 20):</h3>";
    echo "<table border='1' cellpadding='10' style='border-collapse:collapse; width:100%;'>";
    echo "<tr style='background:#f0f0f0;'>
            <th>POR #</th>
            <th>Current Status</th>
            <th>New Status</th>
            <th>Accepted Items</th>
            <th>Rejected Items</th>
          </tr>";
    
    foreach ($records as $rec) {
        echo "<tr>";
        echo "<td>{$rec['por_number']}</td>";
        echo "<td style='color:#F59E0B;'>{$rec['inspection_status']}</td>";
        echo "<td style='color:#10B981; font-weight:bold;'>Passed</td>";
        echo "<td style='color:#10B981;'>{$rec['total_accepted']}</td>";
        echo "<td style='color:#EF4444;'>{$rec['total_rejected']}</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    
    // Perform the update
    $updateStmt = $db->prepare("
        UPDATE proof_of_receiving 
        SET inspection_status = 'Passed'
        WHERE inspection_status IN ('Pending', 'Pending Inspection')
          AND received_by_name = 'Admin User'
    ");
    $updateStmt->execute();
    $updatedCount = $updateStmt->rowCount();
    
    // Commit changes
    $db->commit();
    
    echo "<div style='background:#D1FAE5; border:2px solid #10B981; padding:20px; border-radius:8px; margin:30px 0;'>";
    echo "<h3 style='color:#065F46; margin:0 0 10px 0;'>✓ Successfully Updated!</h3>";
    echo "<p style='color:#065F46; font-size:1.2rem; margin:0;'><strong>{$updatedCount}</strong> POR records updated from Pending to Passed</p>";
    echo "</div>";
    
    // Show new status summary
    $stmt = $db->query("
        SELECT 
            inspection_status, 
            COUNT(*) as count 
        FROM proof_of_receiving 
        GROUP BY inspection_status 
        ORDER BY count DESC
    ");
    
    echo "<h3>Updated Status Summary:</h3>";
    echo "<div style='display:grid; grid-template-columns:repeat(4, 1fr); gap:16px; margin:20px 0;'>";
    
    $counts = ['Pending' => 0, 'Passed' => 0, 'Failed' => 0, 'Partial' => 0];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if (isset($counts[$row['inspection_status']])) {
            $counts[$row['inspection_status']] = $row['count'];
        }
    }
    
    foreach ($counts as $status => $count) {
        $color = match($status) {
            'Passed' => '#10B981',
            'Failed' => '#EF4444',
            'Partial' => '#F59E0B',
            'Pending' => '#6B7280',
        };
        
        echo "<div style='background:white; border:2px solid {$color}; border-radius:8px; padding:20px; text-align:center;'>";
        echo "<div style='color:{$color}; font-weight:600; margin-bottom:8px;'>{$status}</div>";
        echo "<div style='color:{$color}; font-size:2rem; font-weight:700;'>{$count}</div>";
        echo "</div>";
    }
    
    echo "</div>";
    
    echo "<p style='margin-top:30px;'><a href='dashboard.php#por' style='padding:12px 24px; background:#FF7A00; color:white; text-decoration:none; border-radius:8px; font-weight:600; display:inline-block;'>→ Go to POR Module</a></p>";
    
} catch (Exception $e) {
    $db->rollBack();
    echo "<div style='background:#FEE2E2; border:2px solid #EF4444; padding:20px; border-radius:8px;'>";
    echo "<h3 style='color:#991B1B; margin:0 0 10px 0;'>✗ Error</h3>";
    echo "<p style='color:#991B1B; margin:0;'>{$e->getMessage()}</p>";
    echo "</div>";
}
?>

<style>
    body {
        font-family: Arial, sans-serif;
        max-width: 1200px;
        margin: 50px auto;
        padding: 20px;
        background: #f5f5f5;
    }
    h2 {
        color: #333;
        border-bottom: 3px solid #FF7A00;
        padding-bottom: 10px;
    }
</style>
