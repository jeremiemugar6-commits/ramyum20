<?php
require_once __DIR__ . '/includes/auth.php';

// Already logged in? Skip straight to the dashboard.
if (is_logged_in() && current_user()) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - RAM-YUM Store</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/auth.css">

    <style>
        .password-wrapper { position: relative; width: 100%; }
        .password-wrapper input { width: 100%; padding-right: 45px; }
        .toggle-password {
            position: absolute; right: 12px; top: 50%; transform: translateY(-50%);
            background: transparent; border: none; cursor: pointer; color: #9CA3AF;
            padding: 4px; display: flex; align-items: center; justify-content: center;
            transition: color 0.2s;
        }
        .toggle-password:hover { color: var(--text-primary); }
        .toggle-password svg { width: 20px; height: 20px; stroke-width: 2; }
    </style>
</head>
<body>
<div class="auth-container">
    <div class="auth-card">
        <img src="assets/images/logo.jpg" alt="RAM-YUM Logo" style="width: 120px; height: 120px; object-fit: contain; margin: 0 auto 20px; display: block;">
        <h2 class="auth-title">RAM-YUM Store</h2>
        <p class="auth-subtitle">Sign in to your account</p>
        <form id="loginForm">
            <div class="form-group">
                <label for="username" class="form-label">Username or Email</label>
                <input type="text" id="username" class="form-input" placeholder="Enter your username" required>
                <div class="input-error-text">Username is required.</div>
            </div>

            <div class="form-group">
                <label for="password" class="form-label">Password</label>
                <div class="password-wrapper">
                    <input type="password" id="password" class="form-input" placeholder="Enter your password" required>
                    <button type="button" class="toggle-password" id="togglePasswordBtn" aria-label="Toggle password visibility">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                            <circle cx="12" cy="12" r="3"></circle>
                        </svg>
                    </button>
                </div>
                <div class="input-error-text">Password is required.</div>
            </div>

            <button type="submit" id="loginBtn" class="btn-primary">LOGIN</button>
        </form>

        <form id="otpForm" style="display:none;">
            <h3 style="margin:0 0 4px; font-size:1.05rem; color:var(--text-primary);">Two-Factor Authentication</h3>
            <p style="margin:0 0 14px; font-size:0.85rem; color:var(--text-secondary);">We've sent a verification code to your email.</p>

            <div class="form-group">
                <label class="form-label" for="otpBox0">Verification Code</label>
                <div id="otpBoxGroup" style="display:flex; gap:8px; justify-content:space-between;">
                    <input type="text" inputmode="numeric" maxlength="1" class="form-input otp-box" id="otpBox0"
                           style="width:15%; text-align:center; font-size:1.3rem; padding:10px 0;" autocomplete="one-time-code">
                    <input type="text" inputmode="numeric" maxlength="1" class="form-input otp-box" id="otpBox1"
                           style="width:15%; text-align:center; font-size:1.3rem; padding:10px 0;">
                    <input type="text" inputmode="numeric" maxlength="1" class="form-input otp-box" id="otpBox2"
                           style="width:15%; text-align:center; font-size:1.3rem; padding:10px 0;">
                    <input type="text" inputmode="numeric" maxlength="1" class="form-input otp-box" id="otpBox3"
                           style="width:15%; text-align:center; font-size:1.3rem; padding:10px 0;">
                    <input type="text" inputmode="numeric" maxlength="1" class="form-input otp-box" id="otpBox4"
                           style="width:15%; text-align:center; font-size:1.3rem; padding:10px 0;">
                    <input type="text" inputmode="numeric" maxlength="1" class="form-input otp-box" id="otpBox5"
                           style="width:15%; text-align:center; font-size:1.3rem; padding:10px 0;">
                </div>
                <!-- Hidden field carries the assembled 6-digit code for form submission / validation -->
                <input type="hidden" id="otpCode">
                <div class="input-error-text">Enter the 6-digit code.</div>
                <p id="otpHint" style="margin-top:8px; font-size:0.82rem; color:var(--text-secondary);"></p>
                <p id="otpExpiryHint" style="margin-top:2px; font-size:0.8rem; color:var(--text-secondary);"></p>
            </div>

            <button type="submit" id="otpVerifyBtn" class="btn-primary">VERIFY & LOGIN</button>

            <div class="auth-options-row" style="margin-top:14px; justify-content:space-between;">
                <button type="button" id="otpResendBtn" class="auth-forgot-link" style="background:none; border:none; cursor:pointer; padding:0; font:inherit;">Resend Code</button>
                <button type="button" id="otpBackBtn" class="auth-forgot-link" style="background:none; border:none; cursor:pointer; padding:0; font:inherit;">Back to Login</button>
            </div>
        </form>

        <p id="demoAccountsHint" style="margin-top:16px; font-size:0.8rem; color:var(--text-secondary); text-align:center;">
            Demo accounts — admin / admin123 &nbsp;|&nbsp; staff / staff123
        </p>
    </div>
</div>

<script type="module">
    import { Validator } from './assets/js/utils/validator.js';
    import { toast } from './assets/js/components/toast.js';

    const form = document.getElementById('loginForm');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const loginBtn = document.getElementById('loginBtn');
    const togglePasswordBtn = document.getElementById('togglePasswordBtn');

    const otpForm = document.getElementById('otpForm');
    const otpInput = document.getElementById('otpCode'); // hidden field holding the assembled code
    const otpBoxes = Array.from(document.querySelectorAll('.otp-box'));
    const otpVerifyBtn = document.getElementById('otpVerifyBtn');
    const otpResendBtn = document.getElementById('otpResendBtn');
    const otpBackBtn = document.getElementById('otpBackBtn');
    const otpHint = document.getElementById('otpHint');
    const otpExpiryHint = document.getElementById('otpExpiryHint');
    const demoAccountsHint = document.getElementById('demoAccountsHint');

    let resendCooldownTimer = null;
    let expiryCountdownTimer = null;
    const OTP_TTL_SECONDS = 5 * 60;

    // --- OTP BOX GROUP: auto-advance, backspace, and 6-digit paste ---
    function syncOtpHiddenField() {
        otpInput.value = otpBoxes.map(b => b.value).join('');
    }

    function clearOtpBoxes() {
        otpBoxes.forEach(b => { b.value = ''; b.classList.remove('error'); });
        syncOtpHiddenField();
    }

    otpBoxes.forEach((box, idx) => {
        box.addEventListener('input', () => {
            box.value = box.value.replace(/\D/g, '').slice(0, 1);
            syncOtpHiddenField();
            if (box.value && idx < otpBoxes.length - 1) {
                otpBoxes[idx + 1].focus();
            }
        });

        box.addEventListener('keydown', (e) => {
            if (e.key === 'Backspace' && !box.value && idx > 0) {
                otpBoxes[idx - 1].focus();
            }
        });

        box.addEventListener('paste', (e) => {
            const pasted = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '');
            if (pasted.length < 1) return;
            e.preventDefault();
            for (let i = 0; i < otpBoxes.length; i++) {
                otpBoxes[i].value = pasted[i] || '';
            }
            syncOtpHiddenField();
            const nextEmpty = otpBoxes.findIndex(b => !b.value);
            (nextEmpty === -1 ? otpBoxes[otpBoxes.length - 1] : otpBoxes[nextEmpty]).focus();
        });
    });

    function startExpiryCountdown(seconds = OTP_TTL_SECONDS) {
        let remaining = seconds;
        const render = () => {
            const m = Math.floor(remaining / 60);
            const s = String(remaining % 60).padStart(2, '0');
            otpExpiryHint.textContent = remaining > 0
                ? `Code expires in ${m}:${s}`
                : 'This code has expired — request a new one.';
        };
        render();
        if (expiryCountdownTimer) clearInterval(expiryCountdownTimer);
        expiryCountdownTimer = setInterval(() => {
            remaining -= 1;
            render();
            if (remaining <= 0) {
                clearInterval(expiryCountdownTimer);
                expiryCountdownTimer = null;
            }
        }, 1000);
    }

    // --- SHOW PASSWORD TOGGLE ---
    togglePasswordBtn.addEventListener('click', function () {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        this.innerHTML = type === 'password'
            ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>`
            : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>`;
    });

    document.querySelectorAll('.form-input').forEach(input => {
        input.addEventListener('input', () => {
            input.classList.remove('error');
            input.closest('.form-group')?.querySelector('.input-error-text')?.classList.remove('show');
        });
    });

    function showOtpStep(maskedEmail, debugCode) {
        form.style.display = 'none';
        demoAccountsHint.style.display = 'none';
        otpForm.style.display = 'block';
        otpHint.textContent = maskedEmail
            ? `We've sent a 6-digit code to ${maskedEmail}.`
            : "We've sent a 6-digit code to your email.";
        if (debugCode) {
            otpHint.textContent += ` (Demo mode — code: ${debugCode})`;
        }
        clearOtpBoxes();
        otpBoxes[0].focus();
        startExpiryCountdown();
    }

    function backToLoginStep() {
        otpForm.style.display = 'none';
        form.style.display = 'block';
        demoAccountsHint.style.display = 'block';
        loginBtn.textContent = 'LOGIN';
        loginBtn.disabled = false;
        if (resendCooldownTimer) { clearInterval(resendCooldownTimer); resendCooldownTimer = null; }
        if (expiryCountdownTimer) { clearInterval(expiryCountdownTimer); expiryCountdownTimer = null; }
        otpResendBtn.textContent = 'Resend Code';
        otpResendBtn.disabled = false;
    }

    function startResendCooldown(seconds = 60) {
        let remaining = seconds;
        otpResendBtn.disabled = true;
        otpResendBtn.textContent = `Resend Code (${remaining}s)`;
        if (resendCooldownTimer) clearInterval(resendCooldownTimer);
        resendCooldownTimer = setInterval(() => {
            remaining -= 1;
            if (remaining <= 0) {
                clearInterval(resendCooldownTimer);
                resendCooldownTimer = null;
                otpResendBtn.disabled = false;
                otpResendBtn.textContent = 'Resend Code';
            } else {
                otpResendBtn.textContent = `Resend Code (${remaining}s)`;
            }
        }, 1000);
    }

    // --- LOGIN SUBMISSION — real server-side auth via api/login.php ---
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();

        const validationResult = Validator.validateForm(
            { username, password },
            { username: 'required', password: 'required' }
        );

        if (!validationResult.isValid) {
            for (let field in validationResult.errors) {
                const input = document.getElementById(field);
                if (input) {
                    input.classList.add('error');
                    const errorText = input.closest('.form-group')?.querySelector('.input-error-text');
                    if (errorText) {
                        errorText.textContent = validationResult.errors[field];
                        errorText.classList.add('show');
                    }
                }
            }
            return;
        }

        document.querySelectorAll('.form-input').forEach(el => el.classList.remove('error'));
        document.querySelectorAll('.input-error-text').forEach(el => el.classList.remove('show'));

        loginBtn.textContent = 'Logging in...';
        loginBtn.disabled = true;

        try {
            const res = await fetch('api/login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            const result = await res.json();

            if (!result.success) {
                throw new Error(result.error || 'Login failed.');
            }

            if (result.requiresOtp) {
                toast.show('Password verified — enter the code we sent you.', 'info');
                showOtpStep(result.maskedEmail, result.debugCode);
                startResendCooldown();
                return;
            }

            toast.show(`Welcome back, ${result.user.name}!`, 'success');
            setTimeout(() => { window.location.href = 'dashboard.php'; }, 400);
        } catch (error) {
            toast.show(error.message || 'Invalid username or password.', 'error');
            usernameInput.classList.add('error');
            passwordInput.classList.add('error');
            loginBtn.textContent = 'LOGIN';
            loginBtn.disabled = false;
        }
    });

    // --- OTP VERIFICATION ---
    otpForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        syncOtpHiddenField();
        const code = otpInput.value.trim();
        if (!/^\d{6}$/.test(code)) {
            otpBoxes.forEach(b => b.classList.add('error'));
            otpForm.querySelector('.input-error-text')?.classList.add('show');
            return;
        }

        otpVerifyBtn.textContent = 'Verifying...';
        otpVerifyBtn.disabled = true;

        try {
            const res = await fetch('api/verify-otp.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code })
            });
            const result = await res.json();

            if (!result.success) {
                throw new Error(result.error || 'Invalid code.');
            }

            toast.show(`Welcome back, ${result.user.name}!`, 'success');
            setTimeout(() => { window.location.href = 'dashboard.php'; }, 400);
        } catch (error) {
            toast.show(error.message || 'Invalid or expired code.', 'error');
            otpBoxes.forEach(b => b.classList.add('error'));
            clearOtpBoxes();
            otpBoxes[0].focus();
            otpVerifyBtn.textContent = 'VERIFY & LOGIN';
            otpVerifyBtn.disabled = false;
        }
    });

    // --- OTP RESEND ---
    otpResendBtn.addEventListener('click', async () => {
        try {
            const res = await fetch('api/resend-otp.php', { method: 'POST' });
            const result = await res.json();
            if (!result.success) throw new Error(result.error || 'Could not resend code.');
            toast.show('A new code has been sent.', 'info');
            otpHint.textContent = `We've sent a new 6-digit code to ${result.maskedEmail}.`;
            if (result.debugCode) {
                otpHint.textContent += ` (Demo mode — code: ${result.debugCode})`;
            }
            clearOtpBoxes();
            otpBoxes[0].focus();
            startResendCooldown();
            startExpiryCountdown();
        } catch (error) {
            toast.show(error.message || 'Could not resend code.', 'error');
        }
    });

    // --- OTP BACK TO LOGIN ---
    otpBackBtn.addEventListener('click', backToLoginStep);
</script>
</body>
</html>
