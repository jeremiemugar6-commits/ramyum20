# RAM-YUM Backend Implementation Guide

## Complete End-to-End Operational Workflow Processing

This document describes the comprehensive backend PHP processing system for RAM-YUM Korean & Japanese Store's operational workflow.

---

## System Architecture

### Technology Stack
- **Backend**: PHP 7.4+ (Procedural/Standard PHP)
- **Database**: MySQL 8.0+ with MySQLi/PDO
- **Transaction Safety**: All operations wrapped in SQL Transactions (START TRANSACTION / COMMIT / ROLLBACK)
- **Security**: Prepared statements prevent SQL injection
- **Data Integrity**: Rollback on any error prevents partial saves

### Core Files
- `api/workflow-processor.php` - Main workflow processing engine
- `config/database.php` - Database connection and configuration
- `includes/auth.php` - Authentication and authorization
- `includes/functions.php` - Utility functions

---

## Operational Workflow Pipeline

### STEP 1: PURCHASE ORDER CREATION & APPROVAL

#### 1.1 Create Purchase Order

**Endpoint**: `POST api/workflow-processor.php?action=create_purchase_order`

**Request Body**:
```json
{
  "supplier_id": "s1",
  "expected_date": "2026-10-15",
  "items": [
    {
      "product_id": "p1",
      "quantity": 50,
      "unit_cost": 65.00
    },
    {
      "product_id": "p2",
      "quantity": 30
      // unit_cost optional - auto-fetched from product database
    }
  ],
  "notes": "Urgent order for weekend sale"
}
```

**Processing Logic**:
1. ✅ Validates supplier exists in database
2. ✅ Fetches product details and prices automatically
3. ✅ Calculates totals (subtotal, total)
4. ✅ Generates sequential PO Number (PO-2026-0001)
5. ✅ Sets initial status to **'Pending'** (Awaiting approval)
6. ✅ Logs audit trail event

**Response**:
```json
{
  "success": true,
  "message": "Purchase Order PO-2026-0001 created successfully and awaiting approval",
  "data": {
    "po_id": "po_abc123",
    "po_number": "PO-2026-0001",
    "status": "Pending"
  }
}
```

#### 1.2 Approve Purchase Order

**Endpoint**: `POST api/workflow-processor.php?action=approve_purchase_order`

**Authorization**: Admin or Manager only

**Request Body**:
```json
{
  "po_id": "po_abc123"
}
```

**Processing Logic**:
1. ✅ Verifies user has approval authority
2. ✅ Validates PO status is 'Pending'
3. ✅ Updates status to **'Approved'** (Ready to receive)
4. ✅ Records approver name and timestamp
5. ✅ PO now appears in "Pending Deliveries" list
6. ✅ Logs audit trail event

**Status Lifecycle**:
```
Pending → Approved → Received
```

---

### STEP 2: RECEIVING & INSPECTION

#### 2.1 Get Pending Deliveries

**Endpoint**: `GET api/workflow-processor.php?action=pending_deliveries`

**Response**:
```json
{
  "success": true,
  "data": [
    {
      "id": "po_abc123",
      "poNumber": "PO-2026-0001",
      "supplier": "Seoul Food Distribution",
      "orderDate": "2026-10-01T10:30:00.000Z",
      "expectedDate": "2026-10-15",
      "totalItems": 80,
      "total": 4550.00,
      "items": [...]
    }
  ]
}
```

#### 2.2 Receive Items (Inspection Log)

**Endpoint**: `POST api/workflow-processor.php?action=receive_items`

**Request Body**:
```json
{
  "po_id": "po_abc123",
  "items": [
    {
      "product_id": "p1",
      "product_name": "Samyang Buldak Original",
      "sku": "SAM-001",
      "ordered_quantity": 50,
      "received_quantity": 48,
      "unit_cost": 65.00
    },
    {
      "product_id": "p2",
      "product_name": "Shin Ramyun",
      "sku": "SHIN-001",
      "ordered_quantity": 30,
      "received_quantity": 30,
      "unit_cost": 75.00
    }
  ],
  "notes": "2 units damaged in transit for product p1"
}
```

**Processing Logic**:
1. ✅ Validates PO is approved
2. ✅ Generates sequential Receiving Number (GR-2026-0001)
3. ✅ Records actual received quantities vs ordered quantities
4. ✅ Creates inspection log with discrepancies
5. ✅ Updates PO status to 'Received'
6. ✅ Logs audit trail event
7. ⚠️ **IMPORTANT**: Stock NOT updated yet - awaiting POR

---

### STEP 3: PROOF OF RECEIVING & AUTOMATIC STOCK INCREMENT

#### 3.1 Create POR with Stock Update

**Endpoint**: `POST api/workflow-processor.php?action=create_por_with_stock_update`

**⚡ CRITICAL OPERATION**: This triggers automatic inventory updates

**Request Body**:
```json
{
  "receiving_id": "receiving_xyz789",
  "remarks": "All items inspected and approved for storage"
}
```

**Processing Logic** (Atomic Transaction):
1. ✅ Validates receiving record exists
2. ✅ Generates sequential POR Number (POR-2026-0001)
3. ✅ Creates POR record with all item details
4. ✅ **AUTOMATIC STOCK INCREMENT**:
   - For each accepted item:
     - ✅ Fetches current stock from `products` table
     - ✅ Calculates: `newStock = currentStock + acceptedQuantity`
     - ✅ Updates product stock count
     - ✅ Recalculates stock status badge:
       - `0` → "Out of Stock"
       - `1-20` → "Low Stock"
       - `21-100` → "In Stock"
       - `101+` → "Overstock"
     - ✅ Creates inventory movement log entry
     - ✅ Records batch information, expiration dates
5. ✅ Updates system total inventory value
6. ✅ Logs comprehensive audit trail
7. ✅ **Transaction commits** - all changes permanent
8. ❌ On any error: **ROLLBACK** - no partial updates

**Response**:
```json
{
  "success": true,
  "message": "POR POR-2026-0001 created and inventory automatically updated!",
  "data": {
    "por_id": "por_def456",
    "por_number": "POR-2026-0001",
    "total_accepted": 78,
    "inventory_updated": true
  }
}
```

**Database Updates Executed**:
```sql
-- 1. Update product stock
UPDATE products 
SET data = JSON_SET(data, '$.stock', newStock, '$.status', newStatus)
WHERE id = ?;

-- 2. Create inventory movement log
INSERT INTO inventory_movements (id, data, created_at, updated_at)
VALUES (?, ?, NOW(), NOW());

-- 3. Update POR record
UPDATE proof_of_receiving 
SET inventory_updated = 1, inventory_updated_at = NOW()
WHERE id = ?;
```

---

### STEP 4: STOCK TRANSFER WITH PHOTO VERIFICATION

#### 4.1 Create Stock Transfer

**Endpoint**: `POST api/workflow-processor.php?action=create_stock_transfer`

**Request Body**:
```json
{
  "source_location": "loc_warehouse_main",
  "destination_location": "loc_branch_makati",
  "items": [
    {
      "product_id": "p1",
      "quantity": 20,
      "batch_number": "BATCH-001"
    }
  ],
  "notes": "Weekend stock for Makati branch"
}
```

**Validation Logic**:
1. ✅ Checks source location has sufficient stock
2. ✅ `transferQuantity <= availableStock`
3. ✅ If validation fails: Transaction rolls back
4. ✅ Creates transfer with status 'Pending'
5. ⚠️ **Stock NOT deducted yet** - awaiting verification

**Response**:
```json
{
  "success": true,
  "message": "Stock Transfer ST-2026-0001 created. Awaiting photo verification at destination.",
  "data": {
    "transfer_id": "transfer_ghi789",
    "transfer_number": "ST-2026-0001",
    "status": "Pending"
  }
}
```

#### 4.2 Verify Transfer Arrival (Photo Upload)

**Endpoint**: `POST api/workflow-processor.php?action=verify_transfer_arrival`

**⚡ CRITICAL OPERATION**: Only after photo upload will inventory change

**Request Body**:
```json
{
  "transfer_id": "transfer_ghi789",
  "verification_photo": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAA..."
}
```

**Processing Logic** (Atomic Transaction):
1. ✅ Validates transfer is pending
2. ✅ Saves verification photo to server
3. ✅ **INVENTORY UPDATES**:
   - For each item:
     - ✅ Deducts quantity from source location stock
     - ✅ `newStock = currentStock - transferQuantity`
     - ✅ Updates product stock status badge
     - ✅ Creates inventory movement log (Stock Transfer Out)
4. ✅ Updates transfer status to 'Completed'
5. ✅ Records verifier name and timestamp
6. ✅ Logs audit trail with photo reference
7. ✅ **Transaction commits**
8. ❌ On error: **ROLLBACK** - no changes made

**Response**:
```json
{
  "success": true,
  "message": "Transfer ST-2026-0001 verified and inventory updated!",
  "data": {
    "transfer_number": "ST-2026-0001",
    "status": "Completed",
    "verified_by": "Branch Manager"
  }
}
```

---

### STEP 5: AUDIT TRAIL & REPORTING

#### 5.1 Get Audit Trail

**Endpoint**: `GET api/workflow-processor.php?action=audit_trail`

**Query Parameters**:
- `date_from` - Filter start date (YYYY-MM-DD)
- `date_to` - Filter end date (YYYY-MM-DD)
- `event_type` - Filter by event type

**Example**:
```
GET api/workflow-processor.php?action=audit_trail&date_from=2026-10-01&event_type=PO_CREATED
```

**Response**:
```json
{
  "success": true,
  "data": [
    {
      "id": "log_123",
      "event_type": "PO_CREATED",
      "user_id": "admin",
      "username": "Admin User",
      "ip_address": "192.168.1.1",
      "event_data": "{\"po_number\":\"PO-2026-0001\",\"total\":4550.00}",
      "created_at": "2026-10-01 10:30:00"
    },
    {
      "id": "log_124",
      "event_type": "PO_APPROVED",
      "user_id": "manager",
      "username": "Store Manager",
      "event_data": "{\"po_number\":\"PO-2026-0001\"}",
      "created_at": "2026-10-01 11:15:00"
    },
    {
      "id": "log_125",
      "event_type": "POR_CREATED_STOCK_UPDATED",
      "user_id": "admin",
      "event_data": "{\"por_number\":\"POR-2026-0001\",\"inventory_updated\":true}",
      "created_at": "2026-10-03 14:20:00"
    }
  ],
  "count": 3
}
```

**Logged Events**:
- `PO_CREATED` - New purchase order created
- `PO_APPROVED` - Purchase order approved
- `ITEMS_RECEIVED` - Items received at warehouse
- `POR_CREATED_STOCK_UPDATED` - POR created and inventory updated
- `TRANSFER_CREATED` - Stock transfer initiated
- `TRANSFER_VERIFIED` - Transfer verified with photo
- `STOCK_ADJUSTMENT` - Manual stock adjustment
- `LOGIN_SUCCESS` - User login
- `LOGIN_FAILED` - Failed login attempt

---

## Transaction Safety & Error Handling

### Transaction Pattern

Every critical operation follows this pattern:

```php
try {
    // START TRANSACTION
    $db->beginTransaction();
    
    // 1. Validate all inputs
    // 2. Check business rules
    // 3. Perform database operations
    // 4. Update related records
    // 5. Log audit trail
    
    // COMMIT - Make all changes permanent
    $db->commit();
    
    return success_response();
    
} catch (Exception $e) {
    // ROLLBACK - Undo all changes
    $db->rollBack();
    
    return error_response($e->getMessage());
}
```

### Why This Matters

**Without Transactions**:
```
❌ Product stock updated: +50
❌ System crashes
❌ Inventory movement log NOT created
❌ POR record incomplete
❌ Data is now corrupted
```

**With Transactions**:
```
✅ Product stock updated: +50
✅ Error occurs
✅ ROLLBACK executed
✅ Product stock reverted to original
✅ No data corruption
✅ System remains consistent
```

---

## Security Features

### 1. Authentication Required
```php
$currentUser = require_login_api();
// Validates session, checks user is logged in
// Returns user data or exits with 401 Unauthorized
```

### 2. Role-Based Authorization
```php
// Only admin/manager can approve POs
if (!in_array($userRole, ['admin', 'manager'])) {
    json_error('Unauthorized', 403);
}
```

### 3. SQL Injection Prevention
```php
// ❌ DANGEROUS - Never do this
$query = "SELECT * FROM products WHERE id = '{$_POST['id']}'";

// ✅ SAFE - Always use prepared statements
$stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$input['id']]);
```

### 4. Input Validation
```php
// Validate required fields
if (empty($input['supplier_id']) || empty($input['items'])) {
    json_error('Missing required fields');
}

// Validate data types
$quantity = floatval($item['quantity']);
$unitCost = floatval($item['unit_cost']);

// Validate business rules
if ($transferQuantity > $availableStock) {
    throw new Exception('Insufficient stock');
}
```

---

## Integration with Frontend

### Purchase Orders Module

**Create PO Button Handler**:
```javascript
async function createPurchaseOrder(formData) {
    try {
        const response = await fetch('api/workflow-processor.php?action=create_purchase_order', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            toast.show(result.message, 'success');
            // Refresh PO list
            await loadPOs();
        } else {
            toast.show(result.error, 'error');
        }
    } catch (error) {
        toast.show('Network error: ' + error.message, 'error');
    }
}
```

### Receiving Module

**Receive Items Handler**:
```javascript
async function receiveItems(poId, receivedItems) {
    const response = await fetch('api/workflow-processor.php?action=receive_items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            po_id: poId,
            items: receivedItems,
            notes: document.getElementById('receivingNotes').value
        })
    });
    
    const result = await response.json();
    
    if (result.success) {
        modal.close();
        toast.show(result.message, 'success');
        // Navigate to POR module
        navigateTo('por');
    }
}
```

### POR Module

**Create POR with Stock Update**:
```javascript
async function createPORWithStockUpdate(receivingId) {
    // Show confirmation dialog
    const confirmed = await confirmDialog(
        'Create Proof of Receiving',
        'This will automatically update inventory stock levels. Continue?'
    );
    
    if (!confirmed) return;
    
    const response = await fetch('api/workflow-processor.php?action=create_por_with_stock_update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            receiving_id: receivingId,
            remarks: document.getElementById('porRemarks').value
        })
    });
    
    const result = await response.json();
    
    if (result.success) {
        // Show success with inventory update confirmation
        toast.show('✓ ' + result.message + ' Inventory levels updated!', 'success', 5000);
        // Refresh both POR list and inventory dashboard
        await Promise.all([
            loadPORList(),
            updateInventoryDashboard()
        ]);
    }
}
```

### Stock Transfer Module

**Verify Transfer with Photo**:
```javascript
async function verifyTransferArrival(transferId, photoFile) {
    // Convert photo to base64
    const base64Photo = await convertFileToBase64(photoFile);
    
    const response = await fetch('api/workflow-processor.php?action=verify_transfer_arrival', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            transfer_id: transferId,
            verification_photo: base64Photo
        })
    });
    
    const result = await response.json();
    
    if (result.success) {
        toast.show(result.message, 'success');
        // Update transfer list and inventory counts
        await loadTransfers();
    }
}

// Helper function
async function convertFileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}
```

---

## Testing & Verification

### 1. Test Purchase Order Flow

```bash
# Terminal 1: Watch database changes
mysql -u root u479471141_ramyum_db2
SELECT * FROM purchase_orders ORDER BY created_at DESC LIMIT 1\G
SELECT * FROM security_logs WHERE event_type LIKE 'PO%' ORDER BY created_at DESC LIMIT 5;
```

```javascript
// Test script
const testPO = {
    supplier_id: 's1',
    expected_date: '2026-10-15',
    items: [
        { product_id: 'p1', quantity: 50 },
        { product_id: 'p2', quantity: 30 }
    ],
    notes: 'Test order'
};

fetch('api/workflow-processor.php?action=create_purchase_order', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(testPO)
}).then(r => r.json()).then(console.log);
```

### 2. Test Stock Update Integrity

```sql
-- Before POR creation
SELECT 
    p.id,
    JSON_UNQUOTE(JSON_EXTRACT(p.data, '$.productName')) as product,
    JSON_UNQUOTE(JSON_EXTRACT(p.data, '$.stock')) as stock_before
FROM products p
WHERE id IN ('p1', 'p2');

-- Create POR via API

-- After POR creation
SELECT 
    p.id,
    JSON_UNQUOTE(JSON_EXTRACT(p.data, '$.productName')) as product,
    JSON_UNQUOTE(JSON_EXTRACT(p.data, '$.stock')) as stock_after,
    JSON_UNQUOTE(JSON_EXTRACT(p.data, '$.status')) as status
FROM products p
WHERE id IN ('p1', 'p2');

-- Verify inventory movements logged
SELECT 
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.productName')) as product,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.type')) as movement_type,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.quantity')) as quantity,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.referenceId')) as reference,
    created_at
FROM inventory_movements
ORDER BY created_at DESC
LIMIT 5;
```

### 3. Test Transaction Rollback

```php
// Test script: test-rollback.php
<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

$db = getDB();

try {
    $db->beginTransaction();
    
    // Get product stock
    $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute(['p1']);
    $product = $stmt->fetch();
    $data = json_decode($product['data'], true);
    
    echo "Stock before: {$data['stock']}\n";
    
    // Update stock
    $data['stock'] += 100;
    $stmt = $db->prepare("UPDATE products SET data = ? WHERE id = ?");
    $stmt->execute([json_encode($data), 'p1']);
    
    echo "Stock updated to: {$data['stock']}\n";
    
    // Simulate error
    throw new Exception("Simulated error - testing rollback");
    
    $db->commit();
    
} catch (Exception $e) {
    $db->rollBack();
    echo "Error: {$e->getMessage()}\n";
    echo "Transaction rolled back!\n";
    
    // Verify stock unchanged
    $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute(['p1']);
    $product = $stmt->fetch();
    $data = json_decode($product['data'], true);
    
    echo "Stock after rollback: {$data['stock']}\n";
}
```

---

## Troubleshooting

### Common Issues

**1. "Transaction already started"**
```php
// Solution: Check for nested transactions
if (!$db->inTransaction()) {
    $db->beginTransaction();
}
```

**2. "Column not found" errors**
```php
// Solution: JSON columns require JSON_EXTRACT
// ❌ Wrong
WHERE status = 'Pending'

// ✅ Correct
WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) = 'Pending'
```

**3. "Insufficient stock" validation failing**
```php
// Solution: Ensure stock is float, not string
$currentStock = floatval($productData['stock'] ?? 0);
$requestedQty = floatval($input['quantity']);
```

**4. Photo upload failing**
```php
// Solution: Check upload directory permissions
chmod 0777 uploads/transfer-verifications/
```

---

## Database Maintenance

### Regular Cleanup

```sql
-- Archive old audit logs (keep last 6 months)
DELETE FROM security_logs 
WHERE created_at < DATE_SUB(NOW(), INTERVAL 6 MONTH);

-- Reindex tables
OPTIMIZE TABLE purchase_orders;
OPTIMIZE TABLE inventory_movements;
OPTIMIZE TABLE proof_of_receiving;
```

### Backup Strategy

```bash
# Daily backup
mysqldump -u root u479471141_ramyum_db2 > backup_$(date +%Y%m%d).sql

# Backup specific tables
mysqldump -u root u479471141_ramyum_db2 \
    purchase_orders receivings proof_of_receiving \
    inventory_movements > critical_tables_$(date +%Y%m%d).sql
```

---

## Performance Optimization

### 1. Index Critical Columns

```sql
-- Add indexes for JSON searches
ALTER TABLE purchase_orders 
ADD INDEX idx_po_status ((JSON_UNQUOTE(JSON_EXTRACT(data, '$.status'))));

ALTER TABLE products
ADD INDEX idx_product_stock ((JSON_UNQUOTE(JSON_EXTRACT(data, '$.stock'))));
```

### 2. Query Optimization

```php
// ❌ Slow - Multiple queries
foreach ($items as $item) {
    $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$item['product_id']]);
}

// ✅ Fast - Single query
$ids = array_column($items, 'product_id');
$placeholders = str_repeat('?,', count($ids) - 1) . '?';
$stmt = $db->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
$stmt->execute($ids);
```

---

## Next Steps

1. ✅ Review this implementation guide
2. ✅ Test each endpoint using the provided examples
3. ✅ Integrate with your frontend modules
4. ✅ Configure backup schedule
5. ✅ Set up monitoring and alerts
6. ✅ Train staff on the new workflow
7. ✅ Go live!

---

## Support & Documentation

- **System Documentation**: `README.md`
- **Database Schema**: `database/schema.sql`
- **API Reference**: This document
- **Security Guide**: `SECURITY_FIXES_SUMMARY.md`
- **Audit Reports**: `FINAL_SYSTEM_AUDIT_REPORT.md`

---

**© 2026 RAM-YUM Korean & Japanese Store**  
**Backend Implementation v2.0**
