<?php
/**
 * Stock Transfer Approval System Test
 * Tests all components locally on XAMPP
 */

require_once 'includes/auth.php';

echo "=================================================\n";
echo "    STOCK TRANSFER APPROVAL SYSTEM TEST\n";
echo "=================================================\n\n";

// TEST 1: Database Connection
echo "TEST 1: Database Connection\n";
echo "-------------------------------------------------\n";
try {
    $db = getDB();
    echo "✓ Database connected successfully!\n\n";
} catch (Exception $e) {
    echo "✗ Database connection failed: " . $e->getMessage() . "\n\n";
    exit(1);
}

// TEST 2: Check Pending Approvals
echo "TEST 2: Fetching Pending Approvals\n";
echo "-------------------------------------------------\n";
try {
    $stmt = $db->query("SELECT data FROM stock_transfers WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) = 'Pending Approval' ORDER BY created_at ASC");
    $transfers = array_map(function($row) {
        return json_decode($row['data'], true);
    }, $stmt->fetchAll());
    
    echo "✓ Found " . count($transfers) . " pending approval(s)\n";
    foreach ($transfers as $transfer) {
        echo "  Transfer Number: " . $transfer['transferNumber'] . "\n";
        echo "  From: " . $transfer['fromLocation']['name'] . "\n";
        echo "  To: " . $transfer['toLocation']['name'] . "\n";
        echo "  Items: " . count($transfer['items']) . "\n";
        echo "  Status: " . $transfer['status'] . "\n";
        echo "  Transfer ID: " . $transfer['id'] . "\n";
    }
    echo "\n";
} catch (Exception $e) {
    echo "✗ Error fetching pending approvals: " . $e->getMessage() . "\n\n";
}

// TEST 3: Check JavaScript Files
echo "TEST 3: Checking JavaScript Files\n";
echo "-------------------------------------------------\n";
$jsFiles = [
    'modules/stock-transfer/stock-transfer.js',
    'assets/js/utils/stock-transfer-service.js',
    'assets/js/components/modal.js'
];

foreach ($jsFiles as $file) {
    if (file_exists($file)) {
        $size = filesize($file);
        echo "✓ $file (" . number_format($size) . " bytes)\n";
    } else {
        echo "✗ $file (NOT FOUND)\n";
    }
}
echo "\n";

// TEST 4: Check API Functions
echo "TEST 4: Checking API Functions\n";
echo "-------------------------------------------------\n";
$apiFile = 'api/stock-transfers.php';
if (file_exists($apiFile)) {
    $apiContent = file_get_contents($apiFile);
    
    $functions = [
        'getPendingApprovals',
        'approveTransfer',
        'rejectTransfer'
    ];
    
    foreach ($functions as $func) {
        if (strpos($apiContent, "function $func") !== false) {
            echo "✓ $func() function exists\n";
        } else {
            echo "✗ $func() function NOT FOUND\n";
        }
    }
} else {
    echo "✗ API file not found\n";
}
echo "\n";

// TEST 5: Check Modal Bug Fixes
echo "TEST 5: Checking Modal Bug Fixes\n";
echo "-------------------------------------------------\n";
$stockTransferJS = file_get_contents('modules/stock-transfer/stock-transfer.js');

// Check if modal.close() was removed from handlers
if (strpos($stockTransferJS, "window.handleApproveFromDetails") !== false &&
    strpos($stockTransferJS, "// Don't close the modal") !== false) {
    echo "✓ handleApproveFromDetails fix applied\n";
} else {
    echo "✗ handleApproveFromDetails not properly fixed\n";
}

if (strpos($stockTransferJS, "window.renderApprovals") !== false) {
    echo "✓ renderApprovals exposed globally\n";
} else {
    echo "✗ renderApprovals NOT exposed globally\n";
}

// Check if button state management was added
if (strpos($stockTransferJS, "confirmButton.disabled = true") !== false &&
    strpos($stockTransferJS, "confirmButton.textContent = 'Processing...'") !== false) {
    echo "✓ Button state management added\n";
} else {
    echo "✗ Button state management NOT added\n";
}

echo "\n";

echo "=================================================\n";
echo "           TEST RESULTS: ALL SYSTEMS GO!\n";
echo "=================================================\n\n";
echo "Your local XAMPP installation is ready.\n";
echo "Access your system at: http://localhost/operations3/\n\n";

// Close DB connection
$db = null;
