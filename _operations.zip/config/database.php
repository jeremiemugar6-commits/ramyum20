<?php
date_default_timezone_set('Asia/Manila');   // or 'UTC' — pick one and stick with it

// =====================================================================
// CENTRALIZED DATABASE CONFIGURATION
// Database: ram_yum_inventory (consolidated from ramyum_db)
// =====================================================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'u479471141_ramyum_db2');
define('DB_USER', 'u479471141_jeremie');
define('DB_PASS', 'Hajirol.182004');
define('DB_CHARSET', 'utf8mb4');

define('OTP_DEMO_MODE', true);

// Load environment variables from .env file
function loadEnv($path = __DIR__ . '/../.env') {
    if (!file_exists($path)) {
        return;
    }
    
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) {
            continue;
        }
        
        list($name, $value) = explode('=', $line, 2);
        $name = trim($name);
        $value = trim($value);
        
        if (!array_key_exists($name, $_ENV)) {
            $_ENV[$name] = $value;
        }
    }
}

// Load environment variables
loadEnv();

// Demo Integration Mode Configuration
define('DEMO_INTEGRATION_MODE', filter_var($_ENV['DEMO_INTEGRATION_MODE'] ?? 'false', FILTER_VALIDATE_BOOLEAN));
define('DEMO_MODE_MESSAGE', $_ENV['DEMO_MODE_MESSAGE'] ?? 'Local demonstration mode is active.');

function getDB(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;

        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }

    return $pdo;
}

/**
 * Alias for getDB() function for backward compatibility
 * Some legacy files call this function instead of getDB()
 */
function get_database_connection(): PDO
{
    return getDB();
}

/** Alias used by damage-evidence and other endpoints */
function getDBConnection(): PDO
{
    return getDB();
}

/**
 * Get demo integration configuration for frontend
 */
function getDemoConfig(): array
{
    return [
        'demoMode' => DEMO_INTEGRATION_MODE,
        'demoMessage' => DEMO_MODE_MESSAGE
    ];
}