<?php
/**
 * One-time repair: POR showing "Pending" even though it Passed.
 *
 * Runs database/fix-por-inspection-status.sql (widens the enum columns and
 * recomputes the real inspection result of rows that were saved blank).
 * Admin only. Safe to run more than once.
 *
 * Open once in the browser while logged in as admin:
 *   /fix-por-inspection-status.php          -> preview (changes nothing)
 *   /fix-por-inspection-status.php?run=1    -> apply
 * Delete this file afterwards.
 */
require_once __DIR__ . '/includes/auth.php';

$user = require_login_page();
if (($user['role'] ?? '') !== 'admin') {
    http_response_code(403);
    exit('Administrator access required.');
}

$db = getDB();
$run = isset($_GET['run']) && $_GET['run'] === '1';

function por_status_table(PDO $db): string
{
    $rows = $db->query("
        SELECT por_number, status,
               IF(inspection_status + 0 = 0, '(blank)', inspection_status) AS inspection_status,
               total_received, total_accepted, total_rejected
        FROM proof_of_receiving ORDER BY created_at DESC LIMIT 100
    ")->fetchAll(PDO::FETCH_ASSOC);
    if (!$rows) {
        return '<p>No POR records.</p>';
    }
    $html = '<table border="1" cellpadding="6" style="border-collapse:collapse"><tr>';
    foreach (array_keys($rows[0]) as $h) {
        $html .= '<th>' . htmlspecialchars($h) . '</th>';
    }
    $html .= '</tr>';
    foreach ($rows as $r) {
        $html .= '<tr>';
        foreach ($r as $v) {
            $html .= '<td>' . htmlspecialchars((string)$v) . '</td>';
        }
        $html .= '</tr>';
    }
    return $html . '</table>';
}

echo '<h2>POR inspection status repair</h2>';
echo '<h3>Before</h3>' . por_status_table($db);

if (!$run) {
    echo '<p><a href="?run=1"><strong>Apply the fix</strong></a> (back up the database first).</p>';
    exit;
}

$sql = file_get_contents(__DIR__ . '/database/fix-por-inspection-status.sql');
$sql = preg_replace('/^\s*--.*$/m', '', $sql);       // strip comment lines
$statements = array_filter(array_map('trim', explode(';', $sql)));

echo '<h3>Running</h3><ul>';
foreach ($statements as $stmt) {
    if (stripos($stmt, 'SELECT') === 0) {
        continue; // the closing check query - shown below instead
    }
    try {
        $affected = $db->exec($stmt);
        echo '<li style="color:green">OK (' . (int)$affected . ' rows): ' . htmlspecialchars(substr(preg_replace('/\s+/', ' ', $stmt), 0, 90)) . '...</li>';
    } catch (Throwable $e) {
        echo '<li style="color:red">FAILED: ' . htmlspecialchars($e->getMessage()) . '<br><code>'
            . htmlspecialchars(substr(preg_replace('/\s+/', ' ', $stmt), 0, 120)) . '...</code></li>';
    }
}
echo '</ul><h3>After</h3>' . por_status_table($db);
echo '<p>Done. Reload the POR screen. You can delete this file now.</p>';
