<?php
/**
 * Damage Evidence API
 * Handles recording and retrieval of damage evidence during receiving
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

$currentUser = require_login_api();
$pdo = getDBConnection();

$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method === 'GET') {
        // Get damage evidence by receiving ID or PO ID
        $receivingId = $_GET['receiving_id'] ?? null;
        $poId = $_GET['po_id'] ?? null;
        
        if ($receivingId) {
            $stmt = $pdo->prepare("SELECT * FROM damage_evidence WHERE receiving_id = ? ORDER BY recorded_at DESC");
            $stmt->execute([$receivingId]);
        } elseif ($poId) {
            $stmt = $pdo->prepare("SELECT * FROM damage_evidence WHERE po_id = ? ORDER BY recorded_at DESC");
            $stmt->execute([$poId]);
        } else {
            // Get all damage evidence
            $stmt = $pdo->query("SELECT * FROM damage_evidence ORDER BY recorded_at DESC LIMIT 100");
        }
        
        $evidence = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'data' => $evidence
        ]);
        
    } elseif ($method === 'POST') {
        // Create new damage evidence record
        $input = json_decode(file_get_contents('php://input'), true);
        
        // Validate required fields
        $required = ['receiving_id', 'po_id', 'po_number', 'product_id', 'product_name', 
                     'ordered_quantity', 'received_quantity', 'damaged_quantity'];
        foreach ($required as $field) {
            if (!isset($input[$field])) {
                throw new Exception("Missing required field: {$field}");
            }
        }
        
        // Generate ID
        $id = 'dmg_' . time() . '_' . bin2hex(random_bytes(4));
        
        // Insert damage evidence
        $stmt = $pdo->prepare("
            INSERT INTO damage_evidence (
                id, receiving_id, po_id, po_number, product_id, product_name,
                ordered_quantity, received_quantity, damaged_quantity,
                damage_description, evidence_image_path, recorded_by, recorded_at,
                batch_number, expiration_date
            ) VALUES (
                :id, :receiving_id, :po_id, :po_number, :product_id, :product_name,
                :ordered_quantity, :received_quantity, :damaged_quantity,
                :damage_description, :evidence_image_path, :recorded_by, NOW(),
                :batch_number, :expiration_date
            )
        ");
        
        $stmt->execute([
            'id' => $id,
            'receiving_id' => $input['receiving_id'],
            'po_id' => $input['po_id'],
            'po_number' => $input['po_number'],
            'product_id' => $input['product_id'],
            'product_name' => $input['product_name'],
            'ordered_quantity' => $input['ordered_quantity'],
            'received_quantity' => $input['received_quantity'],
            'damaged_quantity' => $input['damaged_quantity'],
            'damage_description' => $input['damage_description'] ?? null,
            'evidence_image_path' => $input['evidence_image_path'] ?? null,
            'recorded_by' => $currentUser['username'] ?? ($currentUser['name'] ?? 'System'),
            'batch_number' => $input['batch_number'] ?? null,
            'expiration_date' => $input['expiration_date'] ?? null
        ]);
        
        // Log the action
        log_security_event('DAMAGE_RECORDED', $currentUser['id'], $currentUser['username'], [
            'damage_id' => $id,
            'po_number' => $input['po_number'],
            'product_name' => $input['product_name'],
            'damaged_quantity' => $input['damaged_quantity']
        ]);
        
        echo json_encode([
            'success' => true,
            'data' => [
                'id' => $id,
                'message' => 'Damage evidence recorded successfully'
            ]
        ]);
        
    } elseif ($method === 'PUT') {
        // Update damage evidence
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? null;
        
        if (!$id) {
            throw new Exception('Damage evidence ID is required');
        }
        
        // Build update query dynamically
        $updates = [];
        $params = ['id' => $id];
        
        $allowedFields = ['damage_description', 'evidence_image_path', 'damaged_quantity'];
        foreach ($allowedFields as $field) {
            if (isset($input[$field])) {
                $updates[] = "{$field} = :{$field}";
                $params[$field] = $input[$field];
            }
        }
        
        if (empty($updates)) {
            throw new Exception('No fields to update');
        }
        
        $sql = "UPDATE damage_evidence SET " . implode(', ', $updates) . " WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        echo json_encode([
            'success' => true,
            'message' => 'Damage evidence updated successfully'
        ]);
        
    } elseif ($method === 'DELETE') {
        // Delete damage evidence (admin only)
        if ($currentUser['role'] !== 'admin') {
            throw new Exception('Unauthorized: Admin access required');
        }
        
        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['id'] ?? null;
        
        if (!$id) {
            throw new Exception('Damage evidence ID is required');
        }
        
        // Get the evidence record to delete associated image
        $stmt = $pdo->prepare("SELECT evidence_image_path FROM damage_evidence WHERE id = ?");
        $stmt->execute([$id]);
        $evidence = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($evidence && $evidence['evidence_image_path']) {
            $imagePath = __DIR__ . '/../' . $evidence['evidence_image_path'];
            if (file_exists($imagePath)) {
                unlink($imagePath);
            }
        }
        
        // Delete the record
        $stmt = $pdo->prepare("DELETE FROM damage_evidence WHERE id = ?");
        $stmt->execute([$id]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Damage evidence deleted successfully'
        ]);
        
    } else {
        throw new Exception('Invalid request method');
    }
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
