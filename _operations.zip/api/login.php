<?php
require_once __DIR__ . '/../includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = get_json_input();
$identifier = trim($input['username'] ?? '');
$password   = (string) ($input['password'] ?? '');

if ($identifier === '' || $password === '') {
    json_error('Username/email and password are required.');
}

[$locked, $remainingMinutes] = check_lockout(strtolower($identifier));
if ($locked) {
    log_security_event('LOGIN_BLOCKED_LOCKOUT', null, $identifier);
    json_error("Too many failed attempts. Try again in {$remainingMinutes} minute(s).", 429);
}

$db = getDB();
$stmt = $db->prepare('SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1');
$stmt->execute([$identifier, $identifier]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    record_failed_login(strtolower($identifier));
    log_security_event('LOGIN_FAILED', $user['id'] ?? null, $identifier);
    json_error('Invalid username or password.', 401);
}

if (!$user['verified']) {
    json_error('This account is not yet verified. Contact an administrator.', 403);
}

// Password correct — do NOT establish the full session yet. Regenerate
// the session id (prevents fixation) and hold a pending-OTP marker only.
session_regenerate_id(true);
$_SESSION['otp_pending_user_id'] = $user['id'];
unset($_SESSION['user_id'], $_SESSION['username'], $_SESSION['role']);

clear_login_attempts(strtolower($identifier));

$otpCode = generate_and_store_otp($user['id']);
$mailed  = send_otp_email($user['email'], $user['name'], $otpCode);
log_security_event('OTP_SENT', $user['id'], $user['username'], ['mailed' => $mailed]);

$response = [
    'success'     => true,
    'requiresOtp' => true,
    'maskedEmail' => mask_email($user['email']),
];

// DEMO_MODE (config/database.php) surfaces the code directly for local/
// capstone demos where outbound SMTP isn't configured on shared hosting.
if (defined('OTP_DEMO_MODE') && OTP_DEMO_MODE === true) {
    $response['debugCode'] = $otpCode;
}

json_response($response);
