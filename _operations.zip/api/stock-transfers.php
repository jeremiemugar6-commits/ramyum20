<?php
/**
 * Stock Transfer API Endpoints
 * Handles stock transfer operations, approvals, and workflow management
 */

// Start output buffering to catch any stray output
ob_start();

// Suppress PHP warnings/notices in output (still logged)
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

require_once __DIR__ . '/../includes/auth.php';

// Clean any buffered output before setting header
ob_clean();

// Set JSON header first to ensure any errors are also JSON
header('Content-Type: application/json');

$currentUser = require_login_api();

$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// Role-based access control
$userRole = $currentUser['role'] ?? 'staff';
$canApprove = $userRole === 'admin' || $userRole === 'manager';

try {
    switch ($method) {
        case 'GET':
            handleGet($db, $action, $userRole, $currentUser);
            break;
        case 'POST':
            handlePost($db, $action, $userRole, $currentUser);
            break;
        case 'PUT':
            handlePut($db, $action, $userRole, $currentUser);
            break;
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
} catch (Exception $e) {
    // Clean buffer before sending error
    ob_clean();
    http_response_code(500);
    error_log('Stock Transfer API Error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
} finally {
    // Flush and end output buffering
    ob_end_flush();
}

function handleGet($db, $action, $userRole, $currentUser) {
    // Recalculate canApprove inside this function scope
    $canApprove = $userRole === 'admin' || $userRole === 'manager';
    
    switch ($action) {
        case 'transfers':
            getTransfers($db, $userRole, $currentUser);
            break;
        case 'locations':
            getLocations($db);
            break;
        case 'inventory':
            getInventoryByLocation($db, $_GET['locationId'] ?? '');
            break;
        case 'transfer':
            getTransferById($db, $_GET['id'] ?? '');
            break;
        case 'pending-approvals':
            if (!$canApprove) {
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Access denied']);
                return;
            }
            getPendingApprovals($db);
            break;
        case 'audit-log':
            getAuditLog($db, $_GET['transferId'] ?? '');
            break;
        case 'qr-token':
            getQRToken($db, $_GET['id'] ?? '');
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

function handlePost($db, $action, $userRole, $currentUser) {
    switch ($action) {
        case 'create':
            createTransfer($db, $currentUser);
            break;
        case 'approve':
            if (!($userRole === 'admin' || $userRole === 'manager')) {
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Access denied']);
                return;
            }
            approveTransfer($db, $currentUser);
            break;
        case 'reject':
            if (!($userRole === 'admin' || $userRole === 'manager')) {
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Access denied']);
                return;
            }
            rejectTransfer($db, $currentUser);
            break;
        case 'generate-qr':
            generateQRCode($db, $currentUser);
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

function handlePut($db, $action, $userRole, $currentUser) {
    switch ($action) {
        case 'update':
            updateTransfer($db, $currentUser);
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

function getTransfers($db, $userRole, $currentUser) {
    try {
        // Staff can only see their own transfers, admin/manager can see all
        if ($userRole === 'staff') {
            $stmt = $db->prepare("SELECT data FROM stock_transfers WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.requestedBy')) = ? ORDER BY created_at DESC");
            $stmt->execute([$currentUser['id']]);
        } else {
            $stmt = $db->query("SELECT data FROM stock_transfers ORDER BY created_at DESC");
        }
        
        $transfers = array_map(function($row) {
            return normalizeTransfer(json_decode($row['data'], true));
        }, $stmt->fetchAll());

        echo json_encode(['success' => true, 'data' => $transfers]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch transfers: ' . $e->getMessage());
    }
}

function getLocations($db) {
    try {
        // Debug: Check if locations table exists
        $checkTable = $db->query("SHOW TABLES LIKE 'locations'")->fetch();
        if (!$checkTable) {
            throw new Exception('Locations table does not exist. Please run database setup.');
        }

        $stmt = $db->query("SELECT data FROM locations WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) = 'Active' ORDER BY JSON_UNQUOTE(JSON_EXTRACT(data, '$.name'))");
        $locations = array_map(function($row) {
            return json_decode($row['data'], true);
        }, $stmt->fetchAll());

        // Debug: Log what we found
        error_log('Stock Transfer API - Found ' . count($locations) . ' locations');
        
        echo json_encode(['success' => true, 'data' => $locations, 'count' => count($locations)]);
    } catch (Exception $e) {
        error_log('Stock Transfer API - getLocations error: ' . $e->getMessage());
        throw new Exception('Failed to fetch locations: ' . $e->getMessage());
    }
}

function getInventoryByLocation($db, $locationId) {
    if (empty($locationId)) {
        echo json_encode(['success' => false, 'error' => 'Location ID required']);
        return;
    }

    try {
        // Get inventory for specific location
        $stmt = $db->prepare("
            SELECT il.data as inventory_data, p.data as product_data 
            FROM inventory_locations il 
            JOIN products p ON JSON_UNQUOTE(JSON_EXTRACT(il.data, '$.productId')) = p.id
            WHERE JSON_UNQUOTE(JSON_EXTRACT(il.data, '$.locationId')) = ?
        ");
        $stmt->execute([$locationId]);
        $results = $stmt->fetchAll();

        $inventory = array_map(function($row) {
            $inventoryData = json_decode($row['inventory_data'], true);
            $productData = json_decode($row['product_data'], true);
            
            return [
                'productId' => $inventoryData['productId'],
                'productName' => $productData['name'],
                'sku' => $productData['sku'],
                'category' => $productData['category'],
                'quantity' => $inventoryData['quantity'],
                'availableQuantity' => $inventoryData['availableQuantity'],
                'reservedQuantity' => $inventoryData['reservedQuantity'] ?? 0,
                'unit' => 'pcs' // Default unit
            ];
        }, $results);

        echo json_encode(['success' => true, 'data' => $inventory]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch inventory: ' . $e->getMessage());
    }
}

function getTransferById($db, $transferId) {
    if (empty($transferId)) {
        echo json_encode(['success' => false, 'error' => 'Transfer ID required']);
        return;
    }

    try {
        $stmt = $db->prepare("SELECT data FROM stock_transfers WHERE id = ?");
        $stmt->execute([$transferId]);
        $result = $stmt->fetch();

        if (!$result) {
            echo json_encode(['success' => false, 'error' => 'Transfer not found']);
            return;
        }

        $transfer = normalizeTransfer(json_decode($result['data'], true));
        echo json_encode(['success' => true, 'data' => $transfer]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch transfer: ' . $e->getMessage());
    }
}

function getPendingApprovals($db) {
    try {
        $stmt = $db->query("SELECT data FROM stock_transfers WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) = 'Pending Approval' ORDER BY created_at ASC");
        $transfers = array_map(function($row) {
            return normalizeTransfer(json_decode($row['data'], true));
        }, $stmt->fetchAll());

        echo json_encode(['success' => true, 'data' => $transfers]);
    } catch (Exception $e) {
        error_log('Failed to fetch pending approvals: ' . $e->getMessage());
        echo json_encode(['success' => false, 'error' => 'Failed to fetch pending approvals: ' . $e->getMessage()]);
    }
}

function createTransfer($db, $currentUser) {
    $input = get_json_input();
    
    // Validation
    $required = ['sourceLocationId', 'destinationLocationId', 'items'];
    foreach ($required as $field) {
        if (empty($input[$field])) {
            echo json_encode(['success' => false, 'error' => "Field '$field' is required"]);
            return;
        }
    }

    if ($input['sourceLocationId'] === $input['destinationLocationId']) {
        echo json_encode(['success' => false, 'error' => 'Source and destination cannot be the same']);
        return;
    }

    if (empty($input['items']) || !is_array($input['items'])) {
        echo json_encode(['success' => false, 'error' => 'At least one item is required']);
        return;
    }

    try {
        $db->beginTransaction();

        // Generate transfer number
        $transferNumber = generateTransferNumber($db);
        
        // Get location names
        $sourceLocation = getLocationById($db, $input['sourceLocationId']);
        $destinationLocation = getLocationById($db, $input['destinationLocationId']);
        
        assertLocationUsable($sourceLocation, 'source');
        assertLocationUsable($destinationLocation, 'destination');

        // Validate inventory availability and build clean item records from the
        // database (never trust names/SKUs sent by the browser)
        $cleanItems = [];
        foreach ($input['items'] as $item) {
            $qty = (float)($item['quantity'] ?? 0);
            if ($qty <= 0) {
                throw new Exception('Transfer quantity must be greater than 0');
            }

            $product = getProductById($db, $item['productId'] ?? '');
            if (!$product) {
                throw new Exception('Product not found: ' . ($item['productId'] ?? ''));
            }

            $available = getAvailableInventory($db, $item['productId'], $input['sourceLocationId']);
            if ($available < $qty) {
                throw new Exception("Insufficient stock for {$product['name']} at {$sourceLocation['name']}. Available: $available, Requested: $qty");
            }

            $cleanItems[] = [
                'productId'   => $item['productId'],
                'productName' => $product['name'],
                'sku'         => $product['sku'] ?? '',
                'quantity'    => $qty,
                'unit'        => $product['unit'] ?? 'pcs',
                'sourceStock' => $available
            ];
        }
        $input['items'] = $cleanItems;

        // Create transfer record
        $transferId = generate_id('st');
        $transferData = [
            'id' => $transferId,
            'transferNumber' => $transferNumber,
            'transferDate' => date('Y-m-d'),
            'sourceLocationId' => $input['sourceLocationId'],
            'sourceLocationName' => $sourceLocation['name'],
            'destinationLocationId' => $input['destinationLocationId'],
            'destinationLocationName' => $destinationLocation['name'],
            'requestedBy' => $currentUser['id'],
            'requestedByName' => $currentUser['name'],
            'status' => 'Pending Approval',
            'remarks' => $input['remarks'] ?? '',
            'items' => $input['items'],
            'totalItems' => array_sum(array_column($input['items'], 'quantity')),
            'createdAt' => gmdate('Y-m-d\TH:i:s.v\Z'),
            'submittedAt' => gmdate('Y-m-d\TH:i:s.v\Z')
        ];

        $stmt = $db->prepare("INSERT INTO stock_transfers (id, data) VALUES (?, ?)");
        $stmt->execute([$transferId, json_encode($transferData)]);

        // Log audit trail
        logAuditEvent($db, $transferId, 'TRANSFER_CREATED', $currentUser, [
            'transferNumber' => $transferNumber,
            'sourceLocation' => $sourceLocation['name'],
            'destinationLocation' => $destinationLocation['name'],
            'itemCount' => count($input['items'])
        ]);

        logAuditEvent($db, $transferId, 'TRANSFER_SUBMITTED', $currentUser, [
            'transferNumber' => $transferNumber,
            'status' => 'Pending Approval'
        ]);

        $db->commit();

        echo json_encode([
            'success' => true, 
            'data' => $transferData,
            'message' => "Stock transfer $transferNumber has been submitted for approval"
        ]);

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

function approveTransfer($db, $currentUser) {
    $input = get_json_input();
    $transferId = $input['transferId'] ?? '';
    $approvalRemarks = $input['approvalRemarks'] ?? '';

    // Tolerate a full transfer object being sent instead of just the ID
    if (is_array($transferId)) {
        $transferId = $transferId['id'] ?? '';
    }

    if (empty($transferId) || !is_string($transferId)) {
        echo json_encode(['success' => false, 'error' => 'Transfer ID required']);
        return;
    }

    try {
        $db->beginTransaction();

        // Get current transfer
        $stmt = $db->prepare("SELECT data FROM stock_transfers WHERE id = ?");
        $stmt->execute([$transferId]);
        $result = $stmt->fetch();
        
        if (!$result) {
            throw new Exception('Transfer not found');
        }

        $transfer = json_decode($result['data'], true);
        
        if ($transfer['status'] !== 'Pending Approval') {
            throw new Exception('Transfer is not pending approval');
        }

        // Both locations must still exist and be active
        assertLocationUsable(getLocationById($db, $transfer['sourceLocationId']), 'source');
        assertLocationUsable(getLocationById($db, $transfer['destinationLocationId']), 'destination');

        // Verify inventory availability again
        foreach ($transfer['items'] as $item) {
            $available = getAvailableInventory($db, $item['productId'], $transfer['sourceLocationId']);
            if ($available < $item['quantity']) {
                $productName = getProductName($db, $item['productId']);
                throw new Exception("Insufficient stock for $productName. Available: $available, Requested: {$item['quantity']}");
            }
        }

        // Update inventory for each item
        foreach ($transfer['items'] as $item) {
            updateInventoryForTransfer($db, $item, $transfer, $currentUser);
        }

        // Update transfer status
        $transfer['status'] = 'Approved';
        $transfer['approvedBy'] = $currentUser['id'];
        $transfer['approvedByName'] = $currentUser['name'];
        $transfer['approvedAt'] = gmdate('Y-m-d\TH:i:s.v\Z');
        $transfer['approvalRemarks'] = $approvalRemarks;

        $updateStmt = $db->prepare("UPDATE stock_transfers SET data = ? WHERE id = ?");
        $updateStmt->execute([json_encode($transfer), $transferId]);

        // Log audit trail
        logAuditEvent($db, $transferId, 'TRANSFER_APPROVED', $currentUser, [
            'transferNumber' => $transfer['transferNumber'],
            'status' => 'Approved',
            'approvalRemarks' => $approvalRemarks
        ]);

        $db->commit();

        echo json_encode([
            'success' => true,
            'data' => $transfer,
            'message' => "Transfer {$transfer['transferNumber']} approved successfully"
        ]);

    } catch (Exception $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log('Error approving transfer: ' . $e->getMessage());
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

function rejectTransfer($db, $currentUser) {
    $input = get_json_input();
    $transferId = $input['transferId'] ?? '';
    $rejectionReason = $input['rejectionReason'] ?? '';

    // Tolerate a full transfer object being sent instead of just the ID
    if (is_array($transferId)) {
        $transferId = $transferId['id'] ?? '';
    }

    if (empty($transferId) || !is_string($transferId)) {
        echo json_encode(['success' => false, 'error' => 'Transfer ID required']);
        return;
    }

    if (empty($rejectionReason)) {
        echo json_encode(['success' => false, 'error' => 'Rejection reason is required']);
        return;
    }

    try {
        $db->beginTransaction();

        // Get current transfer
        $stmt = $db->prepare("SELECT data FROM stock_transfers WHERE id = ?");
        $stmt->execute([$transferId]);
        $result = $stmt->fetch();
        
        if (!$result) {
            throw new Exception('Transfer not found');
        }

        $transfer = json_decode($result['data'], true);
        
        if ($transfer['status'] !== 'Pending Approval') {
            throw new Exception('Transfer is not pending approval');
        }

        // Update transfer status
        $transfer['status'] = 'Rejected';
        $transfer['rejectedBy'] = $currentUser['id'];
        $transfer['rejectedByName'] = $currentUser['name'];
        $transfer['rejectedAt'] = gmdate('Y-m-d\TH:i:s.v\Z');
        $transfer['rejectionReason'] = $rejectionReason;

        $updateStmt = $db->prepare("UPDATE stock_transfers SET data = ? WHERE id = ?");
        $updateStmt->execute([json_encode($transfer), $transferId]);

        // Log audit trail
        logAuditEvent($db, $transferId, 'TRANSFER_REJECTED', $currentUser, [
            'transferNumber' => $transfer['transferNumber'],
            'status' => 'Rejected',
            'rejectionReason' => $rejectionReason
        ]);

        $db->commit();

        echo json_encode([
            'success' => true,
            'data' => $transfer,
            'message' => "Transfer {$transfer['transferNumber']} rejected"
        ]);

    } catch (Exception $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log('Error rejecting transfer: ' . $e->getMessage());
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}

// Helper functions

function generateTransferNumber($db) {
    $currentYear = date('Y');
    $stmt = $db->prepare("SELECT data FROM stock_transfers WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.transferNumber')) LIKE ?");
    $stmt->execute(["ST-$currentYear-%"]);
    $results = $stmt->fetchAll();
    
    $maxNumber = 0;
    foreach ($results as $row) {
        $data = json_decode($row['data'], true);
        if (preg_match("/ST-$currentYear-(\d{4})/", $data['transferNumber'], $matches)) {
            $maxNumber = max($maxNumber, intval($matches[1]));
        }
    }
    
    $nextNumber = str_pad($maxNumber + 1, 4, '0', STR_PAD_LEFT);
    return "ST-$currentYear-$nextNumber";
}


/**
 * Older transfers saved product names scraped from page text (with newlines,
 * "SKU: ... | Available: ..." etc). Reduce to the clean first line.
 */
function cleanProductText($text) {
    $text = (string)$text;
    $lines = preg_split('/\R/', $text);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line !== '') { return $line; }
    }
    return '';
}

function normalizeTransfer($transfer) {
    if (!is_array($transfer)) { return $transfer; }
    if (!empty($transfer['items']) && is_array($transfer['items'])) {
        foreach ($transfer['items'] as &$item) {
            if (isset($item['productName'])) {
                $item['productName'] = cleanProductText($item['productName']);
            }
        }
        unset($item);
    }
    return $transfer;
}

function getProductById($db, $productId) {
    $stmt = $db->prepare("SELECT data FROM products WHERE id = ?");
    $stmt->execute([$productId]);
    $row = $stmt->fetch();
    return $row ? json_decode($row['data'], true) : null;
}

function assertLocationUsable($location, $label) {
    if (!$location) {
        throw new Exception("Invalid $label location");
    }
    if (($location['status'] ?? 'Active') !== 'Active') {
        throw new Exception(($location['name'] ?? $label) . " is not an active location. Choose an active location.");
    }
}

function getLocationById($db, $locationId) {
    $stmt = $db->prepare("SELECT data FROM locations WHERE id = ?");
    $stmt->execute([$locationId]);
    $result = $stmt->fetch();
    return $result ? json_decode($result['data'], true) : null;
}

function getAvailableInventory($db, $productId, $locationId) {
    $stmt = $db->prepare("
        SELECT JSON_UNQUOTE(JSON_EXTRACT(data, '$.availableQuantity')) as available 
        FROM inventory_locations 
        WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.productId')) = ? 
        AND JSON_UNQUOTE(JSON_EXTRACT(data, '$.locationId')) = ?
    ");
    $stmt->execute([$productId, $locationId]);
    $result = $stmt->fetch();
    return $result ? floatval($result['available']) : 0;
}

function getProductName($db, $productId) {
    $stmt = $db->prepare("SELECT JSON_UNQUOTE(JSON_EXTRACT(data, '$.name')) as name FROM products WHERE id = ?");
    $stmt->execute([$productId]);
    $result = $stmt->fetch();
    return $result ? $result['name'] : 'Unknown Product';
}

function updateInventoryForTransfer($db, $item, $transfer, $currentUser) {
    $productId = $item['productId'];
    $quantity = $item['quantity'];
    $sourceLocationId = $transfer['sourceLocationId'];
    $destinationLocationId = $transfer['destinationLocationId'];

    // Update source location (reduce stock)
    $sourceStmt = $db->prepare("
        SELECT id, data FROM inventory_locations 
        WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.productId')) = ? 
        AND JSON_UNQUOTE(JSON_EXTRACT(data, '$.locationId')) = ?
    ");
    $sourceStmt->execute([$productId, $sourceLocationId]);
    $sourceResult = $sourceStmt->fetch();
    
    if ($sourceResult) {
        $sourceData = json_decode($sourceResult['data'], true);
        $sourceData['quantity'] -= $quantity;
        $sourceData['availableQuantity'] -= $quantity;
        $sourceData['lastUpdated'] = gmdate('Y-m-d\TH:i:s.v\Z');
        
        $updateSourceStmt = $db->prepare("UPDATE inventory_locations SET data = ? WHERE id = ?");
        $updateSourceStmt->execute([json_encode($sourceData), $sourceResult['id']]);
    }

    // Update destination location (add stock)
    $destStmt = $db->prepare("
        SELECT id, data FROM inventory_locations 
        WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.productId')) = ? 
        AND JSON_UNQUOTE(JSON_EXTRACT(data, '$.locationId')) = ?
    ");
    $destStmt->execute([$productId, $destinationLocationId]);
    $destResult = $destStmt->fetch();
    
    if ($destResult) {
        // Update existing inventory
        $destData = json_decode($destResult['data'], true);
        $destData['quantity'] += $quantity;
        $destData['availableQuantity'] += $quantity;
        $destData['lastUpdated'] = gmdate('Y-m-d\TH:i:s.v\Z');
        
        $updateDestStmt = $db->prepare("UPDATE inventory_locations SET data = ? WHERE id = ?");
        $updateDestStmt->execute([json_encode($destData), $destResult['id']]);
    } else {
        // Create new inventory record
        $newId = generate_id('inv');
        $newData = [
            'id' => $newId,
            'productId' => $productId,
            'locationId' => $destinationLocationId,
            'quantity' => $quantity,
            'reservedQuantity' => 0,
            'availableQuantity' => $quantity,
            'lastUpdated' => gmdate('Y-m-d\TH:i:s.v\Z')
        ];
        
        $insertDestStmt = $db->prepare("INSERT INTO inventory_locations (id, data) VALUES (?, ?)");
        $insertDestStmt->execute([$newId, json_encode($newData)]);
    }

    // Create inventory movement records
    createInventoryMovement($db, $item, $transfer, $currentUser, 'out');
    createInventoryMovement($db, $item, $transfer, $currentUser, 'in');
}

function createInventoryMovement($db, $item, $transfer, $currentUser, $direction) {
    $locationId = $direction === 'out' ? $transfer['sourceLocationId'] : $transfer['destinationLocationId'];
    $locationName = $direction === 'out' ? $transfer['sourceLocationName'] : $transfer['destinationLocationName'];
    $quantity = $direction === 'out' ? -$item['quantity'] : $item['quantity'];
    $movementType = $direction === 'out' ? 'Stock Out' : 'Stock In';
    
    $movementId = generate_id('mov');
    $movementData = [
        'id' => $movementId,
        'productId' => $item['productId'],
        'productName' => $item['productName'],
        'locationId' => $locationId,
        'locationName' => $locationName,
        'movementType' => $movementType,
        'quantity' => $quantity,
        'referenceType' => 'STOCK_TRANSFER',
        'referenceId' => $transfer['transferNumber'],
        'performedBy' => $currentUser['id'],
        'performedByName' => $currentUser['name'],
        'reason' => "Stock Transfer - $direction",
        'notes' => "Transfer " . ($direction === 'out' ? 'from' : 'to') . " " . ($direction === 'out' ? $transfer['destinationLocationName'] : $transfer['sourceLocationName']),
        'createdAt' => gmdate('Y-m-d\TH:i:s.v\Z')
    ];

    $stmt = $db->prepare("INSERT INTO inventory_movements (id, data) VALUES (?, ?)");
    $stmt->execute([$movementId, json_encode($movementData)]);
}

function logAuditEvent($db, $transferId, $actionType, $currentUser, $details) {
    $stmt = $db->prepare("
        INSERT INTO stock_transfer_audit (transfer_id, action_type, user_id, user_name, details, ip_address) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $transferId,
        $actionType,
        $currentUser['id'],
        $currentUser['name'],
        json_encode($details),
        $_SERVER['REMOTE_ADDR'] ?? null
    ]);
}

function getAuditLog($db, $transferId) {
    if (empty($transferId)) {
        echo json_encode(['success' => true, 'data' => []]);
        return;
    }

    try {
        $stmt = $db->prepare("SELECT * FROM stock_transfer_audit WHERE transfer_id = ? ORDER BY created_at ASC");
        $stmt->execute([$transferId]);
        $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Parse JSON details
        foreach ($logs as &$log) {
            if ($log['details']) {
                $log['details'] = json_decode($log['details'], true);
            }
        }

        echo json_encode(['success' => true, 'data' => $logs]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch audit log: ' . $e->getMessage());
    }
}

function getQRToken($db, $transferId) {
    if (empty($transferId)) {
        echo json_encode(['success' => false, 'error' => 'Transfer ID required']);
        return;
    }

    try {
        // Check if POD already exists
        $stmt = $db->prepare("SELECT qr_token, status FROM proof_of_delivery WHERE transfer_id = ?");
        $stmt->execute([$transferId]);
        $pod = $stmt->fetch();

        if ($pod) {
            echo json_encode([
                'success' => true,
                'data' => [
                    'qr_token' => $pod['qr_token'],
                    'qr_url' => '/scan-pod.php?token=' . urlencode($pod['qr_token']),
                    'status' => $pod['status']
                ]
            ]);
        } else {
            echo json_encode(['success' => false, 'error' => 'QR code not generated yet']);
        }
    } catch (Exception $e) {
        throw new Exception('Failed to fetch QR token: ' . $e->getMessage());
    }
}

function generateQRCode($db, $currentUser) {
    $input = get_json_input();
    $transferId = $input['transferId'] ?? '';

    if (empty($transferId)) {
        echo json_encode(['success' => false, 'error' => 'Transfer ID required']);
        return;
    }

    try {
        $db->beginTransaction();

        // Get transfer details
        $stmt = $db->prepare("SELECT data FROM stock_transfers WHERE id = ?");
        $stmt->execute([$transferId]);
        $result = $stmt->fetch();

        if (!$result) {
            throw new Exception('Transfer not found');
        }

        $transfer = json_decode($result['data'], true);

        // Only generate QR for approved transfers
        if ($transfer['status'] !== 'Approved') {
            throw new Exception('QR code can only be generated for approved transfers');
        }

        // Check if POD already exists
        $stmt = $db->prepare("SELECT id FROM proof_of_delivery WHERE transfer_id = ?");
        $stmt->execute([$transferId]);
        if ($stmt->fetch()) {
            throw new Exception('QR code already generated for this transfer');
        }

        // Generate secure QR token
        $qrToken = 'POD-' . strtoupper(bin2hex(random_bytes(16)));
        $podId = 'pod_' . time() . '_' . bin2hex(random_bytes(4));

        // Create POD record with complete location info
        $stmt = $db->prepare("
            INSERT INTO proof_of_delivery (
                id, transfer_id, transfer_number, qr_token, 
                source_location_id, source_location_name,
                destination_location_id, destination_location_name,
                status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending')
        ");
        $stmt->execute([
            $podId,
            $transferId,
            $transfer['transferNumber'],
            $qrToken,
            $transfer['sourceLocationId'],
            $transfer['sourceLocationName'],
            $transfer['destinationLocationId'],
            $transfer['destinationLocationName']
        ]);

        // Update transfer status to In Transit
        $transfer['status'] = 'In Transit';
        $transfer['inTransitAt'] = gmdate('Y-m-d\TH:i:s.v\Z');
        $transfer['qrGeneratedBy'] = $currentUser['id'];
        $transfer['qrGeneratedByName'] = $currentUser['name'];

        $updateStmt = $db->prepare("UPDATE stock_transfers SET data = ? WHERE id = ?");
        $updateStmt->execute([json_encode($transfer), $transferId]);

        // Log audit event
        logAuditEvent($db, $transferId, 'QR_GENERATED', $currentUser, [
            'transferNumber' => $transfer['transferNumber'],
            'status' => 'In Transit',
            'qrToken' => $qrToken
        ]);

        $db->commit();

        echo json_encode([
            'success' => true,
            'data' => [
                'qr_token' => $qrToken,
                'qr_url' => '/scan-pod.php?token=' . urlencode($qrToken),
                'pod_id' => $podId
            ],
            'message' => 'QR code generated successfully'
        ]);

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}
?>