<?php
/**
 * PO Receiving API with POD (Proof of Receiving) Support
 * Handles PO QR code generation, scanning, and receiving workflow
 */

require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

$currentUser = require_login_api();
$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// Role-based access control
$userRole = $currentUser['role'] ?? 'staff';
$canApprove = $userRole === 'admin' || $userRole === 'manager';

try {
    switch ($method) {
        case 'GET':
            handleGet($db, $action, $currentUser);
            break;
        case 'POST':
            handlePost($db, $action, $currentUser);
            break;
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

function handleGet($db, $action, $currentUser) {
    switch ($action) {
        case 'qr-token':
            getQRToken($db, $_GET['poId'] ?? '', $currentUser);
            break;
        case 'scan':
            scanQRCode($db, $_GET['token'] ?? '', $currentUser);
            break;
        case 'por-details':
            getPORDetails($db, $_GET['porId'] ?? '');
            break;
        case 'by-po':
            getPORByPO($db, $_GET['poId'] ?? '');
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

function handlePost($db, $action, $currentUser) {
    switch ($action) {
        case 'generate-qr':
            generateQRCode($db, $currentUser);
            break;
        case 'confirm-receiving':
            confirmReceiving($db, $currentUser);
            break;
        case 'upload-photo':
            uploadPORPhoto($db, $currentUser);
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

/**
 * Generate QR code for approved PO
 */
function generateQRCode($db, $currentUser) {
    $input = get_json_input();
    $poId = $input['poId'] ?? '';

    if (empty($poId)) {
        echo json_encode(['success' => false, 'error' => 'PO ID required']);
        return;
    }

    try {
        $db->beginTransaction();

        // Get the PO
        $stmt = $db->prepare("SELECT data FROM purchase_orders WHERE id = ?");
        $stmt->execute([$poId]);
        $result = $stmt->fetch();

        if (!$result) {
            throw new Exception('Purchase order not found');
        }

        $po = json_decode($result['data'], true);

        // Only generate QR for approved POs
        if ($po['status'] !== 'Approved') {
            throw new Exception('QR code can only be generated for approved purchase orders');
        }

        // Check if QR already generated
        if (!empty($po['qrToken'])) {
            echo json_encode([
                'success' => true,
                'data' => [
                    'qrToken' => $po['qrToken'],
                    'message' => 'QR code already exists for this PO'
                ]
            ]);
            return;
        }

        // Generate unique QR token
        $qrToken = 'POR-' . strtoupper(bin2hex(random_bytes(16)));
        
        // Update PO with QR token and status
        $po['qrToken'] = $qrToken;
        $po['qrGeneratedAt'] = date('Y-m-d\TH:i:s.v\Z');
        $po['qrGeneratedBy'] = $currentUser['id'];
        $po['qrGeneratedByName'] = $currentUser['name'];
        $po['status'] = 'Awaiting Delivery'; // New status

        $updateStmt = $db->prepare("UPDATE purchase_orders SET data = ? WHERE id = ?");
        $updateStmt->execute([json_encode($po), $poId]);

        $db->commit();

        echo json_encode([
            'success' => true,
            'data' => [
                'qrToken' => $qrToken,
                'po' => $po,
                'message' => 'QR code generated successfully'
            ]
        ]);

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

/**
 * Get QR token for display/printing
 */
function getQRToken($db, $poId, $currentUser) {
    if (empty($poId)) {
        echo json_encode(['success' => false, 'error' => 'PO ID required']);
        return;
    }

    $stmt = $db->prepare("SELECT data FROM purchase_orders WHERE id = ?");
    $stmt->execute([$poId]);
    $result = $stmt->fetch();

    if (!$result) {
        echo json_encode(['success' => false, 'error' => 'Purchase order not found']);
        return;
    }

    $po = json_decode($result['data'], true);

    if (empty($po['qrToken'])) {
        echo json_encode(['success' => false, 'error' => 'QR code not generated for this PO']);
        return;
    }

    echo json_encode([
        'success' => true,
        'data' => [
            'qrToken' => $po['qrToken'],
            'po' => $po
        ]
    ]);
}

/**
 * Scan QR code and retrieve PO details
 */
function scanQRCode($db, $token, $currentUser) {
    if (empty($token)) {
        echo json_encode(['success' => false, 'error' => 'QR token required']);
        return;
    }

    // Find PO by QR token
    $stmt = $db->query("SELECT id, data FROM purchase_orders");
    $results = $stmt->fetchAll();

    $matchedPO = null;
    $matchedId = null;

    foreach ($results as $row) {
        $data = json_decode($row['data'], true);
        if (isset($data['qrToken']) && $data['qrToken'] === $token) {
            $matchedPO = $data;
            $matchedId = $row['id'];
            break;
        }
    }

    if (!$matchedPO) {
        echo json_encode(['success' => false, 'error' => 'Invalid QR code or PO not found']);
        return;
    }

    // Check if already received
    if ($matchedPO['status'] === 'Fully Received') {
        echo json_encode([
            'success' => false,
            'error' => 'This purchase order has already been fully received',
            'po' => $matchedPO
        ]);
        return;
    }

    // Get supplier details
    $supplier = null;
    if (!empty($matchedPO['supplierId'])) {
        $supplierStmt = $db->prepare("SELECT data FROM suppliers WHERE id = ?");
        $supplierStmt->execute([$matchedPO['supplierId']]);
        $supplierResult = $supplierStmt->fetch();
        if ($supplierResult) {
            $supplier = json_decode($supplierResult['data'], true);
        }
    }

    echo json_encode([
        'success' => true,
        'data' => [
            'po' => $matchedPO,
            'poId' => $matchedId,
            'supplier' => $supplier,
            'message' => 'QR code scanned successfully'
        ]
    ]);
}

/**
 * Confirm receiving items (via QR scan)
 */
function confirmReceiving($db, $currentUser) {
    $input = get_json_input();
    $poId = $input['poId'] ?? '';
    $qrToken = $input['qrToken'] ?? '';
    $items = $input['items'] ?? [];
    $remarks = $input['remarks'] ?? '';
    $damagePhotos = $input['damagePhotos'] ?? [];

    if (empty($poId) || empty($qrToken)) {
        echo json_encode(['success' => false, 'error' => 'PO ID and QR token required']);
        return;
    }

    if (empty($items)) {
        echo json_encode(['success' => false, 'error' => 'No items to receive']);
        return;
    }

    try {
        $db->beginTransaction();

        // Get and verify PO
        $stmt = $db->prepare("SELECT data FROM purchase_orders WHERE id = ?");
        $stmt->execute([$poId]);
        $result = $stmt->fetch();

        if (!$result) {
            throw new Exception('Purchase order not found');
        }

        $po = json_decode($result['data'], true);

        // Verify QR token
        if ($po['qrToken'] !== $qrToken) {
            throw new Exception('Invalid QR token');
        }

        // Generate receiving number
        $receivingNumber = generateReceivingNumber($db);
        $porId = generate_id('por');

        // Calculate totals
        $totalReceived = 0;
        $totalAccepted = 0;
        $totalRejected = 0;
        $totalValue = 0;

        foreach ($items as $item) {
            $delivered = floatval($item['quantityDelivered'] ?? 0);
            $accepted = floatval($item['quantityAccepted'] ?? $delivered);
            $rejected = $delivered - $accepted;

            $totalReceived += $delivered;
            $totalAccepted += $accepted;
            $totalRejected += $rejected;
            $totalValue += $accepted * floatval($item['unitCost'] ?? 0);
        }

        // Create POR record
        $porData = [
            'id' => $porId,
            'receivingNumber' => $receivingNumber,
            'poId' => $poId,
            'poNumber' => $po['poNumber'],
            'supplierId' => $po['supplierId'],
            'supplierName' => $po['supplierName'],
            'receivedDate' => date('Y-m-d\TH:i:s.v\Z'),
            'receivedBy' => $currentUser['id'],
            'receivedByName' => $currentUser['name'],
            'items' => $items,
            'totalReceived' => $totalReceived,
            'totalAccepted' => $totalAccepted,
            'totalRejected' => $totalRejected,
            'totalValue' => $totalValue,
            'remarks' => $remarks,
            'damagePhotos' => $damagePhotos,
            'qrToken' => $qrToken,
            'receivingMethod' => 'QR_SCAN',
            'status' => 'Completed'
        ];

        // Insert POR record
        $insertPOR = $db->prepare("INSERT INTO receivings (id, data) VALUES (?, ?)");
        $insertPOR->execute([$porId, json_encode($porData)]);

        // Update inventory for each item
        updateInventoryForPOR($db, $items, $po, $currentUser, $receivingNumber);

        // Update PO status
        updatePOStatus($db, $poId, $po, $items);

        $db->commit();

        echo json_encode([
            'success' => true,
            'data' => [
                'por' => $porData,
                'message' => "Receiving {$receivingNumber} completed successfully"
            ]
        ]);

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

/**
 * Update inventory when items are received
 */
function updateInventoryForPOR($db, $items, $po, $currentUser, $receivingNumber) {
    foreach ($items as $item) {
        $productId = $item['productId'];
        $accepted = floatval($item['quantityAccepted'] ?? $item['quantityDelivered'] ?? 0);

        if ($accepted <= 0) continue;

        // Update product stock
        $stmt = $db->prepare("SELECT data FROM products WHERE id = ?");
        $stmt->execute([$productId]);
        $productResult = $stmt->fetch();

        if ($productResult) {
            $productData = json_decode($productResult['data'], true);
            $previousStock = floatval($productData['stock'] ?? 0);
            $newStock = $previousStock + $accepted;

            $productData['stock'] = $newStock;
            $productData['lastUpdated'] = date('Y-m-d\TH:i:s.v\Z');

            $updateStmt = $db->prepare("UPDATE products SET data = ? WHERE id = ?");
            $updateStmt->execute([json_encode($productData), $productId]);

            // Create inventory movement record
            $movementId = generate_id('inventory_movements');
            $movementData = [
                'id' => $movementId,
                'productId' => $productId,
                'productName' => $item['productName'] ?? $productData['name'],
                'sku' => $item['sku'] ?? $productData['sku'],
                'date' => date('Y-m-d\TH:i:s.v\Z'),
                'type' => 'Stock In',
                'referenceType' => 'PO_RECEIVING',
                'referenceId' => $receivingNumber,
                'referencePO' => $po['poNumber'],
                'quantity' => $accepted,
                'previousBalance' => $previousStock,
                'newBalance' => $newStock,
                'change' => $accepted,
                'reason' => 'Purchase Order Receiving',
                'notes' => "Received from {$po['supplierName']} via {$po['poNumber']}",
                'user' => $currentUser['name'],
                'unitCost' => floatval($item['unitCost'] ?? 0)
            ];

            $movementStmt = $db->prepare("INSERT INTO inventory_movements (id, data) VALUES (?, ?)");
            $movementStmt->execute([$movementId, json_encode($movementData)]);
        }
    }
}

/**
 * Update PO status based on received quantities
 */
function updatePOStatus($db, $poId, $po, $receivedItems) {
    $allItemsFullyReceived = true;
    $anyItemReceived = false;

    foreach ($po['items'] as $poItem) {
        $productId = $poItem['productId'];
        $orderedQty = floatval($poItem['quantity']);
        
        // Calculate total received for this product (including this receiving)
        $totalReceived = 0;
        foreach ($receivedItems as $recItem) {
            if ($recItem['productId'] === $productId) {
                $totalReceived += floatval($recItem['quantityAccepted'] ?? $recItem['quantityDelivered'] ?? 0);
            }
        }

        // Check if item partially or fully received
        if ($totalReceived > 0) {
            $anyItemReceived = true;
        }
        if ($totalReceived < $orderedQty) {
            $allItemsFullyReceived = false;
        }
    }

    // Update PO status
    if ($allItemsFullyReceived) {
        $po['status'] = 'Fully Received';
        $po['fullyReceivedAt'] = date('Y-m-d\TH:i:s.v\Z');
    } elseif ($anyItemReceived) {
        $po['status'] = 'Partially Received';
        $po['partiallyReceivedAt'] = date('Y-m-d\TH:i:s.v\Z');
    }

    $updateStmt = $db->prepare("UPDATE purchase_orders SET data = ? WHERE id = ?");
    $updateStmt->execute([json_encode($po), $poId]);
}

/**
 * Upload damage/inspection photo
 */
function uploadPORPhoto($db, $currentUser) {
    if (!isset($_FILES['photo'])) {
        echo json_encode(['success' => false, 'error' => 'No photo uploaded']);
        return;
    }

    $porId = $_POST['porId'] ?? '';
    if (empty($porId)) {
        echo json_encode(['success' => false, 'error' => 'POR ID required']);
        return;
    }

    $file = $_FILES['photo'];
    $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    $maxSize = 5 * 1024 * 1024; // 5MB

    if (!in_array($file['type'], $allowedTypes)) {
        echo json_encode(['success' => false, 'error' => 'Invalid file type. Only JPG, PNG, WEBP allowed']);
        return;
    }

    if ($file['size'] > $maxSize) {
        echo json_encode(['success' => false, 'error' => 'File too large. Max 5MB']);
        return;
    }

    $uploadDir = __DIR__ . '/../uploads/por-evidence/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'por_' . $porId . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $extension;
    $filepath = $uploadDir . $filename;

    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        $photoUrl = '/uploads/por-evidence/' . $filename;
        
        echo json_encode([
            'success' => true,
            'data' => [
                'filename' => $filename,
                'url' => $photoUrl,
                'uploadedAt' => date('Y-m-d\TH:i:s.v\Z'),
                'uploadedBy' => $currentUser['name']
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to save photo']);
    }
}

/**
 * Get POR details by ID
 */
function getPORDetails($db, $porId) {
    if (empty($porId)) {
        echo json_encode(['success' => false, 'error' => 'POR ID required']);
        return;
    }

    $stmt = $db->prepare("SELECT data FROM receivings WHERE id = ?");
    $stmt->execute([$porId]);
    $result = $stmt->fetch();

    if (!$result) {
        echo json_encode(['success' => false, 'error' => 'POR not found']);
        return;
    }

    echo json_encode([
        'success' => true,
        'data' => json_decode($result['data'], true)
    ]);
}

/**
 * Get POR by PO ID
 */
function getPORByPO($db, $poId) {
    if (empty($poId)) {
        echo json_encode(['success' => false, 'error' => 'PO ID required']);
        return;
    }

    $stmt = $db->query("SELECT data FROM receivings");
    $results = $stmt->fetchAll();

    $matchedPORs = [];
    foreach ($results as $row) {
        $data = json_decode($row['data'], true);
        if (isset($data['poId']) && $data['poId'] === $poId) {
            $matchedPORs[] = $data;
        }
    }

    echo json_encode([
        'success' => true,
        'data' => $matchedPORs
    ]);
}

/**
 * Generate receiving number in GR-YYYY-NNNN format
 */
function generateReceivingNumber($db) {
    $currentYear = date('Y');
    $stmt = $db->query("SELECT data FROM receivings");
    $results = $stmt->fetchAll();

    $maxNumber = 0;
    foreach ($results as $row) {
        $data = json_decode($row['data'], true);
        if (isset($data['receivingNumber']) && preg_match("/GR-$currentYear-(\d{4})/", $data['receivingNumber'], $matches)) {
            $maxNumber = max($maxNumber, intval($matches[1]));
        }
    }

    $nextNumber = str_pad($maxNumber + 1, 4, '0', STR_PAD_LEFT);
    return "GR-$currentYear-$nextNumber";
}
