<?php
/**
 * Reports API for RAM-YUM System
 * Provides comprehensive reporting and analytics data
 */

require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');
require_login_api();

$db = getDB();
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'workflow_summary':
            // Get workflow summary data
            $pos = getCollectionData($db, 'purchase_orders');
            $receivings = getCollectionData($db, 'receivings');
            $movements = getCollectionData($db, 'inventory_movements');
            
            $summary = [
                'totalPOs' => count($pos),
                'completedPOs' => count(array_filter($pos, fn($po) => $po['status'] === 'Fully Received')),
                'partialPOs' => count(array_filter($pos, fn($po) => $po['status'] === 'Partially Received')),
                'pendingPOs' => count(array_filter($pos, fn($po) => in_array($po['status'], ['Approved', 'Pending']))),
                'totalReceivings' => count($receivings),
                'totalMovements' => count($movements),
                'totalValue' => array_sum(array_column($pos, 'total')),
                'receivedValue' => array_sum(array_column($receivings, 'totalValue'))
            ];
            
            json_response([
                'success' => true,
                'data' => $summary
            ]);
            break;
            
        case 'audit_summary':
            // Get recent audit activities
            $pos = getCollectionData($db, 'purchase_orders');
            $receivings = getCollectionData($db, 'receivings');
            $movements = getCollectionData($db, 'inventory_movements');
            
            $activities = [];
            
            // Recent POs
            foreach (array_slice(array_reverse($pos), 0, 10) as $po) {
                $activities[] = [
                    'timestamp' => $po['orderDate'],
                    'type' => 'Purchase Order',
                    'action' => 'Created',
                    'description' => "PO {$po['poNumber']} created",
                    'user' => $po['createdBy'] ?? 'System',
                    'value' => $po['total'] ?? 0
                ];
            }
            
            // Recent receivings
            foreach (array_slice(array_reverse($receivings), 0, 10) as $gr) {
                $activities[] = [
                    'timestamp' => $gr['receivedDate'],
                    'type' => 'Receiving',
                    'action' => 'Items Received',
                    'description' => "Received {$gr['totalReceived']} items",
                    'user' => $gr['receivedBy'] ?? 'System',
                    'value' => $gr['totalValue'] ?? 0
                ];
            }
            
            // Sort by timestamp
            usort($activities, fn($a, $b) => strtotime($b['timestamp']) - strtotime($a['timestamp']));
            
            json_response([
                'success' => true,
                'data' => array_slice($activities, 0, 20)
            ]);
            break;
            
        case 'inventory_metrics':
            // Get inventory performance metrics
            $products = getCollectionData($db, 'products');
            $movements = getCollectionData($db, 'inventory_movements');
            
            $totalProducts = count($products);
            $totalStock = array_sum(array_column($products, 'stock'));
            $totalValue = array_sum(array_map(fn($p) => ($p['stock'] ?? 0) * ($p['price'] ?? 0), $products));
            $lowStock = count(array_filter($products, fn($p) => ($p['stock'] ?? 0) <= ($p['reorderLevel'] ?? 10)));
            $outOfStock = count(array_filter($products, fn($p) => ($p['stock'] ?? 0) === 0));
            
            // Recent movements
            $stockIn = count(array_filter($movements, fn($m) => $m['type'] === 'Stock In'));
            $stockOut = count(array_filter($movements, fn($m) => $m['type'] === 'Stock Out'));
            $adjustments = count(array_filter($movements, fn($m) => $m['type'] === 'Adjustment'));
            
            json_response([
                'success' => true,
                'data' => [
                    'totalProducts' => $totalProducts,
                    'totalStock' => $totalStock,
                    'totalValue' => $totalValue,
                    'lowStock' => $lowStock,
                    'outOfStock' => $outOfStock,
                    'stockInCount' => $stockIn,
                    'stockOutCount' => $stockOut,
                    'adjustmentCount' => $adjustments,
                    'movementCount' => count($movements)
                ]
            ]);
            break;
            
        case 'supplier_performance':
            // Get supplier performance data
            $suppliers = getCollectionData($db, 'suppliers');
            $pos = getCollectionData($db, 'purchase_orders');
            $receivings = getCollectionData($db, 'receivings');
            
            $supplierStats = [];
            foreach ($suppliers as $supplier) {
                $supplierPOs = array_filter($pos, fn($po) => $po['supplierId'] === $supplier['id']);
                $supplierReceivings = array_filter($receivings, fn($gr) => $gr['supplierId'] === $supplier['id']);
                
                $totalOrders = count($supplierPOs);
                $completedOrders = count(array_filter($supplierPOs, fn($po) => $po['status'] === 'Fully Received'));
                $totalValue = array_sum(array_column($supplierPOs, 'total'));
                $receivedValue = array_sum(array_column($supplierReceivings, 'totalValue'));
                
                $supplierStats[] = [
                    'supplier' => $supplier,
                    'totalOrders' => $totalOrders,
                    'completedOrders' => $completedOrders,
                    'totalValue' => $totalValue,
                    'receivedValue' => $receivedValue,
                    'completionRate' => $totalOrders > 0 ? round($completedOrders / $totalOrders * 100, 1) : 0,
                    'receivingCount' => count($supplierReceivings)
                ];
            }
            
            json_response([
                'success' => true,
                'data' => $supplierStats
            ]);
            break;
            
        case 'monthly_trends':
            // Get monthly trend data for the past 12 months
            $pos = getCollectionData($db, 'purchase_orders');
            $receivings = getCollectionData($db, 'receivings');
            
            $trends = [];
            for ($i = 11; $i >= 0; $i--) {
                $month = date('Y-m', strtotime("-$i months"));
                $monthName = date('M Y', strtotime("-$i months"));
                
                $monthPOs = array_filter($pos, fn($po) => date('Y-m', strtotime($po['orderDate'])) === $month);
                $monthReceivings = array_filter($receivings, fn($gr) => date('Y-m', strtotime($gr['receivedDate'])) === $month);
                
                $trends[] = [
                    'month' => $monthName,
                    'pos' => count($monthPOs),
                    'receivings' => count($monthReceivings),
                    'poValue' => array_sum(array_column($monthPOs, 'total')),
                    'receivedValue' => array_sum(array_column($monthReceivings, 'totalValue'))
                ];
            }
            
            json_response([
                'success' => true,
                'data' => $trends
            ]);
            break;
            
        case 'export_data':
            // Export data for external analysis
            $type = $_GET['type'] ?? 'all';
            $format = $_GET['format'] ?? 'json';
            
            $exportData = [];
            
            if ($type === 'all' || $type === 'pos') {
                $exportData['purchase_orders'] = getCollectionData($db, 'purchase_orders');
            }
            
            if ($type === 'all' || $type === 'receivings') {
                $exportData['receivings'] = getCollectionData($db, 'receivings');
            }
            
            if ($type === 'all' || $type === 'inventory') {
                $exportData['products'] = getCollectionData($db, 'products');
                $exportData['movements'] = getCollectionData($db, 'inventory_movements');
            }
            
            if ($type === 'all' || $type === 'suppliers') {
                $exportData['suppliers'] = getCollectionData($db, 'suppliers');
            }
            
            if ($format === 'csv') {
                // Return CSV download headers
                header('Content-Type: text/csv');
                header('Content-Disposition: attachment; filename="ram_yum_export_' . date('Y-m-d') . '.csv"');
                
                // Convert to CSV (simplified for demo)
                $output = "Export Type,Count,Total Value\n";
                foreach ($exportData as $key => $data) {
                    $count = count($data);
                    $value = 0;
                    if (isset($data[0]['total'])) {
                        $value = array_sum(array_column($data, 'total'));
                    }
                    $output .= "$key,$count,$value\n";
                }
                echo $output;
                exit;
            }
            
            json_response([
                'success' => true,
                'data' => $exportData,
                'timestamp' => date('Y-m-d H:i:s'),
                'type' => $type
            ]);
            break;
            
        default:
            json_error('Invalid report action', 400);
    }
    
} catch (Exception $e) {
    json_error('Report generation failed: ' . $e->getMessage(), 500);
}

/**
 * Get collection data with error handling
 */
function getCollectionData($db, $collection) {
    try {
        $stmt = $db->prepare("SELECT data FROM $collection");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        return array_map('json_decode', array_filter($results, fn($r) => !empty($r)));
    } catch (Exception $e) {
        return [];
    }
}
?>