<?php
/**
 * Generic CRUD endpoint for the app's JSON-document collections.
 * Mirrors the interface of the original client-side DataService
 * (findAll / findById / create / update / delete) but backed by
 * real MySQL tables instead of localStorage.
 *
 * Usage:
 *   GET    api/data.php?collection=products                -> findAll
 *   GET    api/data.php?collection=products&id=p1           -> findById
 *   POST   api/data.php?collection=products   { ...fields }  -> create
 *   PUT    api/data.php?collection=products&id=p1 { ...fields } -> update (merge)
 *   DELETE api/data.php?collection=products&id=p1            -> delete
 */

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/stock-status.php';
require_once __DIR__ . '/../includes/status-helpers.php';

require_login_api();

// Collections that staff may read but only manager/admin may create/update/delete
$ROLE_PROTECTED_WRITE = ['purchase_orders', 'stock_transfers', 'stock_adjustments', 'suppliers'];
$ADMIN_ONLY_WRITE = []; // reserved

$currentUser = current_user();
$userRole = $currentUser['role'] ?? 'staff';

function assert_collection_write_allowed(string $collection, string $role): void
{
    global $ROLE_PROTECTED_WRITE;
    if (in_array($collection, $ROLE_PROTECTED_WRITE, true) && !in_array($role, ['admin', 'manager'], true)) {
        json_error('You do not have permission to modify this resource.', 403);
    }
}


const ALLOWED_COLLECTIONS = [
    'categories', 'suppliers', 'products', 'inventory_movements',
    'purchase_orders', 'receivings', 'stock_transfers', 'stock_adjustments',
];

$collection = $_GET['collection'] ?? '';
if (!in_array($collection, ALLOWED_COLLECTIONS, true)) {
    json_error('Unknown or disallowed collection.', 400);
}

$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];

/**
 * Enrich product data with automatic stock status
 * Calculates status based on current stock quantity
 */
function enrich_product_data(array $data): array
{
    if (isset($data['stock'])) {
        $data['status'] = getStockStatus($data['stock']);
    }
    return $data;
}

function enrich_record(string $collection, $data): array
{
    if (!is_array($data)) {
        return [];
    }
    if ($collection === 'products') {
        return enrich_product_data($data);
    }
    if ($collection === 'purchase_orders' && isset($data['status'])) {
        $data['status'] = normalize_po_status($data['status']);
    }
    if ($collection === 'stock_transfers' && isset($data['status'])) {
        $data['status'] = normalize_transfer_status($data['status']);
    }
    return $data;
}
/**
 * Coerce a few well-known numeric fields, mirroring the original
 * DataService's "force numeric safety on save" behavior.
 */
function coerce_numeric_fields(array $data, ?string $collectionName = null): array
{
    $col = $collectionName ?? ($GLOBALS['collection'] ?? '');
    if (isset($data['price'])) {
        $data['price'] = (float) $data['price'];
    }
    if (isset($data['stock']) && !is_array($data['stock'])) {
        $data['stock'] = (float) $data['stock'];
    }
    if (is_string($col) && $col !== '') {
        $data = enrich_record($col, $data);
    } elseif (isset($data['stock'])) {
        $data = enrich_product_data($data);
    }
    return $data;
}

switch ($method) {
    case 'GET':
        $id = $_GET['id'] ?? null;
        if ($id !== null) {
            $stmt = $db->prepare("SELECT data FROM `$collection` WHERE id = ?");
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            $data = $row ? json_decode($row['data'], true) : null;
            // Enrich product with automatic status
            if ($data) {
                $data = enrich_record($collection, $data);
            }
            json_response(['success' => true, 'data' => $data]);
        } else {
            // Special sorting for purchase_orders: Pending first, then by latest date
            if ($collection === 'purchase_orders') {
                $stmt = $db->query("
                    SELECT data FROM `$collection` 
                    ORDER BY 
                        CASE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status'))
                            WHEN 'Pending' THEN 1
                            WHEN 'Received' THEN 2
                            WHEN 'Approved' THEN 3
                            ELSE 4
                        END ASC,
                        created_at DESC
                ");
            } else {
                $stmt = $db->query("SELECT data FROM `$collection` ORDER BY created_at ASC");
            }
            
            $records = array_map(function($r) use ($collection) {
                $data = json_decode($r['data'] ?? '', true);
                if (!is_array($data)) {
                    return null;
                }
                return enrich_record($collection, $data);
            }, $stmt->fetchAll());
            $records = array_values(array_filter($records));
            json_response(['success' => true, 'data' => $records]);
        }
        break;

    case 'POST':
        assert_collection_write_allowed($collection, $userRole);
        $input = get_json_input();
        $input = sanitize_recursive($input);
        $input = coerce_numeric_fields($input);
        if ($collection === 'purchase_orders' && isset($input['status'])) {
            $input['status'] = normalize_po_status($input['status']);
        }
        if ($collection === 'stock_transfers' && isset($input['status'])) {
            $input['status'] = normalize_transfer_status($input['status']);
        }
        $id = generate_id($collection);
        $input['id'] = $id;

        // SERVER-SIDE VALIDATION: Check for duplicate SKU in products collection
        if ($collection === 'products' && !empty($input['sku'])) {
            $skuCheck = $db->prepare("SELECT id FROM `products` WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku')) = ?");
            $skuCheck->execute([$input['sku']]);
            if ($skuCheck->fetch()) {
                json_error("SKU '{$input['sku']}' already exists. Each product must have a unique SKU.", 409);
            }
        }

        // SERVER-SIDE VALIDATION: Prevent negative stock
        if ($collection === 'products' && isset($input['stock'])) {
            if ($input['stock'] < 0) {
                json_error("Stock quantity cannot be negative. Provided: {$input['stock']}", 400);
            }
        }

        $stmt = $db->prepare("INSERT INTO `$collection` (id, data) VALUES (?, ?)");
        $stmt->execute([$id, json_encode($input)]);

        json_response(['success' => true, 'data' => $input], 201);
        break;

    case 'PUT':
        assert_collection_write_allowed($collection, $userRole);
    case 'PATCH':
        $id = $_GET['id'] ?? null;
        if (!$id) {
            json_error('Missing id for update.');
        }
        $stmt = $db->prepare("SELECT data FROM `$collection` WHERE id = ?");
        $stmt->execute([$id]);
        $existingRow = $stmt->fetch();
        if (!$existingRow) {
            json_error('Record not found.', 404);
        }
        $existing = json_decode($existingRow['data'], true);

        $input = get_json_input();
        $input = sanitize_recursive($input);
        $input = coerce_numeric_fields($input);

        $merged = array_merge($existing, $input);
        $merged['id'] = $id;

        // SERVER-SIDE VALIDATION: Check for duplicate SKU when updating products
        if ($collection === 'products' && !empty($merged['sku'])) {
            $skuCheck = $db->prepare("SELECT id FROM `products` WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku')) = ? AND id != ?");
            $skuCheck->execute([$merged['sku'], $id]);
            if ($skuCheck->fetch()) {
                json_error("SKU '{$merged['sku']}' already exists. Each product must have a unique SKU.", 409);
            }
        }

        // SERVER-SIDE VALIDATION: Prevent negative stock
        if ($collection === 'products' && isset($merged['stock'])) {
            if ($merged['stock'] < 0) {
                json_error("Stock quantity cannot be negative. Provided: {$merged['stock']}", 400);
            }
        }

        $update = $db->prepare("UPDATE `$collection` SET data = ? WHERE id = ?");
        $update->execute([json_encode($merged), $id]);

        json_response(['success' => true, 'data' => $merged]);
        break;

    case 'DELETE':
        assert_collection_write_allowed($collection, $userRole);
        $id = $_GET['id'] ?? null;
        if (!$id) {
            json_error('Missing id for delete.');
        }
        $stmt = $db->prepare("DELETE FROM `$collection` WHERE id = ?");
        $stmt->execute([$id]);
        if ($stmt->rowCount() === 0) {
            json_error('Record not found.', 404);
        }
        json_response(['success' => true]);
        break;

    default:
        json_error('Method not allowed.', 405);
}
