<?php
/**
 * Resets all operational (non-user) data back to the original seed state.
 * Admin only. User accounts and security logs are left untouched.
 */

require_once __DIR__ . '/../includes/auth.php';

$admin = require_admin_api();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$db = getDB();

$tables = ['categories', 'products', 'inventory_movements', 'purchase_orders', 'receivings', 'stock_transfers', 'stock_adjustments', 'inventory_predictions'];
foreach ($tables as $t) {
    $db->exec("DELETE FROM `$t`");
}
$db->exec('DELETE FROM suppliers');

$now = date('Y-m-d\TH:i:s.000\Z');

$supplierStmt = $db->prepare('INSERT INTO suppliers (id, data) VALUES (?, ?)');
$supplierStmt->execute(['s1', json_encode([
    'id' => 's1', 'company' => 'Seoul Trading Co.', 'contactPerson' => 'Minji Kim',
    'email' => 'minji@seoultrade.co.kr', 'phone' => '+82 10 1234 5678',
    'address' => '123 Gangnam-daero, Seoul, South Korea', 'taxId' => '123-45-67890',
    'paymentTerms' => 'Net 30', 'notes' => 'Primary supplier for Korean snacks.', 'productCount' => 2,
])]);
$supplierStmt->execute(['s2', json_encode([
    'id' => 's2', 'company' => 'Osaka Premium Imports', 'contactPerson' => 'Taro Tanaka',
    'email' => 'taro@osakapremium.jp', 'phone' => '+81 6 1234 5678',
    'address' => '45 Namba, Osaka, Japan', 'taxId' => 'JP-87654321',
    'paymentTerms' => 'Net 15', 'notes' => 'High quality rice and seafood.', 'productCount' => 1,
])]);

$productStmt = $db->prepare('INSERT INTO products (id, data) VALUES (?, ?)');
$productStmt->execute(['p1', json_encode([
    'id' => 'p1', 'name' => 'Kimchi Ramen', 'sku' => 'KR-001', 'category' => 'Noodles',
    'price' => 5.99, 'stock' => 45, 'reorderLevel' => 20, 'status' => 'In Stock',
    'description' => 'Spicy fermented cabbage ramen', 'image' => '',
    'lastUpdated' => $now, 'supplierId' => 's1', 'expirationDate' => date('Y-m-d', strtotime('+8 months')),
])]);
$productStmt->execute(['p2', json_encode([
    'id' => 'p2', 'name' => 'Premium Sushi Rice', 'sku' => 'SR-002', 'category' => 'Rice',
    'price' => 12.50, 'stock' => 8, 'reorderLevel' => 15, 'status' => 'Low Stock',
    'description' => 'High quality short grain rice', 'image' => '',
    'lastUpdated' => $now, 'supplierId' => 's2', 'expirationDate' => date('Y-m-d', strtotime('+18 months')),
])]);

log_security_event('ADMIN_RESET_DEMO_DATA', $admin['id'], $admin['username']);

json_response(['success' => true]);
