<?php
/**
 * Image Upload API
 * Handles secure image uploads for product images and damage evidence
 */

// Set JSON header FIRST to ensure all errors are JSON
header('Content-Type: application/json');

// Enable error logging but hide from output
ini_set('display_errors', '0');
error_reporting(E_ALL);

require_once __DIR__ . '/../includes/auth.php';

// Check authentication
$currentUser = current_user();
if (!$currentUser) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error' => 'Authentication required'
    ]);
    exit;
}

// Configuration
$ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
$MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
$UPLOAD_DIRS = [
    'product' => __DIR__ . '/../uploads/product-images/',
    'damage' => __DIR__ . '/../uploads/damage-evidence/'
];

// Ensure upload directories exist
foreach ($UPLOAD_DIRS as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
}

try {
    // Validate request method
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }
    
    // Validate upload type
    $uploadType = $_POST['type'] ?? 'product';
    if (!isset($UPLOAD_DIRS[$uploadType])) {
        throw new Exception('Invalid upload type');
    }
    
    // Validate file upload
    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        $errorMsg = 'File upload failed';
        if (isset($_FILES['image']['error'])) {
            switch ($_FILES['image']['error']) {
                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:
                    $errorMsg = 'File is too large';
                    break;
                case UPLOAD_ERR_NO_FILE:
                    $errorMsg = 'No file was uploaded';
                    break;
            }
        }
        throw new Exception($errorMsg);
    }
    
    $file = $_FILES['image'];
    
    // Validate file size
    if ($file['size'] > $MAX_FILE_SIZE) {
        throw new Exception('File size exceeds maximum allowed (5MB)');
    }
    
    // Validate file type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mimeType, $ALLOWED_TYPES)) {
        throw new Exception('Invalid file type. Only JPG, PNG, GIF, and WebP are allowed');
    }
    
    // Generate safe filename
    $extension = '';
    switch ($mimeType) {
        case 'image/jpeg':
            $extension = '.jpg';
            break;
        case 'image/png':
            $extension = '.png';
            break;
        case 'image/gif':
            $extension = '.gif';
            break;
        case 'image/webp':
            $extension = '.webp';
            break;
    }
    
    // Create unique filename
    $timestamp = time();
    $random = bin2hex(random_bytes(8));
    $safeFilename = $uploadType . '_' . $timestamp . '_' . $random . $extension;
    
    // Ensure upload directory exists
    $uploadDir = $UPLOAD_DIRS[$uploadType];
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    // Move uploaded file
    $targetPath = $uploadDir . $safeFilename;
    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        throw new Exception('Failed to save uploaded file');
    }
    
    // Return relative path for database storage
    $relativePath = 'uploads/' . ($uploadType === 'product' ? 'product-images' : 'damage-evidence') . '/' . $safeFilename;
    
    // Log the upload
    log_security_event('FILE_UPLOAD', $currentUser['id'], $currentUser['username'], [
        'type' => $uploadType,
        'filename' => $safeFilename,
        'size' => $file['size'],
        'mime_type' => $mimeType
    ]);
    
    echo json_encode([
        'success' => true,
        'data' => [
            'path' => $relativePath,
            'filename' => $safeFilename,
            'url' => '/' . $relativePath,
            'size' => $file['size'],
            'type' => $mimeType
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
} catch (Throwable $e) {
    // Catch any PHP errors/warnings
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Server error: ' . $e->getMessage()
    ]);
}
