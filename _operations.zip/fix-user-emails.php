<?php
/**
 * Fix User Email Addresses
 * Updates admin, manager, and staff emails to correct addresses
 */

require_once 'config/database.php';

header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html>
<html>
<head>
    <title>Fix User Emails</title>
    <style>
        body { font-family: monospace; padding: 20px; background: #1e1e1e; color: #d4d4d4; }
        .success { color: #4ec9b0; }
        .error { color: #f48771; }
        .info { color: #569cd6; }
        .warning { color: #dcdcaa; }
        table { border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #404040; padding: 8px 12px; text-align: left; }
        th { background: #2d2d2d; }
        tr:nth-child(even) { background: #252526; }
    </style>
</head>
<body>";

echo "<h1>🔧 Fix User Email Addresses</h1>\n";
echo "<p class='info'>Updating admin, manager, and staff emails...</p>\n";

try {
    $db = getDB();
    
    // Show current emails
    echo "<h2>📋 BEFORE UPDATE</h2>\n";
    $stmt = $db->query("
        SELECT id, username, email, role, created_at, updated_at
        FROM users
        ORDER BY 
            CASE role
                WHEN 'admin' THEN 1
                WHEN 'manager' THEN 2
                WHEN 'staff' THEN 3
                ELSE 4
            END
    ");
    
    echo "<table>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email (OLD)</th>
            <th>Role</th>
            <th>Updated At</th>
        </tr>";
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['username']}</td>
            <td class='warning'>{$row['email']}</td>
            <td>{$row['role']}</td>
            <td>{$row['updated_at']}</td>
        </tr>";
    }
    echo "</table>\n";
    
    // Update emails
    echo "<h2>🔄 UPDATING EMAILS...</h2>\n";
    
    $updates = [
        ['username' => 'admin', 'email' => 'jeremiemugar6@gmail.com'],
        ['username' => 'manager', 'email' => 'jeremiemugar7@gmail.com'],
        ['username' => 'staff', 'email' => 'jeremiemugar8@gmail.com']
    ];
    
    $stmt = $db->prepare("
        UPDATE users 
        SET email = :email, updated_at = NOW()
        WHERE username = :username
    ");
    
    $updatedCount = 0;
    foreach ($updates as $update) {
        $stmt->execute($update);
        $affected = $stmt->rowCount();
        $updatedCount += $affected;
        
        if ($affected > 0) {
            echo "<p class='success'>✓ Updated {$update['username']} → {$update['email']}</p>\n";
        } else {
            echo "<p class='error'>✗ Failed to update {$update['username']}</p>\n";
        }
    }
    
    // Show updated emails
    echo "<h2>✅ AFTER UPDATE</h2>\n";
    $stmt = $db->query("
        SELECT id, username, email, role, updated_at
        FROM users
        ORDER BY 
            CASE role
                WHEN 'admin' THEN 1
                WHEN 'manager' THEN 2
                WHEN 'staff' THEN 3
                ELSE 4
            END
    ");
    
    echo "<table>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email (NEW)</th>
            <th>Role</th>
            <th>Updated At</th>
        </tr>";
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['username']}</td>
            <td class='success'>{$row['email']}</td>
            <td>{$row['role']}</td>
            <td class='info'>{$row['updated_at']}</td>
        </tr>";
    }
    echo "</table>\n";
    
    // Verification
    echo "<h2>🔍 VERIFICATION</h2>\n";
    $stmt = $db->query("
        SELECT COUNT(*) as count
        FROM users
        WHERE email IN (
            'jeremiemugar6@gmail.com',
            'jeremiemugar7@gmail.com', 
            'jeremiemugar8@gmail.com'
        )
    ");
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['count'] == 3) {
        echo "<p class='success'>✓ All 3 users updated successfully!</p>\n";
        echo "<p class='success'>✓ Admin: jeremiemugar6@gmail.com</p>\n";
        echo "<p class='success'>✓ Manager: jeremiemugar7@gmail.com</p>\n";
        echo "<p class='success'>✓ Staff: jeremiemugar8@gmail.com</p>\n";
    } else {
        echo "<p class='error'>✗ Only {$result['count']} users updated (expected 3)</p>\n";
    }
    
    echo "<h2>📝 SUMMARY</h2>\n";
    echo "<ul>
        <li class='info'>Users updated: {$updatedCount} / 3</li>
        <li class='info'>Passwords unchanged (admin123, manager123, staff123)</li>
        <li class='info'>All users remain verified and active</li>
    </ul>\n";
    
} catch (Exception $e) {
    echo "<p class='error'>❌ ERROR: " . htmlspecialchars($e->getMessage()) . "</p>\n";
    echo "<pre class='error'>" . htmlspecialchars($e->getTraceAsString()) . "</pre>\n";
}

echo "</body></html>";
?>
