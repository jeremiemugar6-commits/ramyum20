<?php
/**
 * Fix User System Issues
 * Comprehensive user system repair and verification
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/database.php';

$db = getDB();

echo "USER SYSTEM FIX\n";
echo str_repeat("=", 80) . "\n\n";

// 1. Verify all default users exist with correct passwords
echo "1. VERIFYING DEFAULT USERS:\n";
echo str_repeat("-", 80) . "\n";

$defaultUsers = [
    [
        'id' => 'u1',
        'username' => 'admin',
        'name' => 'Admin User',
        'email' => 'admin@ramyum.local',
        'password' => 'admin123',
        'role' => 'admin',
        'verified' => 1
    ],
    [
        'id' => 'u2',
        'username' => 'staff',
        'name' => 'Staff User',
        'email' => 'staff@ramyum.local',
        'password' => 'staff123',
        'role' => 'staff',
        'verified' => 1
    ],
    [
        'id' => 'u3',
        'username' => 'manager',
        'name' => 'Manager User',
        'email' => 'manager@ramyum.local',
        'password' => 'manager123',
        'role' => 'manager',
        'verified' => 1
    ]
];

foreach ($defaultUsers as $userData) {
    echo "Checking user: {$userData['username']}\n";
    
    // Check if user exists
    $stmt = $db->prepare("SELECT id, password_hash FROM users WHERE username = ?");
    $stmt->execute([$userData['username']]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existing) {
        // Verify password
        if (password_verify($userData['password'], $existing['password_hash'])) {
            echo "  ✓ User exists and password is correct\n";
        } else {
            echo "  ⚠ User exists but password needs update\n";
            // Update password
            $newHash = password_hash($userData['password'], PASSWORD_BCRYPT);
            $updateStmt = $db->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
            $updateStmt->execute([$newHash, $existing['id']]);
            echo "  ✓ Password updated\n";
        }
    } else {
        echo "  ⚠ User does not exist - creating...\n";
        // Create user
        $hash = password_hash($userData['password'], PASSWORD_BCRYPT);
        $insertStmt = $db->prepare("
            INSERT INTO users (id, name, email, username, password_hash, role, verified, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ");
        $insertStmt->execute([
            $userData['id'],
            $userData['name'],
            $userData['email'],
            $userData['username'],
            $hash,
            $userData['role'],
            $userData['verified']
        ]);
        echo "  ✓ User created\n";
    }
    echo "\n";
}

// 2. Fix any users with weak/missing password hashes
echo "2. CHECKING PASSWORD HASHES:\n";
echo str_repeat("-", 80) . "\n";

$stmt = $db->query("SELECT id, username, password_hash FROM users");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($users as $user) {
    $hashLength = strlen($user['password_hash']);
    if ($hashLength < 60) {
        echo "  ⚠ {$user['username']}: Weak hash (length: $hashLength)\n";
        echo "    Needs manual password reset\n";
    } else {
        echo "  ✓ {$user['username']}: Strong bcrypt hash\n";
    }
}

// 3. Verify role values
echo "\n3. VERIFYING USER ROLES:\n";
echo str_repeat("-", 80) . "\n";

$stmt = $db->query("SELECT username, role FROM users");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

$validRoles = ['admin', 'manager', 'staff'];
foreach ($users as $user) {
    if (in_array($user['role'], $validRoles)) {
        echo "  ✓ {$user['username']}: {$user['role']} (valid)\n";
    } else {
        echo "  ✗ {$user['username']}: {$user['role']} (INVALID)\n";
    }
}

// 4. Test login for all users
echo "\n4. TESTING LOGIN FUNCTIONALITY:\n";
echo str_repeat("-", 80) . "\n";

foreach ($defaultUsers as $userData) {
    $stmt = $db->prepare("SELECT id, username, password_hash, role FROM users WHERE username = ?");
    $stmt->execute([$userData['username']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user && password_verify($userData['password'], $user['password_hash'])) {
        echo "  ✓ {$userData['username']}: Login successful\n";
        echo "    Role: {$user['role']}\n";
    } else {
        echo "  ✗ {$userData['username']}: Login FAILED\n";
    }
}

// 5. Check for duplicate usernames/emails
echo "\n5. CHECKING FOR DUPLICATES:\n";
echo str_repeat("-", 80) . "\n";

$stmt = $db->query("
    SELECT username, COUNT(*) as count 
    FROM users 
    GROUP BY username 
    HAVING count > 1
");
$dupes = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($dupes) > 0) {
    echo "  ⚠ Duplicate usernames found:\n";
    foreach ($dupes as $dupe) {
        echo "    - {$dupe['username']} (count: {$dupe['count']})\n";
    }
} else {
    echo "  ✓ No duplicate usernames\n";
}

$stmt = $db->query("
    SELECT email, COUNT(*) as count 
    FROM users 
    GROUP BY email 
    HAVING count > 1
");
$dupes = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($dupes) > 0) {
    echo "  ⚠ Duplicate emails found:\n";
    foreach ($dupes as $dupe) {
        echo "    - {$dupe['email']} (count: {$dupe['count']})\n";
    }
} else {
    echo "  ✓ No duplicate emails\n";
}

// 6. Summary
echo "\n" . str_repeat("=", 80) . "\n";
echo "USER SYSTEM STATUS: ";

$stmt = $db->query("SELECT COUNT(*) as count FROM users");
$userCount = $stmt->fetch()['count'];

if ($userCount >= 3) {
    echo "✓ OPERATIONAL ($userCount users)\n";
} else {
    echo "⚠ INCOMPLETE (only $userCount users)\n";
}

echo "\nDEFAULT CREDENTIALS:\n";
echo "  Username: admin    | Password: admin123    | Role: admin\n";
echo "  Username: manager  | Password: manager123  | Role: manager\n";
echo "  Username: staff    | Password: staff123    | Role: staff\n";

echo "\n" . str_repeat("=", 80) . "\n";
echo "FIX COMPLETE\n";
