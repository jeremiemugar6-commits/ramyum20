<?php
/**
 * Stock Status Automatic Calculation Test
 * Tests all boundary values and automatic status updates
 */

require_once __DIR__ . '/includes/stock-status.php';
require_once __DIR__ . '/config/database.php';

echo "=================================================\n";
echo "AUTOMATIC STOCK STATUS TEST\n";
echo "=================================================\n\n";

// TEST 1: Boundary Value Tests
echo "TEST 1: Boundary Values\n";
echo "------------------------\n";

$boundaryTests = [
    ['stock' => 0, 'expected' => 'Out of Stock', 'emoji' => '🔴'],
    ['stock' => 1, 'expected' => 'Low Stock', 'emoji' => '🟠'],
    ['stock' => 20, 'expected' => 'Low Stock', 'emoji' => '🟠'],
    ['stock' => 21, 'expected' => 'In Stock', 'emoji' => '🟢'],
    ['stock' => 50, 'expected' => 'In Stock', 'emoji' => '🟢'],
    ['stock' => 100, 'expected' => 'In Stock', 'emoji' => '🟢'],
    ['stock' => 101, 'expected' => 'Overstock', 'emoji' => '🔵'],
    ['stock' => 150, 'expected' => 'Overstock', 'emoji' => '🔵'],
    ['stock' => -5, 'expected' => 'Out of Stock', 'emoji' => '🔴']
];

$allPassed = true;

foreach ($boundaryTests as $test) {
    $result = getStockStatus($test['stock']);
    $emoji = getStockStatusEmoji($result);
    $passed = ($result === $test['expected']);
    
    echo sprintf(
        "Stock = %4d => %s %-15s (Expected: %s %-15s) %s\n",
        $test['stock'],
        $emoji,
        $result,
        $test['emoji'],
        $test['expected'],
        $passed ? '✓' : '✗ FAILED'
    );
    
    if (!$passed) {
        $allPassed = false;
    }
}

echo "\n";
echo $allPassed ? "✓ All boundary tests PASSED\n\n" : "✗ Some tests FAILED\n\n";

// TEST 2: Badge HTML Generation
echo "TEST 2: Badge HTML Generation\n";
echo "------------------------------\n";

$badgeTests = [0, 15, 50, 120];

foreach ($badgeTests as $stock) {
    $badge = getStockStatusBadge($stock);
    $status = getStockStatus($stock);
    echo "Stock = $stock: $badge\n";
}

echo "\n";

// TEST 3: Product Data Enrichment
echo "TEST 3: Product Data Enrichment\n";
echo "--------------------------------\n";

$testProducts = [
    ['id' => 'p1', 'name' => 'Test Product 1', 'stock' => 0],
    ['id' => 'p2', 'name' => 'Test Product 2', 'stock' => 15],
    ['id' => 'p3', 'name' => 'Test Product 3', 'stock' => 50],
    ['id' => 'p4', 'name' => 'Test Product 4', 'stock' => 150]
];

foreach ($testProducts as $product) {
    $enriched = enrichProductWithStatus($product);
    $emoji = getStockStatusEmoji($enriched['status']);
    echo "{$product['name']}: Stock={$product['stock']} => $emoji {$enriched['status']}\n";
}

echo "\n";

// TEST 4: Database Product Status Check
echo "TEST 4: Database Product Status Check\n";
echo "--------------------------------------\n";

try {
    $db = getDB();
    
    // Get a few products and check their automatic status
    $stmt = $db->query("SELECT id, data FROM products LIMIT 5");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($products) > 0) {
        echo "Checking actual products from database:\n\n";
        
        foreach ($products as $row) {
            $product = json_decode($row['data'], true);
            $currentStock = $product['stock'] ?? 0;
            $calculatedStatus = getStockStatus($currentStock);
            $storedStatus = $product['status'] ?? 'N/A';
            $emoji = getStockStatusEmoji($calculatedStatus);
            
            echo "Product: {$product['name']}\n";
            echo "  Current Stock: $currentStock\n";
            echo "  Calculated Status: $emoji $calculatedStatus\n";
            echo "  Stored Status: $storedStatus\n";
            echo "  Match: " . ($calculatedStatus === $storedStatus ? '✓' : '⚠ Different') . "\n\n";
        }
    } else {
        echo "No products found in database\n\n";
    }
    
} catch (Exception $e) {
    echo "Error accessing database: " . $e->getMessage() . "\n\n";
}

// TEST 5: Inventory Operation Simulation
echo "TEST 5: Inventory Operation Simulation\n";
echo "---------------------------------------\n";

$simulationStock = 15;
echo "Initial Stock: $simulationStock => " . getStockStatusEmoji(getStockStatus($simulationStock)) . " " . getStockStatus($simulationStock) . "\n";

$simulationStock += 10; // Receive 10 units
echo "After receiving 10 units: $simulationStock => " . getStockStatusEmoji(getStockStatus($simulationStock)) . " " . getStockStatus($simulationStock) . "\n";

$simulationStock -= 25; // Deduct 25 units
echo "After deducting 25 units: $simulationStock => " . getStockStatusEmoji(getStockStatus($simulationStock)) . " " . getStockStatus($simulationStock) . "\n";

$simulationStock += 101; // Add 101 units
echo "After adding 101 units: $simulationStock => " . getStockStatusEmoji(getStockStatus($simulationStock)) . " " . getStockStatus($simulationStock) . "\n";

echo "\n";

// TEST 6: Edge Cases
echo "TEST 6: Edge Cases\n";
echo "-------------------\n";

$edgeCases = [
    ['value' => null, 'desc' => 'NULL value'],
    ['value' => '', 'desc' => 'Empty string'],
    ['value' => '15', 'desc' => 'String number'],
    ['value' => 20.5, 'desc' => 'Decimal (20.5)'],
    ['value' => 100.9, 'desc' => 'Decimal (100.9)']
];

foreach ($edgeCases as $case) {
    $status = getStockStatus($case['value']);
    $emoji = getStockStatusEmoji($status);
    echo "{$case['desc']}: '{$case['value']}' => $emoji $status\n";
}

echo "\n";

// FINAL SUMMARY
echo "=================================================\n";
echo "TEST SUMMARY\n";
echo "=================================================\n";

if ($allPassed) {
    echo "✓ All boundary tests PASSED\n";
    echo "✓ Status calculation is correct\n";
    echo "✓ System is ready for use\n";
} else {
    echo "✗ Some tests FAILED\n";
    echo "⚠ Check the implementation\n";
}

echo "\n";
echo "Status Rules Applied:\n";
echo "  0              => 🔴 Out of Stock\n";
echo "  1-20           => 🟠 Low Stock\n";
echo "  21-100         => 🟢 In Stock\n";
echo "  101+           => 🔵 Overstock\n";
echo "=================================================\n";

?>
