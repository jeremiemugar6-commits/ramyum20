<?php
/**
 * Comprehensive API Endpoint Tester
 * Tests all API endpoints for errors
 */

require_once 'config/database.php';
require_once 'includes/auth.php';

// Suppress session warnings for CLI testing
if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

echo "=== RAM-YUM API ENDPOINT TESTING ===\n\n";

$db = getDB();
$errors = [];
$passed = [];

// Test function
function testEndpoint($name, $callable) {
    global $errors, $passed;
    try {
        $callable();
        $passed[] = "✓ $name";
    } catch (Exception $e) {
        $errors[] = "✗ $name: " . $e->getMessage();
    }
}

// 1. Test Products API
testEndpoint("Products - List", function() use ($db) {
    $stmt = $db->query("SELECT * FROM products LIMIT 1");
    $stmt->fetchAll(PDO::FETCH_ASSOC);
});

// 2. Test Suppliers API
testEndpoint("Suppliers - List", function() use ($db) {
    $stmt = $db->query("SELECT * FROM suppliers LIMIT 1");
    $stmt->fetchAll(PDO::FETCH_ASSOC);
});

// 3. Test Purchase Orders API
testEndpoint("Purchase Orders - List", function() use ($db) {
    $stmt = $db->query("
        SELECT * FROM purchase_orders 
        ORDER BY 
            CASE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status'))
                WHEN 'Pending' THEN 1
                WHEN 'Received' THEN 2
                WHEN 'Approved' THEN 3
                ELSE 4
            END ASC,
            created_at DESC
        LIMIT 1
    ");
    $stmt->fetchAll(PDO::FETCH_ASSOC);
});

// 4. Test Receiving API
testEndpoint("Receiving - List", function() use ($db) {
    $stmt = $db->query("SELECT * FROM receivings ORDER BY created_at DESC LIMIT 1");
    $stmt->fetchAll(PDO::FETCH_ASSOC);
});

// 5. Test POR API - List
testEndpoint("POR - List", function() use ($db) {
    $stmt = $db->query("
        SELECT * FROM proof_of_receiving 
        ORDER BY 
            CASE inspection_status
                WHEN 'Pending Inspection' THEN 1
                WHEN 'Pending' THEN 1
                WHEN 'Passed' THEN 2
                WHEN 'Failed' THEN 3
                ELSE 4
            END ASC,
            receiving_date DESC, 
            created_at DESC
        LIMIT 1
    ");
    $stmt->fetchAll(PDO::FETCH_ASSOC);
});

// 6. Test POR API - Available Receivings
testEndpoint("POR - Available Receivings", function() use ($db) {
    $stmt = $db->query("
        SELECT r.*
        FROM receivings r
        LEFT JOIN proof_of_receiving por ON por.receiving_id = r.id
        WHERE por.id IS NULL
        ORDER BY r.created_at DESC
        LIMIT 1
    ");
    $receivings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($receivings as $r) {
        $data = json_decode($r['data'] ?? '{}', true);
        $status = $data['status'] ?? '';
        if ($status === 'Approved' || $status === 'Completed') {
            // Valid receiving
        }
    }
});

// 7. Test Stock Transfer API
testEndpoint("Stock Transfers - List", function() use ($db) {
    $stmt = $db->query("SELECT * FROM stock_transfers ORDER BY created_at DESC LIMIT 1");
    $stmt->fetchAll(PDO::FETCH_ASSOC);
});

// 8. Test Locations API
testEndpoint("Locations - List", function() use ($db) {
    $stmt = $db->query("SELECT * FROM locations ORDER BY created_at DESC LIMIT 1");
    $stmt->fetchAll(PDO::FETCH_ASSOC);
});

// 9. Test Users API
testEndpoint("Users - List", function() use ($db) {
    $stmt = $db->query("SELECT * FROM users LIMIT 1");
    $stmt->fetchAll(PDO::FETCH_ASSOC);
});

// 10. Test Inventory Movements
testEndpoint("Inventory Movements - List", function() use ($db) {
    $stmt = $db->query("SELECT * FROM inventory_movements ORDER BY created_at DESC LIMIT 1");
    $stmt->fetchAll(PDO::FETCH_ASSOC);
});

// 11. Check critical tables exist
$criticalTables = [
    'products', 'suppliers', 'purchase_orders', 'receivings', 
    'proof_of_receiving', 'proof_of_receiving_items', 
    'stock_transfers', 'locations', 'users', 'inventory_movements'
];

foreach ($criticalTables as $table) {
    testEndpoint("Table Exists - $table", function() use ($db, $table) {
        $stmt = $db->query("SHOW TABLES LIKE '$table'");
        $result = $stmt->fetch();
        if (!$result) {
            throw new Exception("Table $table does not exist");
        }
    });
}

// Output results
echo "\n=== PASSED TESTS (" . count($passed) . ") ===\n";
foreach ($passed as $pass) {
    echo "$pass\n";
}

if (!empty($errors)) {
    echo "\n=== FAILED TESTS (" . count($errors) . ") ===\n";
    foreach ($errors as $error) {
        echo "$error\n";
    }
    echo "\n❌ Some tests failed!\n";
} else {
    echo "\n✅ All tests passed!\n";
}

echo "\n=== DATABASE CONNECTION INFO ===\n";
echo "Host: " . (DB_HOST ?? 'Not set') . "\n";
echo "Database: " . (DB_NAME ?? 'Not set') . "\n";
echo "Connection: " . ($db ? "Active" : "Failed") . "\n";
