<?php
/**
 * Supplier Validation Functions
 * Enforces supplier consistency across Supplier → PO → Receiving → POR workflow
 */

/**
 * Get supplier information from Purchase Order
 * 
 * @param PDO $db Database connection
 * @param string $poId Purchase Order ID
 * @return array|null Supplier data or null if not found
 */
function getSupplierFromPO($db, $poId) {
    try {
        $stmt = $db->prepare("SELECT data FROM purchase_orders WHERE id = ?");
        $stmt->execute([$poId]);
        $result = $stmt->fetch();
        
        if (!$result) {
            return null;
        }
        
        $po = json_decode($result['data'], true);
        
        return [
            'supplierId' => $po['supplierId'] ?? null,
            'supplierName' => $po['supplier'] ?? null,
            'poNumber' => $po['poNumber'] ?? null,
            'poStatus' => $po['status'] ?? null
        ];
    } catch (Exception $e) {
        error_log("getSupplierFromPO error: " . $e->getMessage());
        return null;
    }
}

/**
 * Get supplier information from Receiving record
 * 
 * @param PDO $db Database connection
 * @param string $receivingId Receiving ID
 * @return array|null Supplier data or null if not found
 */
function getSupplierFromReceiving($db, $receivingId) {
    try {
        $stmt = $db->prepare("SELECT data FROM receivings WHERE id = ?");
        $stmt->execute([$receivingId]);
        $result = $stmt->fetch();
        
        if (!$result) {
            return null;
        }
        
        $receiving = json_decode($result['data'], true);
        $poId = $receiving['poId'] ?? null;
        
        if (!$poId) {
            return null;
        }
        
        return getSupplierFromPO($db, $poId);
    } catch (Exception $e) {
        error_log("getSupplierFromReceiving error: " . $e->getMessage());
        return null;
    }
}

/**
 * Validate that supplier ID exists in suppliers table
 * 
 * @param PDO $db Database connection
 * @param string $supplierId Supplier ID to validate
 * @return bool True if valid, false otherwise
 */
function validateSupplierExists($db, $supplierId) {
    try {
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM suppliers WHERE id = ?");
        $stmt->execute([$supplierId]);
        $result = $stmt->fetch();
        
        return $result['count'] > 0;
    } catch (Exception $e) {
        error_log("validateSupplierExists error: " . $e->getMessage());
        return false;
    }
}

/**
 * Validate supplier consistency for POR creation
 * Ensures POR supplier matches the PO supplier
 * 
 * @param PDO $db Database connection
 * @param string $poId Purchase Order ID
 * @param string $supplierId Supplier ID being used for POR
 * @return array ['valid' => bool, 'error' => string|null, 'correctSupplier' => array|null]
 */
function validatePORSupplierConsistency($db, $poId, $supplierId) {
    $result = [
        'valid' => false,
        'error' => null,
        'correctSupplier' => null
    ];
    
    // Get supplier from PO
    $poSupplier = getSupplierFromPO($db, $poId);
    
    if (!$poSupplier) {
        $result['error'] = "Purchase Order not found (ID: $poId)";
        return $result;
    }
    
    if (!$poSupplier['supplierId']) {
        $result['error'] = "Purchase Order does not have a supplier assigned";
        return $result;
    }
    
    $result['correctSupplier'] = $poSupplier;
    
    // Validate supplier match
    if ($supplierId !== $poSupplier['supplierId']) {
        $result['error'] = "Supplier mismatch: POR supplier ($supplierId) does not match PO supplier ({$poSupplier['supplierId']} - {$poSupplier['supplierName']})";
        return $result;
    }
    
    // Validate supplier exists
    if (!validateSupplierExists($db, $supplierId)) {
        $result['error'] = "Supplier ID does not exist in supplier master data: $supplierId";
        return $result;
    }
    
    $result['valid'] = true;
    return $result;
}

/**
 * Validate PO status is appropriate for receiving
 * 
 * @param PDO $db Database connection
 * @param string $poId Purchase Order ID
 * @return array ['valid' => bool, 'error' => string|null, 'status' => string|null]
 */
function validatePOStatusForReceiving($db, $poId) {
    $result = [
        'valid' => false,
        'error' => null,
        'status' => null
    ];
    
    try {
        $stmt = $db->prepare("SELECT data FROM purchase_orders WHERE id = ?");
        $stmt->execute([$poId]);
        $poResult = $stmt->fetch();
        
        if (!$poResult) {
            $result['error'] = "Purchase Order not found";
            return $result;
        }
        
        $po = json_decode($poResult['data'], true);
        $status = $po['status'] ?? 'Unknown';
        $result['status'] = $status;
        
        // Valid statuses for receiving
        $validStatuses = ['Approved', 'Partially Received'];
        
        if (!in_array($status, $validStatuses)) {
            $result['error'] = "Purchase Order must be Approved before receiving. Current status: $status";
            return $result;
        }
        
        $result['valid'] = true;
        return $result;
        
    } catch (Exception $e) {
        $result['error'] = "Error validating PO status: " . $e->getMessage();
        return $result;
    }
}

/**
 * Validate complete POR creation request
 * Comprehensive validation for all supplier and business rules
 * 
 * @param PDO $db Database connection
 * @param array $porData POR creation data
 * @return array ['valid' => bool, 'errors' => array, 'supplierInfo' => array|null]
 */
function validatePORCreation($db, $porData) {
    $result = [
        'valid' => true,
        'errors' => [],
        'supplierInfo' => null
    ];
    
    // Required fields
    $requiredFields = ['purchaseOrderId', 'poNumber', 'supplierId', 'supplierName'];
    foreach ($requiredFields as $field) {
        if (empty($porData[$field])) {
            $result['errors'][] = "Required field missing: $field";
            $result['valid'] = false;
        }
    }
    
    if (!$result['valid']) {
        return $result;
    }
    
    // Validate PO exists and status
    $poValidation = validatePOStatusForReceiving($db, $porData['purchaseOrderId']);
    if (!$poValidation['valid']) {
        $result['errors'][] = $poValidation['error'];
        $result['valid'] = false;
    }
    
    // Validate supplier consistency
    $supplierValidation = validatePORSupplierConsistency(
        $db,
        $porData['purchaseOrderId'],
        $porData['supplierId']
    );
    
    if (!$supplierValidation['valid']) {
        $result['errors'][] = $supplierValidation['error'];
        $result['valid'] = false;
    } else {
        $result['supplierInfo'] = $supplierValidation['correctSupplier'];
    }
    
    return $result;
}

/**
 * Get full supplier details from supplier master
 * 
 * @param PDO $db Database connection
 * @param string $supplierId Supplier ID
 * @return array|null Supplier details or null
 */
function getSupplierDetails($db, $supplierId) {
    try {
        $stmt = $db->prepare("SELECT data FROM suppliers WHERE id = ?");
        $stmt->execute([$supplierId]);
        $result = $stmt->fetch();
        
        if (!$result) {
            return null;
        }
        
        $supplier = json_decode($result['data'], true);
        
        return [
            'id' => $supplier['id'] ?? $supplierId,
            'name' => $supplier['name'] ?? '',
            'company' => $supplier['company'] ?? '',
            'contactPerson' => $supplier['contactPerson'] ?? '',
            'phone' => $supplier['phone'] ?? '',
            'email' => $supplier['email'] ?? '',
            'address' => $supplier['address'] ?? ''
        ];
    } catch (Exception $e) {
        error_log("getSupplierDetails error: " . $e->getMessage());
        return null;
    }
}

/**
 * Validate supplier data consistency across entire transaction chain
 * For data integrity checking
 * 
 * @param PDO $db Database connection
 * @param string $porId POR ID to validate
 * @return array Validation report
 */
function validateTransactionSupplierChain($db, $porId) {
    $report = [
        'valid' => true,
        'porId' => $porId,
        'checks' => []
    ];
    
    try {
        // Get POR
        $porStmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
        $porStmt->execute([$porId]);
        $por = $porStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$por) {
            $report['valid'] = false;
            $report['checks'][] = [
                'check' => 'POR Exists',
                'status' => 'FAIL',
                'message' => 'POR not found'
            ];
            return $report;
        }
        
        $report['checks'][] = [
            'check' => 'POR Exists',
            'status' => 'PASS',
            'message' => "POR {$por['por_number']} found"
        ];
        
        // Get PO
        $poStmt = $db->prepare("SELECT data FROM purchase_orders WHERE id = ?");
        $poStmt->execute([$por['purchase_order_id']]);
        $poResult = $poStmt->fetch();
        
        if (!$poResult) {
            $report['valid'] = false;
            $report['checks'][] = [
                'check' => 'PO Exists',
                'status' => 'FAIL',
                'message' => "PO not found: {$por['purchase_order_id']}"
            ];
            return $report;
        }
        
        $po = json_decode($poResult['data'], true);
        $report['checks'][] = [
            'check' => 'PO Exists',
            'status' => 'PASS',
            'message' => "PO {$po['poNumber']} found"
        ];
        
        // Check supplier consistency
        if ($por['supplier_id'] === $po['supplierId']) {
            $report['checks'][] = [
                'check' => 'Supplier Consistency (POR-PO)',
                'status' => 'PASS',
                'message' => "Supplier IDs match: {$por['supplier_id']}"
            ];
        } else {
            $report['valid'] = false;
            $report['checks'][] = [
                'check' => 'Supplier Consistency (POR-PO)',
                'status' => 'FAIL',
                'message' => "Mismatch - POR: {$por['supplier_id']}, PO: {$po['supplierId']}"
            ];
        }
        
        // Check supplier exists in master
        $supplierExists = validateSupplierExists($db, $por['supplier_id']);
        if ($supplierExists) {
            $report['checks'][] = [
                'check' => 'Supplier Master Reference',
                'status' => 'PASS',
                'message' => "Supplier exists in master data"
            ];
        } else {
            $report['valid'] = false;
            $report['checks'][] = [
                'check' => 'Supplier Master Reference',
                'status' => 'FAIL',
                'message' => "Supplier not found in master: {$por['supplier_id']}"
            ];
        }
        
    } catch (Exception $e) {
        $report['valid'] = false;
        $report['checks'][] = [
            'check' => 'Validation Process',
            'status' => 'ERROR',
            'message' => $e->getMessage()
        ];
    }
    
    return $report;
}

/**
 * Auto-populate supplier information from PO
 * Used when creating POR to ensure supplier consistency
 * 
 * @param PDO $db Database connection
 * @param string $poId Purchase Order ID
 * @return array|null Auto-populated supplier data
 */
function autoPopulateSupplierFromPO($db, $poId) {
    $supplierInfo = getSupplierFromPO($db, $poId);
    
    if (!$supplierInfo || !$supplierInfo['supplierId']) {
        return null;
    }
    
    // Get full details from supplier master
    $supplierDetails = getSupplierDetails($db, $supplierInfo['supplierId']);
    
    return [
        'supplierId' => $supplierInfo['supplierId'],
        'supplierName' => $supplierInfo['supplierName'],
        'supplierDetails' => $supplierDetails,
        'readonly' => true, // Flag to indicate this should not be user-editable
        'source' => 'Purchase Order'
    ];
}
?>
