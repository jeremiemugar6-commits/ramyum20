<?php
/**
 * Clear Sample/Demo POR Data
 * This script removes all POR records from the database
 */

require_once __DIR__ . '/includes/functions.php';

$db = getDB();

try {
    // Start transaction
    $db->beginTransaction();
    
    // Count records before deletion
    $stmt = $db->query("SELECT COUNT(*) as count FROM proof_of_receiving");
    $beforeCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    // Delete all POR items first (child records)
    $db->exec("DELETE FROM proof_of_receiving_items");
    $itemsDeleted = $db->exec("SELECT ROW_COUNT()");
    
    // Delete all POR records (parent records)
    $db->exec("DELETE FROM proof_of_receiving");
    
    // Count records after deletion
    $stmt = $db->query("SELECT COUNT(*) as count FROM proof_of_receiving");
    $afterCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    
    // Reset auto-increment (optional)
    $db->exec("ALTER TABLE proof_of_receiving AUTO_INCREMENT = 1");
    $db->exec("ALTER TABLE proof_of_receiving_items AUTO_INCREMENT = 1");
    
    // Commit transaction
    $db->commit();
    
    echo "<h2>✅ Sample POR Data Cleared Successfully</h2>";
    echo "<ul>";
    echo "<li><strong>POR Records Deleted:</strong> {$beforeCount}</li>";
    echo "<li><strong>POR Items Deleted:</strong> All associated items</li>";
    echo "<li><strong>Remaining POR Records:</strong> {$afterCount}</li>";
    echo "</ul>";
    
    echo "<p style='color:green; font-weight:bold;'>✓ Database cleaned successfully!</p>";
    echo "<p><a href='dashboard.php#por' style='padding:10px 20px; background:#FF7A00; color:white; text-decoration:none; border-radius:5px;'>Go to POR Module</a></p>";
    echo "<p><a href='clear-por-sample-data.php' onclick='return confirm(\"Are you sure you want to run this again?\")' style='padding:10px 20px; background:#666; color:white; text-decoration:none; border-radius:5px;'>Run Again</a></p>";
    
} catch (Exception $e) {
    // Rollback on error
    $db->rollBack();
    echo "<h2 style='color:red;'>❌ Error Clearing Data</h2>";
    echo "<p style='color:red;'>{$e->getMessage()}</p>";
}
?>

<style>
    body {
        font-family: Arial, sans-serif;
        max-width: 800px;
        margin: 50px auto;
        padding: 20px;
        background: #f5f5f5;
    }
    h2 {
        color: #333;
        border-bottom: 2px solid #FF7A00;
        padding-bottom: 10px;
    }
    ul {
        background: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    li {
        padding: 8px 0;
        border-bottom: 1px solid #eee;
    }
    li:last-child {
        border-bottom: none;
    }
</style>
