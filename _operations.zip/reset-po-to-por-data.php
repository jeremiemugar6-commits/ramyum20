<?php
/**
 * Reset All Data: Purchase Orders → Receiving → POR
 * This will delete all PO, Receiving, and POR records for a fresh start
 * WARNING: This is irreversible! All data will be permanently deleted.
 */

require_once __DIR__ . '/config/database.php';

$db = getDB();

// Check if confirmation was provided
$confirmed = $_POST['confirm'] ?? false;

if (!$confirmed) {
    // Show confirmation page
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Reset Data - Confirmation Required</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 50px auto;
                padding: 20px;
                background: #f5f5f5;
            }
            .warning-box {
                background: #FEE2E2;
                border: 3px solid #EF4444;
                padding: 30px;
                border-radius: 12px;
                margin: 20px 0;
            }
            h1 {
                color: #991B1B;
                margin: 0 0 20px 0;
            }
            .warning-icon {
                font-size: 3rem;
                text-align: center;
                margin-bottom: 20px;
            }
            .data-list {
                background: white;
                padding: 20px;
                border-radius: 8px;
                margin: 20px 0;
            }
            .data-list h3 {
                color: #333;
                margin-top: 0;
            }
            .btn {
                padding: 15px 30px;
                font-size: 1.1rem;
                font-weight: 600;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                margin: 10px 10px 10px 0;
                text-decoration: none;
                display: inline-block;
            }
            .btn-danger {
                background: #EF4444;
                color: white;
            }
            .btn-danger:hover {
                background: #DC2626;
            }
            .btn-cancel {
                background: #6B7280;
                color: white;
            }
            .btn-cancel:hover {
                background: #4B5563;
            }
        </style>
    </head>
    <body>
        <div class="warning-box">
            <div class="warning-icon">⚠️</div>
            <h1>⚠️ WARNING: Data Reset</h1>
            <p style="font-size:1.2rem; color:#991B1B; font-weight:600;">
                This action will PERMANENTLY DELETE all the following data:
            </p>
        </div>

        <div class="data-list">
            <h3>🗑️ What Will Be Deleted:</h3>
            <ul style="line-height:2;">
                <li><strong>All Purchase Orders</strong> (PO records and items)</li>
                <li><strong>All Receiving Records</strong> (receiving history)</li>
                <li><strong>All Proof of Receiving (POR)</strong> records and items</li>
                <li><strong>Related Inventory Movements</strong> (from receiving)</li>
            </ul>
        </div>

        <div class="data-list" style="background:#FEF3C7; border:2px solid #F59E0B;">
            <h3 style="color:#92400E;">✓ What Will Be KEPT:</h3>
            <ul style="line-height:2; color:#92400E;">
                <li><strong>Products</strong> - Your product catalog will remain</li>
                <li><strong>Current Inventory</strong> - Stock levels will NOT be changed</li>
                <li><strong>Suppliers</strong> - Supplier information will remain</li>
                <li><strong>Locations</strong> - Warehouse locations will remain</li>
                <li><strong>Users</strong> - User accounts will remain</li>
                <li><strong>Stock Transfers</strong> - Transfer records will remain</li>
            </ul>
        </div>

        <?php
        // Show current counts
        try {
            $poCount = $db->query("SELECT COUNT(*) FROM purchase_orders")->fetchColumn();
            $receivingCount = $db->query("SELECT COUNT(*) FROM receivings")->fetchColumn();
            $porCount = $db->query("SELECT COUNT(*) FROM proof_of_receiving")->fetchColumn();
            $porItemsCount = $db->query("SELECT COUNT(*) FROM proof_of_receiving_items")->fetchColumn();
            
            echo "<div class='data-list' style='background:#DBEAFE;'>";
            echo "<h3 style='color:#1E40AF;'>📊 Current Data Counts:</h3>";
            echo "<ul style='line-height:2; color:#1E40AF; font-weight:600;'>";
            echo "<li>Purchase Orders: <strong>{$poCount}</strong></li>";
            echo "<li>Receiving Records: <strong>{$receivingCount}</strong></li>";
            echo "<li>POR Records: <strong>{$porCount}</strong></li>";
            echo "<li>POR Items: <strong>{$porItemsCount}</strong></li>";
            echo "</ul>";
            echo "</div>";
        } catch (Exception $e) {
            echo "<p style='color:red;'>Error getting counts: {$e->getMessage()}</p>";
        }
        ?>

        <div style="margin-top:30px; padding:20px; background:white; border-radius:8px;">
            <p style="font-size:1.1rem; margin-bottom:20px;">
                <strong>⚠️ This action cannot be undone!</strong><br>
                Are you absolutely sure you want to delete all this data?
            </p>
            
            <form method="POST" onsubmit="return confirm('FINAL CONFIRMATION: This will permanently delete all PO, Receiving, and POR data. Are you ABSOLUTELY SURE?');">
                <input type="hidden" name="confirm" value="yes">
                <button type="submit" class="btn btn-danger">
                    🗑️ YES, DELETE ALL DATA
                </button>
                <a href="dashboard.php" class="btn btn-cancel">
                    ← Cancel (Keep Data)
                </a>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// User confirmed - proceed with deletion
try {
    // Get counts BEFORE starting transaction
    $porCount = 0;
    $receivingCount = 0;
    $poCount = 0;
    
    try {
        $stmt = $db->query("SELECT COUNT(*) FROM proof_of_receiving");
        $porCount = $stmt->fetchColumn();
        $stmt->closeCursor();
    } catch (Exception $e) {
        // Table might not exist or be empty
        $porCount = 0;
    }
    
    try {
        $stmt = $db->query("SELECT COUNT(*) FROM receivings");
        $receivingCount = $stmt->fetchColumn();
        $stmt->closeCursor();
    } catch (Exception $e) {
        $receivingCount = 0;
    }
    
    try {
        $stmt = $db->query("SELECT COUNT(*) FROM purchase_orders");
        $poCount = $stmt->fetchColumn();
        $stmt->closeCursor();
    } catch (Exception $e) {
        $poCount = 0;
    }
    
    // Now start transaction
    $db->beginTransaction();
    
    echo "<html><head><title>Resetting Data...</title>";
    echo "<style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; background: #f5f5f5; }
        .progress { background: white; padding: 20px; border-radius: 8px; margin: 10px 0; border-left: 4px solid #3B82F6; }
        .success { background: #D1FAE5; border-left-color: #10B981; }
        .error { background: #FEE2E2; border-left-color: #EF4444; }
    </style></head><body>";
    
    echo "<h1>🔄 Resetting Data...</h1>";
    
    // 1. Delete POR items first (child records)
    echo "<div class='progress'>Deleting POR items...</div>";
    flush();
    $db->exec("DELETE FROM proof_of_receiving_items");
    echo "<div class='progress success'>✓ Deleted POR items</div>";
    flush();
    
    // 2. Delete POR records
    echo "<div class='progress'>Deleting POR records...</div>";
    flush();
    $db->exec("DELETE FROM proof_of_receiving");
    echo "<div class='progress success'>✓ Deleted {$porCount} POR records</div>";
    flush();
    
    // 3. Delete receiving records
    echo "<div class='progress'>Deleting Receiving records...</div>";
    flush();
    $db->exec("DELETE FROM receivings");
    echo "<div class='progress success'>✓ Deleted {$receivingCount} Receiving records</div>";
    flush();
    
    // 4. Delete inventory movements related to receiving/POR
    echo "<div class='progress'>Deleting related Inventory Movements...</div>";
    flush();
    $db->exec("DELETE FROM inventory_movements WHERE JSON_EXTRACT(data, '$.referenceType') IN ('POR', 'Receiving')");
    echo "<div class='progress success'>✓ Deleted related Inventory Movements</div>";
    flush();
    
    // 5. Delete purchase orders
    echo "<div class='progress'>Deleting Purchase Orders...</div>";
    flush();
    $db->exec("DELETE FROM purchase_orders");
    echo "<div class='progress success'>✓ Deleted {$poCount} Purchase Orders</div>";
    flush();
    
    // Commit transaction BEFORE ALTER TABLE
    if ($db->inTransaction()) {
        $db->commit();
    }
    
    // 6. Reset auto-increment (OUTSIDE transaction - ALTER TABLE causes implicit commit)
    echo "<div class='progress'>Resetting auto-increment counters...</div>";
    flush();
    try {
        $db->exec("ALTER TABLE proof_of_receiving AUTO_INCREMENT = 1");
        $db->exec("ALTER TABLE proof_of_receiving_items AUTO_INCREMENT = 1");
        echo "<div class='progress success'>✓ Reset counters</div>";
    } catch (Exception $e) {
        echo "<div class='progress success'>⚠ Skipped counter reset</div>";
    }
    flush();
    
    echo "<div style='background:#D1FAE5; border:3px solid #10B981; padding:30px; border-radius:12px; margin:30px 0; text-align:center;'>";
    echo "<h2 style='color:#065F46; margin:0 0 20px 0;'>✓ Data Reset Complete!</h2>";
    echo "<p style='color:#065F46; font-size:1.2rem;'>All Purchase Order, Receiving, and POR data has been deleted.</p>";
    echo "<p style='color:#065F46;'><strong>Your system is now ready for fresh, accurate data!</strong></p>";
    echo "</div>";
    
    echo "<div style='background:white; padding:20px; border-radius:8px;'>";
    echo "<h3>Summary:</h3>";
    echo "<ul style='line-height:2;'>";
    echo "<li>Purchase Orders deleted: <strong>{$poCount}</strong></li>";
    echo "<li>Receiving records deleted: <strong>{$receivingCount}</strong></li>";
    echo "<li>POR records deleted: <strong>{$porCount}</strong></li>";
    echo "<li>POR items deleted: <strong>All</strong></li>";
    echo "<li>Inventory movements cleaned: <strong>✓</strong></li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<p style='margin-top:30px;'><a href='dashboard.php' style='padding:12px 24px; background:#FF7A00; color:white; text-decoration:none; border-radius:8px; font-weight:600; display:inline-block;'>→ Go to Dashboard</a></p>";
    
    echo "</body></html>";
    
} catch (Exception $e) {
    // Only rollback if transaction was started
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    
    echo "<html><head><title>Reset Failed</title>";
    echo "<style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; background: #f5f5f5; }
        .error { background: #FEE2E2; border: 3px solid #EF4444; padding: 30px; border-radius: 12px; }
    </style></head><body>";
    echo "<div class='error'>";
    echo "<h2>✗ Error During Reset</h2>";
    echo "<p><strong>Error:</strong> {$e->getMessage()}</p>";
    echo "<p><strong>Line:</strong> {$e->getLine()}</p>";
    echo "<p style='margin-top:20px;'><a href='reset-po-to-por-data.php' style='padding:12px 24px; background:#6B7280; color:white; text-decoration:none; border-radius:8px; font-weight:600;'>← Try Again</a></p>";
    echo "</div>";
    echo "</body></html>";
}
?>
