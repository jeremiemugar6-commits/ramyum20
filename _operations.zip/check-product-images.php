<?php
/**
 * Check Product Images Script
 * Verify what image data is stored in products
 */

require_once __DIR__ . '/config/database.php';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Check Product Images - RAMYUM</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1400px; margin: 0 auto; padding: 20px; }
        h2 { color: #FF7A00; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 0.9rem; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #FF7A00; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        .has-image { background-color: #d4edda; }
        .no-image { background-color: #f8d7da; }
        img { max-width: 80px; max-height: 80px; object-fit: cover; }
        .status { padding: 4px 8px; border-radius: 4px; font-size: 0.85rem; font-weight: 600; }
        .status-ok { background-color: #d4edda; color: #155724; }
        .status-missing { background-color: #fff3cd; color: #856404; }
        .status-error { background-color: #f8d7da; color: #721c24; }
        pre { background: #f5f5f5; padding: 10px; border-radius: 4px; font-size: 0.8rem; max-height: 200px; overflow: auto; }
    </style>
</head>
<body>
    <h1>🔍 Product Images Verification</h1>

<?php
try {
    $pdo = get_database_connection();
    
    echo "<h2>Product Image Status</h2>";
    
    // Get all products
    $stmt = $pdo->prepare("SELECT id, data FROM products ORDER BY id");
    $stmt->execute();
    
    $products = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $data = json_decode($row['data'], true);
        $products[] = [
            'id' => $row['id'],
            'name' => $data['name'] ?? 'Unknown',
            'sku' => $data['sku'] ?? $row['id'],
            'image' => $data['image'] ?? null,
            'data' => $data
        ];
    }
    
    echo "<p><strong>Total Products:</strong> " . count($products) . "</p>";
    
    $withImages = 0;
    $withoutImages = 0;
    $imageExists = 0;
    $imageMissing = 0;
    
    foreach ($products as $product) {
        if (!empty($product['image'])) {
            $withImages++;
            $filePath = __DIR__ . '/' . $product['image'];
            if (file_exists($filePath)) {
                $imageExists++;
            } else {
                $imageMissing++;
            }
        } else {
            $withoutImages++;
        }
    }
    
    echo "<div style='display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin: 20px 0;'>";
    echo "<div style='background: #e3f2fd; padding: 15px; border-radius: 8px;'>";
    echo "<div style='font-size: 2rem; font-weight: bold; color: #1976d2;'>{$withImages}</div>";
    echo "<div style='color: #555;'>Products with Image Path</div>";
    echo "</div>";
    
    echo "<div style='background: #fff3cd; padding: 15px; border-radius: 8px;'>";
    echo "<div style='font-size: 2rem; font-weight: bold; color: #856404;'>{$withoutImages}</div>";
    echo "<div style='color: #555;'>Products without Image</div>";
    echo "</div>";
    
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 8px;'>";
    echo "<div style='font-size: 2rem; font-weight: bold; color: #155724;'>{$imageExists}</div>";
    echo "<div style='color: #555;'>Image Files Exist</div>";
    echo "</div>";
    
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 8px;'>";
    echo "<div style='font-size: 2rem; font-weight: bold; color: #721c24;'>{$imageMissing}</div>";
    echo "<div style='color: #555;'>Image Files Missing</div>";
    echo "</div>";
    echo "</div>";
    
    echo "<h2>Detailed Product Image Report</h2>";
    echo "<table>";
    echo "<tr>";
    echo "<th>SKU</th>";
    echo "<th>Product Name</th>";
    echo "<th>Image Path</th>";
    echo "<th>Status</th>";
    echo "<th>Preview</th>";
    echo "<th>Full Path</th>";
    echo "</tr>";
    
    foreach ($products as $product) {
        $imagePath = $product['image'];
        $status = '';
        $statusClass = '';
        $preview = '';
        $fullPath = '';
        
        if (empty($imagePath)) {
            $status = 'No Image Path';
            $statusClass = 'status-missing';
            $preview = '<span style="color: #999;">—</span>';
        } else {
            $fullPath = __DIR__ . '/' . $imagePath;
            if (file_exists($fullPath)) {
                $status = '✓ File Exists';
                $statusClass = 'status-ok';
                $preview = "<img src='{$imagePath}' alt='{$product['name']}' onerror=\"this.style.display='none'; this.nextElementSibling.style.display='block';\"><div style='display:none; color:red;'>Failed to load</div>";
            } else {
                $status = '✗ File Missing';
                $statusClass = 'status-error';
                $preview = '<span style="color: red;">File not found</span>';
            }
        }
        
        echo "<tr>";
        echo "<td><strong>{$product['sku']}</strong></td>";
        echo "<td>{$product['name']}</td>";
        echo "<td><code>" . ($imagePath ?: '<em>null</em>') . "</code></td>";
        echo "<td><span class='status {$statusClass}'>{$status}</span></td>";
        echo "<td>{$preview}</td>";
        echo "<td style='font-size: 0.75rem; color: #666;'>" . ($fullPath ?: '—') . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    
    // Show sample product JSON
    if (!empty($products)) {
        echo "<h2>Sample Product JSON (First Product)</h2>";
        echo "<pre>" . json_encode($products[0]['data'], JSON_PRETTY_PRINT) . "</pre>";
    }
    
    // Check if images folder exists
    echo "<h2>Folder Check</h2>";
    $imageFolder = __DIR__ . '/assets/images/products';
    if (is_dir($imageFolder)) {
        echo "<p>✓ <strong>Folder exists:</strong> <code>assets/images/products/</code></p>";
        
        // List files in folder
        $files = scandir($imageFolder);
        $imageFiles = array_filter($files, function($file) use ($imageFolder) {
            return is_file($imageFolder . '/' . $file) && preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $file);
        });
        
        echo "<p><strong>Image files in folder:</strong> " . count($imageFiles) . "</p>";
        
        if (!empty($imageFiles)) {
            echo "<div style='display: grid; grid-template-columns: repeat(6, 1fr); gap: 10px; margin: 20px 0;'>";
            foreach ($imageFiles as $file) {
                $filePath = 'assets/images/products/' . $file;
                echo "<div style='border: 1px solid #ddd; padding: 8px; border-radius: 4px; text-align: center;'>";
                echo "<img src='{$filePath}' style='max-width: 100px; max-height: 100px; object-fit: cover;' alt='{$file}'>";
                echo "<div style='font-size: 0.7rem; margin-top: 5px; word-break: break-all;'>{$file}</div>";
                echo "</div>";
            }
            echo "</div>";
        }
    } else {
        echo "<p>✗ <strong>Folder does not exist:</strong> <code>assets/images/products/</code></p>";
        echo "<p>Create it with: <code>mkdir -p assets/images/products</code></p>";
    }
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>❌ Database error: " . htmlspecialchars($e->getMessage()) . "</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>

</body>
</html>
