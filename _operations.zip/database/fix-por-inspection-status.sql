-- =====================================================================
-- FIX: POR (Proof of Receiving) shows "Pending" even though it Passed
--
-- ROOT CAUSE
--   The app writes inspection_status = 'Passed' / 'Partial' and item
--   inspection_result = 'Passed', but the columns were declared as
--     inspection_status  ENUM('Pending','In Progress','Completed','Failed')
--     inspection_result  ENUM('Pass','Fail','Conditional','Pending')
--   MySQL/MariaDB (non-strict mode) silently stores a value that is not in
--   the enum list as an EMPTY STRING, and the screen turns "" into "Pending".
--
-- WHAT THIS DOES
--   1. Widens the enums so every value the app uses is accepted
--   2. Re-computes the real result for rows that were saved blank
--      (or left on the legacy 'Completed' / default 'Pending')
--
-- Safe to run more than once. Back up first (phpMyAdmin > Export).
-- =====================================================================

-- 1) Widen the enums (existing values keep their position; new ones are appended)
ALTER TABLE `proof_of_receiving`
  MODIFY `inspection_status`
    ENUM('Pending','In Progress','Completed','Failed',
         'Passed','Partial','Pending Inspection','Approved','Rejected','Partially Approved')
    NOT NULL DEFAULT 'Pending',
  MODIFY `status`
    ENUM('Draft','Completed','Cancelled','Archived')
    NOT NULL DEFAULT 'Draft';

ALTER TABLE `proof_of_receiving_items`
  MODIFY `inspection_result`
    ENUM('Pass','Fail','Conditional','Pending','Passed','Failed','Partial')
    NOT NULL DEFAULT 'Pending';

-- 2a) Item level: blank value -> derive from the item quantities
UPDATE `proof_of_receiving_items`
SET `inspection_result` = CASE
      WHEN received_quantity <= 0 AND accepted_quantity <= 0 AND rejected_quantity <= 0 THEN 'Pending'
      WHEN rejected_quantity > 0 OR accepted_quantity <= 0 THEN 'Failed'
      WHEN accepted_quantity >= received_quantity THEN 'Passed'
      ELSE 'Partial'
    END
WHERE `inspection_result` + 0 = 0;

-- 2b) Item level: items of an already-completed POR that still say Pending
UPDATE `proof_of_receiving_items` i
JOIN `proof_of_receiving` p ON p.id = i.por_id
SET i.`inspection_result` = CASE
      WHEN i.received_quantity <= 0 AND i.accepted_quantity <= 0 AND i.rejected_quantity <= 0 THEN 'Pending'
      WHEN i.rejected_quantity > 0 OR i.accepted_quantity <= 0 THEN 'Failed'
      WHEN i.accepted_quantity >= i.received_quantity THEN 'Passed'
      ELSE 'Partial'
    END
WHERE p.status = 'Completed' AND i.`inspection_result` = 'Pending';

-- 2c) Item level: old spellings -> canonical
UPDATE `proof_of_receiving_items` SET `inspection_result` = 'Passed' WHERE `inspection_result` = 'Pass';
UPDATE `proof_of_receiving_items` SET `inspection_result` = 'Failed' WHERE `inspection_result` = 'Fail';

-- 3) Header level: blank / 'Completed' / stuck on 'Pending' although the POR is Completed
UPDATE `proof_of_receiving`
SET `inspection_status` = CASE
      WHEN total_received <= 0 AND total_accepted <= 0 AND total_rejected <= 0 THEN 'Pending'
      WHEN total_rejected > 0 OR total_accepted <= 0 THEN 'Failed'
      WHEN total_accepted >= total_received THEN 'Passed'
      ELSE 'Partial'
    END
WHERE `inspection_status` + 0 = 0
   OR `inspection_status` = 'Completed'
   OR (`status` = 'Completed' AND `inspection_status` IN ('Pending', 'In Progress', 'Pending Inspection'));

-- 4) Header level: old spellings -> canonical
UPDATE `proof_of_receiving` SET `inspection_status` = 'Pending' WHERE `inspection_status` = 'Pending Inspection';
UPDATE `proof_of_receiving` SET `inspection_status` = 'Passed'  WHERE `inspection_status` = 'Approved';
UPDATE `proof_of_receiving` SET `inspection_status` = 'Failed'  WHERE `inspection_status` = 'Rejected';
UPDATE `proof_of_receiving` SET `inspection_status` = 'Partial' WHERE `inspection_status` = 'Partially Approved';

-- 5) Check the result
SELECT por_number, status, inspection_status, total_received, total_accepted, total_rejected
FROM `proof_of_receiving` ORDER BY created_at DESC;
