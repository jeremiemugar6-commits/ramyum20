<?php
require_once 'config/database.php';

$db = getDB();

echo "DATABASE SCHEMA ANALYSIS\n";
echo str_repeat("=", 80) . "\n\n";

// Get all tables
$tables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

foreach ($tables as $table) {
    echo "TABLE: $table\n";
    echo str_repeat("-", 80) . "\n";
    
    $columns = $db->query("DESCRIBE $table")->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($columns as $col) {
        echo sprintf("  %-25s %-20s %s\n", 
            $col['Field'], 
            $col['Type'],
            $col['Key'] ? "[$col[Key]]" : ""
        );
    }
    
    echo "\n";
}
