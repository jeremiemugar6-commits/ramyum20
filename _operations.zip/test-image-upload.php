<?php
require_once 'includes/auth.php';
$currentUser = require_login_page();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Test Image Upload</title>
    <style>
        body { font-family: Arial; max-width: 600px; margin: 50px auto; padding: 20px; }
        .result { margin-top: 20px; padding: 15px; border-radius: 6px; }
        .success { background: #D1FAE5; color: #065F46; }
        .error { background: #FEE2E2; color: #991B1B; }
        button { padding: 10px 20px; background: #FF7A00; color: white; border: none; border-radius: 6px; cursor: pointer; }
        input[type="file"] { margin: 10px 0; }
        #preview { max-width: 300px; max-height: 300px; margin-top: 10px; }
    </style>
</head>
<body>
    <h1>🧪 Test Image Upload</h1>
    <p><strong>Logged in as:</strong> <?php echo htmlspecialchars($currentUser['name']); ?> (<?php echo htmlspecialchars($currentUser['role']); ?>)</p>
    
    <hr>
    
    <h3>Upload Product Image</h3>
    <input type="file" id="imageFile" accept="image/*">
    <button onclick="testUpload()">Upload Image</button>
    
    <div id="result"></div>
    <img id="preview" style="display:none;">

    <script>
        async function testUpload() {
            const fileInput = document.getElementById('imageFile');
            const resultDiv = document.getElementById('result');
            const preview = document.getElementById('preview');
            
            if (!fileInput.files || !fileInput.files[0]) {
                resultDiv.innerHTML = '<div class="result error">Please select a file first!</div>';
                return;
            }
            
            const file = fileInput.files[0];
            
            // Show file info
            resultDiv.innerHTML = `<div class="result">
                <strong>Uploading:</strong><br>
                File: ${file.name}<br>
                Size: ${(file.size / 1024).toFixed(2)} KB<br>
                Type: ${file.type}<br>
                <br>
                <em>Please wait...</em>
            </div>`;
            
            try {
                const formData = new FormData();
                formData.append('image', file);
                formData.append('type', 'product');
                
                const response = await fetch('api/upload-image.php', {
                    method: 'POST',
                    body: formData
                });
                
                // Check content type
                const contentType = response.headers.get('content-type');
                console.log('Response Content-Type:', contentType);
                
                // Get raw text first
                const rawText = await response.text();
                console.log('Raw Response:', rawText);
                
                // Try to parse JSON
                let result;
                try {
                    result = JSON.parse(rawText);
                } catch (e) {
                    throw new Error('Invalid JSON response. Server returned: ' + rawText.substring(0, 200));
                }
                
                if (result.success) {
                    resultDiv.innerHTML = `<div class="result success">
                        <strong>✅ Upload Successful!</strong><br><br>
                        <strong>Path:</strong> ${result.data.path}<br>
                        <strong>URL:</strong> ${result.data.url}<br>
                        <strong>Filename:</strong> ${result.data.filename}<br>
                        <strong>Size:</strong> ${(result.data.size / 1024).toFixed(2)} KB<br>
                        <strong>Type:</strong> ${result.data.type}<br>
                    </div>`;
                    
                    // Show preview
                    preview.src = result.data.url;
                    preview.style.display = 'block';
                } else {
                    resultDiv.innerHTML = `<div class="result error">
                        <strong>❌ Upload Failed</strong><br><br>
                        Error: ${result.error}
                    </div>`;
                }
                
            } catch (error) {
                console.error('Upload error:', error);
                resultDiv.innerHTML = `<div class="result error">
                    <strong>❌ Upload Error</strong><br><br>
                    ${error.message}
                </div>`;
            }
        }
    </script>
</body>
</html>
