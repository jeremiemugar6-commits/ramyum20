<?php
/**
 * Test QR Code and POD Workflow
 * This script tests the complete workflow from QR generation to POD confirmation
 */

require_once 'config/database.php';
require_once 'includes/auth.php';

// Simulate admin user for testing
$_SESSION['user'] = [
    'id' => 'u1',
    'username' => 'admin',
    'name' => 'Admin User',
    'email' => 'admin@ramyum.com',
    'role' => 'admin'
];

$db = getDB();

echo "<h1>QR Code & POD Workflow Test</h1>\n";
echo "<pre>\n";

// TEST 1: Get an approved transfer
echo "=== TEST 1: Finding Approved Transfer ===\n";
$stmt = $db->query("SELECT id, data FROM stock_transfers WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) = 'Approved' LIMIT 1");
$result = $stmt->fetch();

if ($result) {
    $transfer = json_decode($result['data'], true);
    echo "✓ Found approved transfer: {$transfer['transferNumber']}\n";
    echo "  Source: {$transfer['sourceLocationName']}\n";
    echo "  Destination: {$transfer['destinationLocationName']}\n";
    echo "  Status: {$transfer['status']}\n";
    echo "  Items: " . count($transfer['items']) . "\n\n";
    
    $transferId = $result['id'];
    
    // TEST 2: Check if QR already exists
    echo "=== TEST 2: Check Existing QR Code ===\n";
    $stmt = $db->prepare("SELECT * FROM proof_of_delivery WHERE transfer_id = ?");
    $stmt->execute([$transferId]);
    $existingPOD = $stmt->fetch();
    
    if ($existingPOD) {
        echo "✓ QR Code already exists\n";
        echo "  Token: {$existingPOD['qr_token']}\n";
        echo "  Status: {$existingPOD['status']}\n\n";
        $qrToken = $existingPOD['qr_token'];
    } else {
        echo "✗ No QR code found. Generating new one...\n";
        
        // TEST 3: Generate QR Code
        echo "\n=== TEST 3: Generate QR Code ===\n";
        $qrToken = 'POD-' . strtoupper(bin2hex(random_bytes(16)));
        $podId = 'pod_test_' . time();
        
        $stmt = $db->prepare("
            INSERT INTO proof_of_delivery (id, transfer_id, transfer_number, qr_token, status)
            VALUES (?, ?, ?, ?, 'Pending')
        ");
        
        $stmt->execute([
            $podId,
            $transferId,
            $transfer['transferNumber'],
            $qrToken
        ]);
        
        echo "✓ QR Code generated successfully\n";
        echo "  POD ID: $podId\n";
        echo "  Token: $qrToken\n";
        echo "  URL: /scan-pod.php?token=$qrToken\n\n";
        
        // Update transfer status to In Transit
        $transfer['status'] = 'In Transit';
        $transfer['inTransitAt'] = date('Y-m-d\TH:i:s.v\Z');
        
        $stmt = $db->prepare("UPDATE stock_transfers SET data = ? WHERE id = ?");
        $stmt->execute([json_encode($transfer), $transferId]);
        
        echo "✓ Transfer status updated to 'In Transit'\n\n";
    }
    
    // TEST 4: Verify QR Token
    echo "=== TEST 4: Verify QR Token ===\n";
    $stmt = $db->prepare("SELECT * FROM proof_of_delivery WHERE qr_token = ?");
    $stmt->execute([$qrToken]);
    $pod = $stmt->fetch();
    
    if ($pod) {
        echo "✓ QR Token verified successfully\n";
        echo "  Transfer Number: {$pod['transfer_number']}\n";
        echo "  Status: {$pod['status']}\n";
        
        if ($pod['status'] !== 'Received') {
            // TEST 5: Simulate POD Confirmation
            echo "\n=== TEST 5: Simulate POD Confirmation ===\n";
            
            $confirmationNotes = "Test delivery confirmation - all items received in good condition";
            
            $stmt = $db->prepare("
                UPDATE proof_of_delivery 
                SET received_at = NOW(), 
                    received_by = 'admin',
                    confirmation_notes = ?,
                    status = 'Received'
                WHERE qr_token = ?
            ");
            $stmt->execute([$confirmationNotes, $qrToken]);
            
            echo "✓ POD confirmed successfully\n";
            echo "  Received by: admin\n";
            echo "  Notes: $confirmationNotes\n\n";
            
            // TEST 6: Update Stock Transfer Status
            echo "=== TEST 6: Update Stock Transfer Status ===\n";
            $stmt = $db->prepare("SELECT data FROM stock_transfers WHERE id = ?");
            $stmt->execute([$transferId]);
            $transferData = json_decode($stmt->fetch()['data'], true);
            
            $transferData['status'] = 'Completed';
            $transferData['completedAt'] = date('Y-m-d\TH:i:s.v\Z');
            $transferData['completedBy'] = 'admin';
            
            $stmt = $db->prepare("UPDATE stock_transfers SET data = ? WHERE id = ?");
            $stmt->execute([json_encode($transferData), $transferId]);
            
            echo "✓ Stock Transfer status updated to 'Completed'\n\n";
        } else {
            echo "\n=== Transfer Already Received ===\n";
            echo "  Received at: {$pod['received_at']}\n";
            echo "  Received by: {$pod['received_by']}\n";
            if ($pod['confirmation_notes']) {
                echo "  Notes: {$pod['confirmation_notes']}\n";
            }
            echo "\n";
        }
    } else {
        echo "✗ QR Token verification failed\n\n";
    }
    
    // TEST 7: Verify Final State
    echo "=== TEST 7: Verify Final State ===\n";
    $stmt = $db->prepare("SELECT data FROM stock_transfers WHERE id = ?");
    $stmt->execute([$transferId]);
    $finalTransfer = json_decode($stmt->fetch()['data'], true);
    
    echo "Transfer Number: {$finalTransfer['transferNumber']}\n";
    echo "Status: {$finalTransfer['status']}\n";
    echo "Source: {$finalTransfer['sourceLocationName']}\n";
    echo "Destination: {$finalTransfer['destinationLocationName']}\n";
    
    if (isset($finalTransfer['completedAt'])) {
        echo "Completed At: {$finalTransfer['completedAt']}\n";
        echo "Completed By: {$finalTransfer['completedBy']}\n";
    }
    
    echo "\n=== TEST SUMMARY ===\n";
    echo "✓ All tests completed successfully!\n\n";
    
    echo "Test Results:\n";
    echo "  1. ✓ Found approved transfer\n";
    echo "  2. ✓ Checked existing QR code\n";
    echo "  3. ✓ Generated/Verified QR code\n";
    echo "  4. ✓ Verified QR token\n";
    echo "  5. ✓ Confirmed POD\n";
    echo "  6. ✓ Updated transfer status\n";
    echo "  7. ✓ Verified final state\n";
    
} else {
    echo "✗ No approved transfers found in database\n";
    echo "Please approve at least one transfer first.\n";
}

echo "</pre>\n";
