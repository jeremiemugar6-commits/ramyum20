<?php
require_once __DIR__ . '/config/mail.php';
require_once __DIR__ . '/includes/functions.php';

// Test email sending functionality
function test_email_sending() {
    echo "<h2>Email Configuration Test</h2>";
    
    // Check if SMTP credentials are configured
    if (SMTP_HOST === '') {
        echo "<p style='color: red;'>❌ SMTP_HOST is not configured in .env file</p>";
        return false;
    }
    
    echo "<p>✅ SMTP Host: " . SMTP_HOST . "</p>";
    echo "<p>✅ SMTP Port: " . SMTP_PORT . "</p>";
    echo "<p>✅ SMTP Username: " . SMTP_USERNAME . "</p>";
    echo "<p>✅ SMTP From Email: " . SMTP_FROM_EMAIL . "</p>";
    
    if (SMTP_PASSWORD === '' || SMTP_PASSWORD === 'your-app-password-here') {
        echo "<p style='color: red;'>❌ SMTP_PASSWORD is not configured properly in .env file</p>";
        return false;
    }
    echo "<p>✅ SMTP Password is configured</p>";
    
    // Test sending an email
    echo "<h3>Sending Test Email...</h3>";
    
    $testEmail = SMTP_USERNAME; // Send to the same email as configured
    $testName = "Test User";
    $testCode = "123456";
    
    $success = send_otp_email_smtp($testEmail, $testName, $testCode, 5);
    
    if ($success) {
        echo "<p style='color: green;'>✅ <strong>SUCCESS!</strong> Test email sent to: " . $testEmail . "</p>";
        echo "<p>Check your inbox for the OTP email with code: <strong>" . $testCode . "</strong></p>";
        return true;
    } else {
        echo "<p style='color: red;'>❌ <strong>FAILED!</strong> Could not send email. Check your SMTP credentials and internet connection.</p>";
        echo "<p>Make sure you're using an App Password for Gmail (not your regular password).</p>";
        return false;
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Email Test - RAMYUM</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        h2, h3 { color: #FF7A00; }
    </style>
</head>
<body>
    <h1>RAMYUM Email Configuration Test</h1>
    
    <?php 
    test_email_sending();
    ?>
    
    <hr>
    <h3>Instructions:</h3>
    <ol>
        <li>Update the <code>.env</code> file with your real email credentials</li>
        <li>For Gmail: Enable 2FA and generate an App Password</li>
        <li>Run this test again to verify email sending works</li>
        <li>Once working, delete this test file for security</li>
    </ol>
    
    <h3>Next Steps:</h3>
    <p>Once email sending works, your OTP system will automatically send verification codes to users' email addresses during login.</p>
    
    <p><strong>Security Note:</strong> Delete this test file (<code>test-email.php</code>) once you've confirmed email sending works.</p>
</body>
</html>