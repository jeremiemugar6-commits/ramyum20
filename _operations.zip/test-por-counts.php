<?php
require_once __DIR__ . '/includes/functions.php';

$db = getDB();

// Get POR status counts
$stmt = $db->query("
    SELECT 
        inspection_status, 
        COUNT(*) as count 
    FROM proof_of_receiving 
    GROUP BY inspection_status 
    ORDER BY count DESC
");

echo "<h2>POR Inspection Status Counts:</h2>";
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>Status</th><th>Count</th></tr>";

$total = 0;
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td><strong>{$row['inspection_status']}</strong></td>";
    echo "<td>{$row['count']}</td>";
    echo "</tr>";
    $total += $row['count'];
}

echo "<tr style='background:#f0f0f0;'>";
echo "<td><strong>TOTAL</strong></td>";
echo "<td><strong>{$total}</strong></td>";
echo "</tr>";
echo "</table>";

// Also check some sample records
echo "<h2>Sample POR Records:</h2>";
$stmt = $db->query("SELECT por_number, inspection_status, total_accepted, total_rejected FROM proof_of_receiving LIMIT 10");
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>POR #</th><th>Status</th><th>Accepted</th><th>Rejected</th></tr>";
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td>{$row['por_number']}</td>";
    echo "<td>{$row['inspection_status']}</td>";
    echo "<td style='color:green;'>{$row['total_accepted']}</td>";
    echo "<td style='color:red;'>{$row['total_rejected']}</td>";
    echo "</tr>";
}
echo "</table>";
?>
