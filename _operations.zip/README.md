# RAM-YUM Product & Inventory Operations System — PHP Edition

This is a full PHP + MySQL rewrite of the original vanilla-JS / localStorage
RAM-YUM app. Every module (Dashboard, Products, Inventory, Suppliers,
Purchase Orders, Receiving, Stock Transfer, Reports, Settings) is backed by
a real MySQL database and real PHP server-side sessions instead of the
browser's localStorage.

## What changed vs. the original

| Area | Original | This version |
|---|---|---|
| Data storage | Browser `localStorage` | MySQL (real tables, persists across devices/browsers) |
| Auth | Client-side "session token" in localStorage | PHP server-side sessions (`$_SESSION`), guarded on every protected page |
| Passwords | Client-side SHA-based hash+salt | Server-side `bcrypt` via PHP's `password_hash()` / `password_verify()` |
| Brute-force protection | Tracked in localStorage | Tracked server-side in a `login_attempts` table (5 attempts / 15 min lockout) |
| Sign-up | Public sign-up removed already; admin-created users | Same — only an admin can create accounts, now via a real `users` table |
| Security/audit log | In-browser log | `security_logs` table in MySQL |
| Email verification (EmailJS) | Sent a verification email on user creation | Removed — admin-created accounts are active immediately (no SMTP server was in scope) |

Every operational "collection" (products, suppliers, purchase orders,
receivings, stock transfers, stock adjustments, inventory movements,
categories) is stored as a JSON document in its own MySQL table (`id` +
`data JSON`). This keeps 100% of the original field names — including
nested structures like a purchase order's `items` array or a product's
`locationStock` — working without any changes to the module JavaScript,
while still being real, queryable, persistent MySQL data. The `users`
table is fully relational (proper columns, unique constraints, bcrypt
hashes) since authentication needs that.

## Requirements

- PHP 8.0+
- MySQL 5.7+ / MariaDB 10.3+ (needs native `JSON` column support)
- A web server (Apache/Nginx) or PHP's built-in server for local testing

## Setup

1. **Create the database.**
   ```bash
   mysql -u root -p < database/migrate-to-centralized.sql
   ```
   This creates the `ram_yum_inventory` database, all tables, and seeds demo
   accounts plus sample products/suppliers. 
   
   **Note**: If upgrading from an existing installation, use the web-based
   migration tool at `/migrate-to-centralized-db.php` to preserve your data.

2. **Configure the connection.** Edit `config/database.php`:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'ram_yum_inventory');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   ```

3. **Run it.**
   - With PHP's built-in server (quick local testing):
     ```bash
     php -S localhost:8000
     ```
     then open `http://localhost:8000/index.php`
   - Or point your Apache/Nginx document root at this folder.

## Default demo accounts

| Username | Password | Role |
|---|---|---|
| `admin` | `Admin@123` | admin (full access, incl. Settings → Users) |
| `staff` | `Staff@123` | staff |

**Change these passwords (or the accounts) before using this anywhere
beyond a local demo.**

## Folder structure

```
php-version/
├── api/                 # All backend endpoints (JSON in/out)
│   ├── login.php / logout.php
│   ├── data.php          # generic CRUD for products, suppliers, PO's, etc.
│   ├── users.php          # admin-only user management (bcrypt hashing)
│   ├── profile.php        # update own name/avatar
│   ├── change-password.php
│   ├── clear-login-attempts.php
│   ├── security-logs.php
│   └── reset-demo-data.php
├── config/database.php   # DB connection settings — edit this
├── database/schema.sql   # run this once to create tables + seed data
├── includes/
│   ├── auth.php          # sessions, login lockout, role guards
│   └── functions.php     # JSON helpers, sanitization, audit logging
├── assets/                # CSS, images, and shared JS (unchanged from original)
├── modules/               # per-module JS (unchanged, except settings.js)
├── index.php              # login page
├── dashboard.php          # main app shell (server-guarded)
└── forgot-password.php
```

## Notes

- The generic `api/data.php` endpoint only accepts a whitelisted set of
  collection names (see `ALLOWED_COLLECTIONS` in that file), so arbitrary
  table access isn't possible from the client.
- All protected pages/endpoints require an active PHP session; `dashboard.php`
  will redirect to `index.php` automatically if you're not logged in.
- The "Reset Demo Data" button in Settings (admin only) clears and re-seeds
  products/suppliers/orders — it does **not** touch user accounts.
