<?php
/**
 * Add Sample POD Data for Demo Transfers
 */

require_once 'config/database.php';

$db = getDB();

echo "Adding sample POD data for demo transfers...\n\n";

try {
    // Get transfers that need POD data
    $stmt = $db->query("
        SELECT id, data 
        FROM stock_transfers 
        WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) IN ('Approved', 'In Transit', 'Completed')
        ORDER BY created_at DESC
    ");
    $transfers = $stmt->fetchAll();
    
    foreach ($transfers as $row) {
        $transferId = $row['id'];
        $transfer = json_decode($row['data'], true);
        
        // Check if POD already exists
        $checkStmt = $db->prepare("SELECT id FROM proof_of_delivery WHERE transfer_id = ?");
        $checkStmt->execute([$transferId]);
        
        if ($checkStmt->fetch()) {
            echo "⊙ POD already exists for {$transfer['transferNumber']}\n";
            continue;
        }
        
        // Generate POD for approved or in-transit transfers
        if ($transfer['status'] === 'Approved' || $transfer['status'] === 'In Transit' || $transfer['status'] === 'Completed') {
            $qrToken = 'POD-' . strtoupper(bin2hex(random_bytes(16)));
            $podId = 'pod_' . time() . '_' . bin2hex(random_bytes(4));
            
            // Determine POD status based on transfer status
            $podStatus = 'Pending';
            $receivedAt = null;
            $receivedBy = null;
            $notes = null;
            
            if ($transfer['status'] === 'Completed') {
                $podStatus = 'Received';
                $receivedAt = date('Y-m-d H:i:s');
                $receivedBy = $transfer['completedBy'] ?? 'admin';
                $notes = 'Transfer received and verified. All items in good condition.';
            } elseif ($transfer['status'] === 'In Transit') {
                // Leave as pending
            }
            
            // Insert POD
            $insertStmt = $db->prepare("
                INSERT INTO proof_of_delivery 
                (id, transfer_id, transfer_number, qr_token, status, received_at, received_by, confirmation_notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $insertStmt->execute([
                $podId,
                $transferId,
                $transfer['transferNumber'],
                $qrToken,
                $podStatus,
                $receivedAt,
                $receivedBy,
                $notes
            ]);
            
            echo "✓ Created POD for {$transfer['transferNumber']}\n";
            echo "  Status: {$podStatus}\n";
            echo "  Token: {$qrToken}\n";
            echo "  URL: /scan-pod.php?token={$qrToken}\n\n";
            
            // Update transfer to In Transit if it was Approved
            if ($transfer['status'] === 'Approved') {
                $transfer['status'] = 'In Transit';
                $transfer['inTransitAt'] = date('Y-m-d\TH:i:s.v\Z');
                
                $updateStmt = $db->prepare("UPDATE stock_transfers SET data = ? WHERE id = ?");
                $updateStmt->execute([json_encode($transfer), $transferId]);
                
                echo "  → Updated transfer status to 'In Transit'\n\n";
            }
        }
    }
    
    // Show summary
    echo "\n=== Summary ===\n";
    $stmt = $db->query("SELECT status, COUNT(*) as count FROM proof_of_delivery GROUP BY status");
    $summary = $stmt->fetchAll();
    
    foreach ($summary as $row) {
        echo "{$row['status']}: {$row['count']}\n";
    }
    
    echo "\nSample POD data created successfully!\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
