/**
 * Stock Status Utility
 * Centralized logic for automatic stock status calculation
 * Mirrors server-side logic in includes/stock-status.php
 */

export class StockStatus {
    /**
     * Get automatic stock status based on current quantity
     * 
     * Rules:
     * - 0 = Out of Stock
     * - 1-20 = Low Stock
     * - 21-100 = In Stock
     * - 101+ = Overstock / High Stock
     * 
     * @param {number} currentStock Current stock quantity
     * @returns {string} Stock status
     */
    static getStatus(currentStock) {
        const stock = parseFloat(currentStock) || 0;
        
        if (stock <= 0) {
            return 'Out of Stock';
        } else if (stock < 21) {
            // 1-20.999... = Low Stock
            return 'Low Stock';
        } else if (stock <= 100) {
            // 21-100 = In Stock
            return 'In Stock';
        } else {
            // 101+ = Overstock
            return 'Overstock';
        }
    }

    /**
     * Get emoji for stock status
     * 
     * @param {string} status Stock status
     * @returns {string} Emoji
     */
    static getEmoji(status) {
        switch (status) {
            case 'Out of Stock':
                return '🔴';
            case 'Low Stock':
                return '🟠';
            case 'In Stock':
                return '🟢';
            case 'Overstock':
                return '🔵';
            default:
                return '⚪';
        }
    }

    /**
     * Get CSS class for stock status badge
     * 
     * @param {string} status Stock status
     * @returns {string} CSS class
     */
    static getBadgeClass(status) {
        switch (status) {
            case 'Out of Stock':
                return 'badge-out-of-stock';
            case 'Low Stock':
                return 'badge-low-stock';
            case 'In Stock':
                return 'badge-in-stock';
            case 'Overstock':
                return 'badge-overstock';
            default:
                return 'badge-default';
        }
    }

    /**
     * Get stock status badge HTML
     * 
     * @param {number} currentStock Current stock quantity
     * @param {boolean} compact Use compact styling
     * @returns {string} HTML badge
     */
    static getBadge(currentStock, compact = false) {
        const status = this.getStatus(currentStock);
        const emoji = this.getEmoji(status);
        const badgeClass = this.getBadgeClass(status);
        const compactClass = compact ? ' stock-badge-compact' : '';
        
        return `<span class="stock-badge ${badgeClass}${compactClass}">${emoji} ${status}</span>`;
    }

    /**
     * Update product object with automatic status
     * 
     * @param {Object} product Product object
     * @returns {Object} Updated product object
     */
    static enrichProduct(product) {
        if (product && typeof product.stock !== 'undefined') {
            product.status = this.getStatus(product.stock);
        }
        return product;
    }

    /**
     * Update multiple products with automatic status
     * 
     * @param {Array} products Array of product objects
     * @returns {Array} Updated products
     */
    static enrichProducts(products) {
        return products.map(p => this.enrichProduct(p));
    }

    /**
     * Test all boundary values
     * Returns true if all tests pass
     * 
     * @returns {boolean} All tests passed
     */
    static runTests() {
        const tests = [
            { stock: 0, expected: 'Out of Stock' },
            { stock: 1, expected: 'Low Stock' },
            { stock: 20, expected: 'Low Stock' },
            { stock: 21, expected: 'In Stock' },
            { stock: 50, expected: 'In Stock' },
            { stock: 100, expected: 'In Stock' },
            { stock: 101, expected: 'Overstock' },
            { stock: 150, expected: 'Overstock' },
            { stock: -5, expected: 'Out of Stock' }
        ];

        let allPassed = true;
        console.log('=== Stock Status Tests ===');

        tests.forEach((test, index) => {
            const result = this.getStatus(test.stock);
            const passed = result === test.expected;
            
            console.log(
                `Test ${index + 1}: Stock=${test.stock} => ${result} ` +
                `(Expected: ${test.expected}) ${passed ? '✓' : '✗'}`
            );

            if (!passed) {
                allPassed = false;
            }
        });

        console.log(`\nAll tests ${allPassed ? 'PASSED' : 'FAILED'}`);
        return allPassed;
    }
}

// Auto-run tests in development
if (typeof window !== 'undefined' && window.location.hostname === 'localhost') {
    // Uncomment to run tests automatically:
    // console.log('Stock Status utility loaded. Run StockStatus.runTests() to test.');
}
