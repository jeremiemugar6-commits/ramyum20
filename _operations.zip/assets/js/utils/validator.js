export const Validator = {
    required(value) { return value !== undefined && value !== null && String(value).trim().length > 0; },
    email(value) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value); },
    password(value) { return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/.test(value); },
    confirmPassword(password, confirm) { return password === confirm; },
    positiveNumber(value) { return !isNaN(value) && parseFloat(value) > 0; },
    validateForm(data, rules) {
        let errors = {}; let isValid = true;
        for (let field in rules) {
            const fieldRules = rules[field].split('|');
            const value = data[field];
            for (let rule of fieldRules) {
                if (rule === 'required' && !this.required(value)) { errors[field] = `${field} is required.`; isValid = false; break; }
                if (rule === 'email' && !this.email(value)) { errors[field] = `Please enter a valid email address.`; isValid = false; break; }
                if (rule === 'password' && !this.password(value)) { errors[field] = `Password must be 8+ chars, include uppercase, lowercase, and number.`; isValid = false; break; }
            }
        }
        return { isValid, errors };
    }
};