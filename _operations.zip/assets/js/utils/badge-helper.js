/**
 * Badge Helper Utility for RAM-YUM System
 * Provides consistent status badge generation across all modules
 */

export class BadgeHelper {
    /**
     * Generate Purchase Order status badge
     */
    static getPOStatusBadge(status) {
        const badges = {
            'Draft': {
                class: 'po-status-draft',
                text: 'Draft',
                icon: '📝'
            },
            'Pending': {
                class: 'po-status-pending',
                text: 'Pending',
                icon: '⏳'
            },
            'Approved': {
                class: 'po-status-approved',
                text: 'Approved',
                icon: '✅'
            },
            'Partially Received': {
                class: 'po-status-partially-received',
                text: 'Partial',
                icon: '📦'
            },
            'Received': {
                class: 'po-status-fully-received',
                text: 'Received',
                icon: '✅'
            },
            'Fully Received': {
                class: 'po-status-fully-received',
                text: 'Received',
                icon: '✅'
            },
            'RECEIVED': {
                class: 'po-status-fully-received',
                text: 'Received',
                icon: '✅'
            },
            'Archived': {
                class: 'po-status-archived',
                text: 'Archived',
                icon: '📁'
            },
            'Cancelled': {
                class: 'po-status-cancelled',
                text: 'Cancelled',
                icon: '❌'
            }
        };

        const badge = badges[status] || badges['Draft'];
        return `<span class="status-badge ${badge.class}" title="${status}">
            <span style="margin-right: 4px;">${badge.icon}</span>
            ${badge.text}
        </span>`;
    }

    /**
     * Generate receiving status badge
     */
    static getReceivingStatusBadge(status) {
        const badges = {
            'Not Started': {
                class: 'receiving-status-not-started',
                text: 'Not Started',
                icon: '⏸️'
            },
            'In Progress': {
                class: 'receiving-status-in-progress',
                text: 'In Progress',
                icon: '🔄'
            },
            'Completed': {
                class: 'receiving-status-completed',
                text: 'Completed',
                icon: '✅'
            }
        };

        const badge = badges[status] || badges['Not Started'];
        return `<span class="status-badge ${badge.class}" title="${status}">
            <span style="margin-right: 4px;">${badge.icon}</span>
            ${badge.text}
        </span>`;
    }

    /**
     * Generate stock status badge
     * Uses automatic calculation: 0=Out, 1-20=Low, 21-100=In, 101+=Overstock
     */
    static getStockStatusBadge(stock, reorderLevel = null) {
        const stockNum = parseFloat(stock) || 0;

        let status, badge;
        
        if (stockNum <= 0) {
            status = 'Out of Stock';
            badge = {
                class: 'badge-out-of-stock',
                text: 'Out of Stock',
                icon: '🔴'
            };
        } else if (stockNum < 21) {
            status = 'Low Stock';
            badge = {
                class: 'badge-low-stock',
                text: 'Low Stock',
                icon: '🟠'
            };
        } else if (stockNum <= 100) {
            status = 'In Stock';
            badge = {
                class: 'badge-in-stock',
                text: 'In Stock',
                icon: '🟢'
            };
        } else {
            status = 'Overstock';
            badge = {
                class: 'badge-overstock',
                text: 'Overstock',
                icon: '🔵'
            };
        }

        return `<span class="status-badge ${badge.class}" title="${status}">
            <span style="margin-right: 4px;">${badge.icon}</span>
            ${badge.text}
        </span>`;
    }

    /**
     * Generate movement type badge
     */
    static getMovementTypeBadge(type) {
        const badges = {
            'Stock In': {
                class: 'movement-type-in',
                text: 'Stock In',
                icon: '📈'
            },
            'Stock Out': {
                class: 'movement-type-out',
                text: 'Stock Out',
                icon: '📉'
            },
            'Adjustment': {
                class: 'movement-type-adjustment',
                text: 'Adjustment',
                icon: '⚖️'
            }
        };

        const badge = badges[type] || badges['Adjustment'];
        return `<span class="status-badge ${badge.class}" title="${type}">
            <span style="margin-right: 4px;">${badge.icon}</span>
            ${badge.text}
        </span>`;
    }

    /**
     * Generate reference type badge
     */
    static getReferenceTypeBadge(referenceType, referenceId = '') {
        const badges = {
            'RECEIVING': {
                class: 'reference-receiving',
                text: referenceId || 'Receiving',
                icon: '📦'
            },
            'MANUAL': {
                class: 'reference-manual',
                text: 'Manual',
                icon: '✋'
            },
            'PO': {
                class: 'reference-po',
                text: referenceId || 'Purchase Order',
                icon: '📋'
            }
        };

        const badge = badges[referenceType] || badges['MANUAL'];
        return `<span class="status-badge ${badge.class}" title="${referenceType}: ${referenceId}">
            <span style="margin-right: 4px;">${badge.icon}</span>
            ${badge.text}
        </span>`;
    }

    /**
     * Generate receiving progress badge with percentage
     */
    static getReceivingProgressBadge(receivedItems, totalItems) {
        const percentage = totalItems > 0 ? ((receivedItems / totalItems) * 100).toFixed(1) : 0;
        
        let badge;
        if (percentage == 0) {
            badge = {
                class: 'receiving-status-not-started',
                text: 'Not Started',
                icon: '⏸️'
            };
        } else if (percentage < 100) {
            badge = {
                class: 'receiving-status-in-progress',
                text: `${percentage}% Received`,
                icon: '🔄'
            };
        } else {
            badge = {
                class: 'receiving-status-completed',
                text: 'Complete',
                icon: '✅'
            };
        }

        return `<span class="status-badge ${badge.class}" title="${receivedItems} of ${totalItems} items received">
            <span style="margin-right: 4px;">${badge.icon}</span>
            ${badge.text}
        </span>`;
    }

    /**
     * Generate workflow steps indicator
     */
    static getWorkflowSteps(currentStep) {
        const steps = [
            { key: 'draft', label: 'Draft' },
            { key: 'pending', label: 'Pending' },
            { key: 'approved', label: 'Approved' },
            { key: 'receiving', label: 'Receiving' },
            { key: 'completed', label: 'Completed' }
        ];

        const stepMap = {
            'Draft': 'draft',
            'Pending': 'pending',
            'Approved': 'approved',
            'Partially Received': 'receiving',
            'Fully Received': 'completed'
        };

        const currentStepKey = stepMap[currentStep] || 'draft';
        const currentIndex = steps.findIndex(s => s.key === currentStepKey);

        return `<div class="workflow-steps">
            ${steps.map((step, index) => {
                let className = 'workflow-step';
                if (index < currentIndex) className += ' completed';
                if (index === currentIndex) className += ' active';
                
                return `<span class="${className}">
                    <div class="progress-dot ${index <= currentIndex ? (index < currentIndex ? 'completed' : 'active') : ''}"></div>
                    ${step.label}
                </span>`;
            }).join('')}
        </div>`;
    }

    /**
     * Generate currency display with proper formatting
     */
    static formatCurrency(amount, highlight = false, large = false) {
        const formatted = parseFloat(amount).toLocaleString('en-PH', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

        let className = 'currency-amount';
        if (large) className += ' currency-large';
        if (highlight) className += ' currency-highlight';

        return `<span class="${className}">₱${formatted}</span>`;
    }

    /**
     * Generate quantity display with color coding
     */
    static formatQuantity(quantity, change = null) {
        const num = parseFloat(quantity) || 0;
        let className = 'quantity-display';
        
        if (change !== null) {
            if (change > 0) className += ' quantity-positive';
            else if (change < 0) className += ' quantity-negative';
            else className += ' quantity-neutral';
        }

        const formatted = num.toLocaleString('en-PH');
        return `<span class="${className}">${formatted}</span>`;
    }

    /**
     * Generate demo mode indicator
     */
    static getDemoIndicator(message) {
        return `<div class="demo-indicator">
            <strong>🔒 STANDALONE MODE:</strong> ${message}
        </div>`;
    }

    /**
     * Generate stock transfer status badge
     */
    static getStockTransferStatusBadge(status) {
        const badges = {
            'Draft': {
                class: 'transfer-status-draft',
                text: 'Draft',
                icon: '📝'
            },
            'Pending Approval': {
                class: 'transfer-status-pending',
                text: 'Pending',
                icon: '⏳'
            },
            'Approved': {
                class: 'transfer-status-approved',
                text: 'Approved',
                icon: '✅'
            },
            'Rejected': {
                class: 'transfer-status-rejected',
                text: 'Rejected',
                icon: '❌'
            },
            'Cancelled': {
                class: 'transfer-status-cancelled',
                text: 'Cancelled',
                icon: '🚫'
            },
            'In Transit': {
                class: 'transfer-status-transit',
                text: 'In Transit',
                icon: '🚚'
            },
            'Completed': {
                class: 'transfer-status-completed',
                text: 'Completed',
                icon: '✅'
            }
        };

        const badge = badges[status] || badges['Draft'];
        return `<span class="status-badge ${badge.class}" title="${status}">
            <span style="margin-right: 4px;">${badge.icon}</span>
            ${badge.text}
        </span>`;
    }

    /**
     * Generate transfer direction indicator
     */
    static getTransferDirectionBadge(sourceLocation, destinationLocation) {
        return `<div class="transfer-direction">
            <span class="location-badge source">${sourceLocation}</span>
            <span class="direction-arrow">→</span>
            <span class="location-badge destination">${destinationLocation}</span>
        </div>`;
    }

    /**
     * Generate priority badge
     */
    static getPriorityBadge(priority = 'Normal') {
        const badges = {
            'Low': {
                class: 'priority-low',
                text: 'Low',
                icon: '🔵'
            },
            'Normal': {
                class: 'priority-normal',
                text: 'Normal',
                icon: '🟢'
            },
            'High': {
                class: 'priority-high',
                text: 'High',
                icon: '🟡'
            },
            'Urgent': {
                class: 'priority-urgent',
                text: 'Urgent',
                icon: '🔴'
            }
        };

        const badge = badges[priority] || badges['Normal'];
        return `<span class="priority-badge ${badge.class}" title="Priority: ${priority}">
            <span style="margin-right: 4px;">${badge.icon}</span>
            ${badge.text}
        </span>`;
    }

    /**
     * Generate action button with consistent styling
     */
    static getActionButton(text, onClick, type = 'primary', icon = '') {
        const className = `action-btn-${type}`;
        const iconHtml = icon ? `<span style="margin-right: 6px;">${icon}</span>` : '';
        
        return `<button class="${className}" onclick="${onClick}">
            ${iconHtml}${text}
        </button>`;
    }
}

// Make available globally for use in modules
window.BadgeHelper = BadgeHelper;