import { store } from '../store.js';

export class Modal {
    constructor() {
        this.overlay = null;
        this.modalContent = null;
        this.isOpen = false;
        this.callbacks = { onConfirm: null, onCancel: null, onOpen: null };
        this.createModalStructure();
    }

    createModalStructure() {
        this.overlay = document.createElement('div');
        this.overlay.id = 'app-modal-overlay';
        this.overlay.style.cssText = `
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 999;
            opacity: 0;
            transition: opacity 0.3s ease;
        `;

        this.modalContent = document.createElement('div');
        this.modalContent.id = 'app-modal-box';
        this.modalContent.style.cssText = `
            background: var(--bg-white);
            border-radius: 18px;
            padding: 26px 28px;
            max-width: 540px;
            width: 94%;
            box-shadow: 0 25px 50px rgba(0,0,0,0.18), 0 8px 16px rgba(0,0,0,0.10);
            border: 1px solid var(--border-color);
            transform: scale(0.92) translateY(8px);
            transition: transform 0.28s cubic-bezier(0.34,1.56,0.64,1), opacity 0.28s ease;
            max-height: 90vh;
            overflow-y: auto;
            color: var(--text-primary);
            position: relative;
        `;

        this.overlay.appendChild(this.modalContent);
        document.body.appendChild(this.overlay);

        this.overlay.addEventListener('click', (e) => {
            if (e.target === this.overlay) this.close();
        });

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isOpen) this.close();
        });
    }

    open(title, bodyHTML, actions = {}) {
        this.isOpen = true;
        this.callbacks = {
            onConfirm: actions.onConfirm || null,
            onCancel: actions.onCancel || null,
            onOpen: actions.onOpen || null
        };

        const confirmText = actions.confirmText || 'Confirm';
        const cancelText = actions.cancelText || 'Cancel';
        const showFooter = actions.hideFooter !== true;

        // Support custom width (e.g. receiving form needs more space)
        if (actions.width) {
            this.modalContent.style.maxWidth = typeof actions.width === 'number'
                ? actions.width + 'px'
                : String(actions.width);
        } else {
            this.modalContent.style.maxWidth = '540px';
        }

        this.modalContent.innerHTML = `
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:14px;">
                <h2 style="font-size:1.1rem; margin:0; font-weight:700; color:var(--text-primary);">${title}</h2>
                <button id="modal-close-icon" style="background:var(--bg-gray); border:none; width:30px; height:30px; border-radius:50%; font-size:1.2rem; cursor:pointer; color:var(--text-secondary); display:flex; align-items:center; justify-content:center; line-height:1; transition:background 0.15s;" onmouseover="this.style.background='var(--border-color)'" onmouseout="this.style.background='var(--bg-gray)'">&times;</button>
            </div>
            <div id="modal-body" style="overflow-y:auto; max-height:calc(90vh - 140px); padding-right:4px;">${bodyHTML}</div>
            ${showFooter ? `
            <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:16px; border-top:1px solid var(--border-color); padding-top:14px; position:sticky; bottom:0; background:var(--bg-white);">
                <button id="modal-cancel-btn" style="padding:9px 18px; background:var(--bg-white); border:1.5px solid var(--border-color); border-radius:8px; color:var(--text-secondary); cursor:pointer; font-weight:600; font-size:0.875rem; font-family:inherit; transition:all 0.15s;" onmouseover="this.style.background='var(--bg-gray)'" onmouseout="this.style.background='var(--bg-white)'">${cancelText}</button>
                <button id="modal-confirm-btn" style="padding:9px 18px; background:var(--primary-red); color:#fff; border:none; border-radius:8px; cursor:pointer; font-weight:600; font-size:0.875rem; font-family:inherit; transition:all 0.15s;" onmouseover="this.style.background='var(--primary-red-dark)'" onmouseout="this.style.background='var(--primary-red)'">${confirmText}</button>
            </div>` : ''}
        `;

        document.getElementById('modal-close-icon')?.addEventListener('click', () => this.close());
        document.getElementById('modal-cancel-btn')?.addEventListener('click', () => {
            if (this.callbacks.onCancel) this.callbacks.onCancel();
            this.close();
        });

        const confirmBtn = document.getElementById('modal-confirm-btn');
        if (confirmBtn) {
            confirmBtn.addEventListener('click', async () => {
                if (!this.callbacks.onConfirm) return;
                if (confirmBtn.dataset.busy === '1') return;
                confirmBtn.dataset.busy = '1';
                const prevText = confirmBtn.textContent;
                confirmBtn.disabled = true;
                confirmBtn.style.opacity = '0.7';
                try {
                    const result = await this.callbacks.onConfirm();
                    // Explicit false = keep open (validation failed)
                    // Explicit true or undefined after success: caller may close
                    if (result === false) {
                        confirmBtn.disabled = false;
                        confirmBtn.style.opacity = '1';
                        confirmBtn.dataset.busy = '0';
                        confirmBtn.textContent = prevText;
                    }
                    // if true, leave busy — page usually refreshes or closes modal
                } catch (err) {
                    confirmBtn.disabled = false;
                    confirmBtn.style.opacity = '1';
                    confirmBtn.dataset.busy = '0';
                    confirmBtn.textContent = prevText;
                    throw err;
                }
            });
        }

        // Animate Open
        this.overlay.style.display = 'flex';
        requestAnimationFrame(() => {
            this.overlay.style.opacity = '1';
            this.modalContent.style.transform = 'scale(1) translateY(0)';
            
            // Execute onOpen callback immediately after rendering
            if (this.callbacks.onOpen) {
                this.callbacks.onOpen();
            }
        });
    }

    close() {
        if (!this.isOpen) return;
        this.isOpen = false;
        this.overlay.style.opacity = '0';
        this.modalContent.style.transform = 'scale(0.92) translateY(8px)';
        setTimeout(() => {
            this.overlay.style.display = 'none';
            this.modalContent.innerHTML = '';
        }, 280);
    }
}

export const modal = new Modal();