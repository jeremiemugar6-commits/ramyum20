export class DataTable {
    constructor(containerId, columns, data, options = {}) {
        this.container = document.getElementById(containerId);
        if (!this.container) throw new Error(`Container #${containerId} not found.`);
        this.columns = columns;
        this.data = data;
        this.options = {
            selectable: options.selectable || false,
            actions: options.actions || false,
            onView: options.onView || null,
            onEdit: options.onEdit || null,
            onDelete: options.onDelete || null,
            ...options
        };
        this.render();
    }

    updateData(newData) {
        this.data = newData;
        this.render();
    }

    render() {
        let html = `<div style="overflow-x:auto; border-radius:10px; border:1px solid var(--border-color);">
            <table style="width:100%; border-collapse:collapse; font-size:0.875rem; color:var(--text-primary);">`;

        // --- THEAD ---
        html += `<thead style="background:var(--bg-gray); border-bottom:2px solid var(--border-color);"><tr>`;

        if (this.options.selectable) {
            html += `<th style="padding:11px 16px; text-align:left; width:40px;">
                <input type="checkbox" id="select-all" style="width:15px; height:15px; accent-color:var(--primary-red); cursor:pointer;">
            </th>`;
        }

        this.columns.forEach(col => {
            html += `<th style="padding:11px 16px; text-align:left; font-size:0.75rem; font-weight:700; color:var(--text-secondary); text-transform:uppercase; letter-spacing:0.05em; white-space:nowrap;">${col.label}</th>`;
        });

        if (this.options.actions) {
            html += `<th style="padding:11px 16px; text-align:right; font-size:0.75rem; font-weight:700; color:var(--text-secondary); text-transform:uppercase; letter-spacing:0.05em;">Actions</th>`;
        }

        html += `</tr></thead>`;

        // --- TBODY ---
        html += `<tbody style="background:var(--bg-white);">`;

        if (this.data.length === 0) {
            const colspan = this.columns.length + (this.options.actions ? 1 : 0) + (this.options.selectable ? 1 : 0);
            html += `<tr>
                <td colspan="${colspan}" style="text-align:center; padding:48px 16px; color:var(--text-muted);">
                    <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="display:block; margin:0 auto 10px; opacity:0.35;"><path d="M3 7h18M3 12h18M3 17h18"/></svg>
                    <span style="font-size:0.95rem; font-weight:600; color:var(--text-primary);">No records found</span>
                    <div style="font-size:0.8rem; color:var(--text-muted); margin-top:6px;">Try adjusting filters or add a new entry.</div>
                </td>
            </tr>`;
        } else {
            this.data.forEach((row, i) => {
                const rowBg = i % 2 === 1 ? 'background:var(--bg-gray);' : '';
                html += `<tr style="border-bottom:1px solid var(--border-color); transition:background 0.15s; ${rowBg}" 
                    onmouseover="this.style.background='var(--primary-red-light)'" 
                    onmouseout="this.style.background='${i % 2 === 1 ? 'var(--bg-gray)' : 'var(--bg-white)'}'">`;

                if (this.options.selectable) {
                    html += `<td style="padding:11px 16px;">
                        <input type="checkbox" class="row-select" data-id="${row.id}" style="width:15px; height:15px; accent-color:var(--primary-red); cursor:pointer;">
                    </td>`;
                }

                this.columns.forEach(col => {
                    const value = row[col.key] !== undefined ? row[col.key] : '—';
                    html += `<td style="padding:11px 16px; color:var(--text-primary); vertical-align:middle;">${value}</td>`;
                });

                if (this.options.actions) {
                    html += `<td style="padding:11px 16px; text-align:right;">
                        <div style="display:flex; gap:6px; justify-content:flex-end; align-items:center;">`;

                    // Add approve button for specific conditions (if onApprove callback exists)
                    if (this.options.onApprove && (row.rawStatus === 'Pending' || row.status === 'Pending')) {
                        html += `<button class="table-btn approve-btn" data-id="${row.id}" 
                            style="background:#10B981; color:#fff; border:none; padding:5px 13px; border-radius:6px; cursor:pointer; font-size:0.8rem; font-weight:600; transition:background 0.15s; font-family:inherit;"
                            onmouseover="this.style.background='#059669'" onmouseout="this.style.background='#10B981'">Approve</button>`;
                    }

                    // View / Details button (for viewing transfer/related details)
                    if (this.options.onView) {
                        const viewLabel = this.options.viewLabel || 'Details';
                        html += `<button type="button" class="table-btn view-btn" data-id="${row.id}" 
                            style="background:#0D9488; color:#fff; border:none; padding:6px 14px; border-radius:8px; cursor:pointer; font-size:0.8rem; font-weight:600; transition:all 0.15s; font-family:inherit; box-shadow:0 1px 2px rgba(13,148,136,0.25);"
                            onmouseover="this.style.background='#0F766E'" onmouseout="this.style.background='#0D9488'" title="${viewLabel}">${viewLabel}</button>`;
                    }

                    if (this.options.onEdit) {
                        const editLabel = this.options.editLabel || 'Edit';
                        html += `<button type="button" class="table-btn edit-btn" data-id="${row.id}" 
                            style="background:#2563EB; color:#fff; border:none; padding:6px 14px; border-radius:8px; cursor:pointer; font-size:0.8rem; font-weight:600; transition:all 0.15s; font-family:inherit; box-shadow:0 1px 2px rgba(37,99,235,0.25);"
                            onmouseover="this.style.background='#1D4ED8'" onmouseout="this.style.background='#2563EB'" title="${editLabel}">${editLabel}</button>`;
                    }

                    if (this.options.onDelete) {
                        const deleteLabel = this.options.deleteLabel || 'Delete';
                        // secondary = neutral outline (e.g. Edit); danger = red (true delete)
                        const variant = this.options.deleteVariant || (deleteLabel.toLowerCase() === 'delete' ? 'danger' : 'secondary');
                        if (variant === 'secondary') {
                            html += `<button type="button" class="table-btn delete-btn" data-id="${row.id}" 
                                style="background:#fff; color:#374151; border:1.5px solid #D1D5DB; padding:6px 14px; border-radius:8px; cursor:pointer; font-size:0.8rem; font-weight:600; transition:all 0.15s; font-family:inherit;"
                                onmouseover="this.style.background='#F3F4F6';this.style.borderColor='#9CA3AF'" onmouseout="this.style.background='#fff';this.style.borderColor='#D1D5DB'" title="${deleteLabel}">${deleteLabel}</button>`;
                        } else {
                            html += `<button type="button" class="table-btn delete-btn" data-id="${row.id}" 
                                style="background:#EF4444; color:#fff; border:none; padding:6px 14px; border-radius:8px; cursor:pointer; font-size:0.8rem; font-weight:600; transition:all 0.15s; font-family:inherit;"
                                onmouseover="this.style.background='#DC2626'" onmouseout="this.style.background='#EF4444'" title="${deleteLabel}">${deleteLabel}</button>`;
                        }
                    }

                    html += `</div></td>`;
                }

                html += `</tr>`;
            });
        }

        html += `</tbody></table></div>`;
        this.container.innerHTML = html;

        // --- EVENT LISTENERS ---
        const resolveRow = (e) => {
            const btn = e.target.closest('[data-id]');
            if (!btn) return null;
            const id = btn.dataset.id;
            return this.data.find(r => String(r.id) === String(id)) || null;
        };

        if (this.options.onApprove) {
            this.container.querySelectorAll('.approve-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    const rowData = resolveRow(e);
                    if (rowData) this.options.onApprove(rowData);
                });
            });
        }

        if (this.options.onView) {
            this.container.querySelectorAll('.view-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    const rowData = resolveRow(e);
                    if (rowData) this.options.onView(rowData);
                });
            });
        }

        if (this.options.onEdit) {
            this.container.querySelectorAll('.edit-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    const rowData = resolveRow(e);
                    if (rowData) this.options.onEdit(rowData);
                });
            });
        }

        if (this.options.onDelete) {
            this.container.querySelectorAll('.delete-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    const rowData = resolveRow(e);
                    if (rowData) this.options.onDelete(rowData);
                });
            });
        }

        const selectAll = document.getElementById('select-all');
        if (selectAll) {
            selectAll.addEventListener('change', (e) => {
                this.container.querySelectorAll('.row-select').forEach(cb => cb.checked = e.target.checked);
            });
        }
    }
}
