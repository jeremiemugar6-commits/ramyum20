<?php
/**
 * Stock Transfer Database Setup Script - Fixed Version
 * Executes the SQL schema and demo data for stock transfer module
 */

require_once __DIR__ . '/config/database.php';

// HTML header for browser viewing
echo "<!DOCTYPE html><html><head><title>Database Setup</title><style>
    body { font-family: system-ui; margin: 40px; }
    .success { color: green; }
    .warning { color: orange; }
    .error { color: red; }
    .info { color: blue; }
    h1, h2, h3 { color: #333; }
    .btn { background: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin-right: 10px; }
    .btn.success { background: #10b981; }
</style></head><body>";

try {
    $db = getDB();
    
    // Ensure buffered queries for MySQL  
    $db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
    
    echo "<h1>🛠️ Stock Transfer Database Setup</h1>\n";
    
    // Step 1: Create locations table and data
    echo "<h2>Step 1: Setting up Locations</h2>\n";
    
    // Create locations table
    $createLocationsTable = "
    CREATE TABLE IF NOT EXISTS locations (
        id         VARCHAR(40) PRIMARY KEY,
        data       JSON NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB";
    
    try {
        $db->exec($createLocationsTable);
        echo "<p class='success'>✅ Locations table created/verified</p>\n";
    } catch (Exception $e) {
        echo "<p class='error'>❌ Failed to create locations table: " . htmlspecialchars($e->getMessage()) . "</p>\n";
    }
    
    // Insert location data directly
    $locations = [
        ['loc1', 'Main Warehouse', 'WH', 'Warehouse', '123 Industrial Avenue, Manila', 'Juan dela Cruz', '+63 2 8555 0001', 'warehouse@ramyum.com', 'Active', 2000, 'Primary storage and distribution center'],
        ['loc2', 'Branch 1 - Makati', 'MKT', 'Branch', '456 Ayala Avenue, Makati City', 'Maria Santos', '+63 2 8555 0002', 'makati@ramyum.com', 'Active', 500, 'Makati retail branch with premium location'],
        ['loc3', 'Branch 2 - Quezon City', 'QC', 'Branch', '789 Commonwealth Avenue, Quezon City', 'Ana Rodriguez', '+63 2 8555 0003', 'qc@ramyum.com', 'Active', 400, 'Quezon City retail branch with cold storage'],
        ['loc4', 'Storage Area - BGC', 'BGC', 'Storage', '321 Bonifacio Global City, Taguig', 'Roberto Kim', '+63 2 8555 0004', 'bgc@ramyum.com', 'Active', 1500, 'Secondary storage facility for overflow inventory']
    ];
    
    $insertLocationSQL = "INSERT INTO locations (id, data) VALUES (?, ?) ON DUPLICATE KEY UPDATE data = VALUES(data)";
    $stmt = $db->prepare($insertLocationSQL);
    
    foreach ($locations as $loc) {
        $locationData = json_encode([
            'id' => $loc[0],
            'name' => $loc[1],
            'code' => $loc[2],
            'type' => $loc[3],
            'address' => $loc[4],
            'manager' => $loc[5],
            'phone' => $loc[6],
            'email' => $loc[7],
            'status' => $loc[8],
            'capacity' => $loc[9],
            'description' => $loc[10]
        ]);
        
        try {
            $stmt->execute([$loc[0], $locationData]);
            echo "<p class='success'>✅ Location: " . $loc[1] . "</p>\n";
        } catch (Exception $e) {
            echo "<p class='warning'>⚠ Location " . $loc[1] . " exists</p>\n";
        }
    }
    
    // Step 2: Create other required tables
    echo "<h2>Step 2: Creating Additional Tables</h2>\n";
    
    $tables = [
        'inventory_locations' => "
        CREATE TABLE IF NOT EXISTS inventory_locations (
            id         VARCHAR(40) PRIMARY KEY,
            data       JSON NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB",
        
        'stock_transfer_audit' => "
        CREATE TABLE IF NOT EXISTS stock_transfer_audit (
            id            VARCHAR(40) PRIMARY KEY,
            transfer_id   VARCHAR(100) NOT NULL,
            action        VARCHAR(50) NOT NULL,
            performed_by  VARCHAR(40) NOT NULL,
            performed_by_name VARCHAR(255) NOT NULL,
            details       TEXT,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_transfer_id (transfer_id),
            INDEX idx_action (action),
            INDEX idx_performed_by (performed_by),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB"
    ];
    
    foreach ($tables as $tableName => $sql) {
        try {
            $db->exec($sql);
            echo "<p class='success'>✅ Table: {$tableName}</p>\n";
        } catch (Exception $e) {
            echo "<p class='warning'>⚠ Table {$tableName} exists</p>\n";
        }
    }
    
    // Step 3: Create some sample inventory data
    echo "<h2>Step 3: Setting up Sample Inventory</h2>\n";
    
    $sampleInventory = [
        ['inv_p1_loc1', 'p1', 'loc1', 150, 0, 150],
        ['inv_p1_loc2', 'p1', 'loc2', 30, 0, 30],
        ['inv_p2_loc1', 'p2', 'loc1', 200, 0, 200],
        ['inv_p2_loc2', 'p2', 'loc2', 25, 0, 25],
        ['inv_p3_loc1', 'p3', 'loc1', 100, 0, 100],
        ['inv_p4_loc1', 'p4', 'loc1', 120, 0, 120]
    ];
    
    $insertInventorySQL = "INSERT INTO inventory_locations (id, data) VALUES (?, ?) ON DUPLICATE KEY UPDATE data = VALUES(data)";
    $invStmt = $db->prepare($insertInventorySQL);
    
    foreach ($sampleInventory as $inv) {
        $inventoryData = json_encode([
            'id' => $inv[0],
            'productId' => $inv[1],
            'locationId' => $inv[2],
            'quantity' => $inv[3],
            'reservedQuantity' => $inv[4],
            'availableQuantity' => $inv[5],
            'lastUpdated' => date('Y-m-d\TH:i:s.000\Z')
        ]);
        
        try {
            $invStmt->execute([$inv[0], $inventoryData]);
            echo "<p class='success'>✅ Inventory: Product {$inv[1]} at Location {$inv[2]} ({$inv[3]} units)</p>\n";
        } catch (Exception $e) {
            echo "<p class='warning'>⚠ Inventory exists: Product {$inv[1]} at Location {$inv[2]}</p>\n";
        }
    }
    
    // Step 4: Verification
    echo "<h2>Step 4: Verification</h2>\n";
    
    // Check locations
    $stmt = $db->query("SELECT COUNT(*) as count FROM locations");
    $locationCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    echo "<p class='success'>✅ Locations: " . $locationCount . " records</p>\n";
    
    // Check inventory locations
    try {
        $stmt = $db->query("SELECT COUNT(*) as count FROM inventory_locations");
        $inventoryCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "<p class='success'>✅ Inventory locations: " . $inventoryCount . " records</p>\n";
    } catch (Exception $e) {
        echo "<p class='warning'>⚠ Inventory locations: " . htmlspecialchars($e->getMessage()) . "</p>\n";
    }
    
    // Check stock transfers table
    try {
        $stmt = $db->query("SELECT COUNT(*) as count FROM stock_transfers");
        $transferCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "<p class='success'>✅ Stock transfers: " . $transferCount . " records</p>\n";
    } catch (Exception $e) {
        echo "<p class='info'>ℹ Stock transfers table doesn't exist yet (that's OK)</p>\n";
    }
    
    // Test API call
    echo "<h2>Step 5: API Test</h2>\n";
    echo "<p>Testing locations API...</p>\n";
    
    try {
        // Simulate the API call internally
        $stmt = $db->query("SELECT data FROM locations WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) = 'Active' ORDER BY JSON_UNQUOTE(JSON_EXTRACT(data, '$.name'))");
        $locations = array_map(function($row) {
            return json_decode($row['data'], true);
        }, $stmt->fetchAll());
        
        if (count($locations) > 0) {
            echo "<p class='success'>✅ API Test: Found " . count($locations) . " active locations</p>\n";
            foreach ($locations as $loc) {
                echo "<p class='info'>  📍 " . $loc['name'] . " (" . $loc['type'] . ")</p>\n";
            }
        } else {
            echo "<p class='error'>❌ API Test: No active locations found</p>\n";
        }
        
    } catch (Exception $e) {
        echo "<p class='error'>❌ API Test Failed: " . htmlspecialchars($e->getMessage()) . "</p>\n";
    }
    
    echo "<h2>🎉 Setup Complete!</h2>\n";
    echo "<p>The Stock Transfer module database has been successfully set up.</p>\n";
    echo "<div style='margin: 20px 0;'>";
    echo "<a href='dashboard.php' class='btn'>📊 Go to Dashboard</a>";
    echo "<a href='test-locations-data.php' class='btn success'>🧪 Test Locations</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<h3 class='error'>❌ Setup Failed</h3>\n";
    echo "<p class='error'>Error: " . htmlspecialchars($e->getMessage()) . "</p>\n";
    echo "<p>Please check your database connection and try again.</p>\n";
}

echo "</body></html>";
?>