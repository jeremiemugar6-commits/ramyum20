# POR "Pending although Passed" - fix notes

## Apply (2 steps)
1. **Back up the database**, then open (logged in as admin) `/fix-por-inspection-status.php`
   -> preview -> `/fix-por-inspection-status.php?run=1`.
   (Or run `database/fix-por-inspection-status.sql` in phpMyAdmin.) Delete the .php runner afterwards.
2. Upload the changed files and hard-refresh the browser (Ctrl+F5).

## Root cause
`proof_of_receiving.inspection_status` was ENUM('Pending','In Progress','Completed','Failed') and
`proof_of_receiving_items.inspection_result` was ENUM('Pass','Fail','Conditional','Pending'), but the app
writes 'Passed' / 'Partial'. In non-strict MySQL an unlisted value is stored as '' and the UI showed ''
as "Pending".

## Files changed
- database/fix-por-inspection-status.sql (new), fix-por-inspection-status.php (new runner)
- database/u479471141_ramyum_db2.sql  (enums widened, 2 existing rows now Passed)
- includes/functions.php   canonical status helpers
- api/por.php              resolved status everywhere; stats/archive actions; complete keeps real result;
                           po_id param; supplier_name bug; audit-log columns
- api/workflow-processor.php  canonical values; duplicate POR/GR number bug; audit-log columns
- api/proof-of-receiving.php  complete sets real result/totals; remainingItems guard
- modules/por/index.js, modules/purchase-orders/purchase-orders.js, modules/receiving/receiving.js
- add-products.php         PHP 8 fatal (nested ternary)

## Tested (MariaDB, non-strict, your dump)
Reproduced the blank-status bug; migration is idempotent; receiving full/partial/rejected -> Passed/Partial/Failed;
sequential POR/GR numbers; manual create -> update -> complete -> archive; tab counts correct.
