import { DataService } from '../../assets/js/utils/data-service.js';
import { store } from '../../assets/js/store.js';
import { StockStatus } from '../../assets/js/utils/stock-status.js';

const dataService = new DataService();

// --- RENDER FUNCTION ---
export async function renderDashboard() {
    const container = document.getElementById('appContent');
    const user = store.getState().user;
    
    const now = new Date();
    const hour = now.getHours();
    let greeting = 'Good Evening';
    if (hour < 12) greeting = 'Good Morning';
    else if (hour < 18) greeting = 'Good Afternoon';
    
    const dateStr = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

    container.innerHTML = `
        <style>
            .dashboard-hero {
                background: linear-gradient(135deg, #FF7A00 0%, #E53935 100%);
                padding: 32px 28px;
                border-radius: 16px;
                margin-bottom: 28px;
                color: white;
                position: relative;
                overflow: hidden;
                box-shadow: 0 10px 30px rgba(255, 122, 0, 0.25);
            }
            .dashboard-hero::before {
                content: '';
                position: absolute;
                top: -50%;
                right: -10%;
                width: 300px;
                height: 300px;
                background: rgba(255, 255, 255, 0.1);
                border-radius: 50%;
                z-index: 0;
            }
            .dashboard-hero-content {
                position: relative;
                z-index: 1;
            }
            .dashboard-hero h1 {
                font-size: 2rem;
                font-weight: 700;
                margin-bottom: 8px;
                text-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .dashboard-hero p {
                font-size: 1rem;
                opacity: 0.95;
                margin-bottom: 4px;
            }
            .dashboard-hero-meta {
                display: flex;
                gap: 20px;
                margin-top: 16px;
                flex-wrap: wrap;
            }
            .hero-meta-item {
                display: flex;
                align-items: center;
                gap: 8px;
                background: rgba(255, 255, 255, 0.15);
                padding: 8px 16px;
                border-radius: 8px;
                backdrop-filter: blur(10px);
            }
            .hero-meta-item svg {
                width: 18px;
                height: 18px;
            }
            
            .kpi-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
                gap: 20px;
                margin-bottom: 28px;
            }
            
            .kpi-card {
                background: var(--bg-card);
                border-radius: 14px;
                padding: 24px;
                border: 1px solid var(--border-color);
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
                position: relative;
                overflow: hidden;
                transition: all 0.3s ease;
                cursor: pointer;
            }
            .kpi-card::before {
                content: '';
                position: absolute;
                inset: 0;
                background: var(--bg-card);
                z-index: -1;
            }
            .kpi-card:hover {
                transform: translateY(-4px);
                box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
                border-color: #FF7A00;
            }
            .kpi-card-icon {
                width: 56px;
                height: 56px;
                border-radius: 12px;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 16px;
            }
            .kpi-card-label {
                font-size: 0.85rem;
                font-weight: 600;
                color: var(--text-secondary);
                text-transform: uppercase;
                letter-spacing: 0.05em;
                margin-bottom: 8px;
            }
            .kpi-card-value {
                font-size: 2.5rem;
                font-weight: 700;
                color: var(--text-primary);
                line-height: 1;
                margin-bottom: 8px;
            }
            .kpi-card-change {
                font-size: 0.875rem;
                font-weight: 600;
                display: flex;
                align-items: center;
                gap: 4px;
            }
            .kpi-card-change.positive { color: #10B981; }
            .kpi-card-change.negative { color: #EF4444; }
            
            .quick-actions-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
                gap: 16px;
                margin-bottom: 28px;
            }
            .quick-action-btn {
                background: var(--bg-card);
                border: 2px solid var(--border-color);
                border-radius: 12px;
                padding: 20px 16px;
                text-align: center;
                cursor: pointer;
                transition: all 0.3s ease;
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 12px;
                color: var(--text-primary);
                text-decoration: none;
            }
            .quick-action-btn::before {
                content: '';
                position: absolute;
                inset: 0;
                background: var(--bg-card);
                border-radius: inherit;
                z-index: -1;
            }
            .quick-action-btn:hover {
                transform: translateY(-2px);
                border-color: #FF7A00;
                box-shadow: 0 4px 12px rgba(255, 122, 0, 0.15);
            }
            .quick-action-icon {
                width: 48px;
                height: 48px;
                background: linear-gradient(135deg, #FF7A00, #E53935);
                border-radius: 10px;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .quick-action-icon svg {
                width: 24px;
                height: 24px;
                color: white;
            }
            .quick-action-label {
                font-size: 0.875rem;
                font-weight: 600;
            }
            
            .chart-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
                gap: 20px;
                margin-bottom: 28px;
            }
            
            .inventory-table {
                width: 100%;
                border-collapse: collapse;
            }
            .inventory-table th {
                background: var(--bg-gray);
                padding: 14px 16px;
                text-align: left;
                font-size: 0.8rem;
                font-weight: 700;
                color: var(--text-secondary);
                text-transform: uppercase;
                letter-spacing: 0.05em;
            }
            .inventory-table td {
                padding: 14px 16px;
                border-bottom: 1px solid var(--border-color);
            }
            .inventory-table tbody tr:hover {
                background: var(--bg-gray);
            }
            
            .timeline-item {
                display: flex;
                gap: 16px;
                margin-bottom: 20px;
                position: relative;
            }
            .timeline-item::before {
                content: '';
                position: absolute;
                left: 19px;
                top: 40px;
                bottom: -20px;
                width: 2px;
                background: var(--border-color);
            }
            .timeline-item:last-child::before {
                display: none;
            }
            .timeline-icon {
                width: 40px;
                height: 40px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
                z-index: 1;
            }
            .timeline-content {
                flex: 1;
                padding-top: 4px;
            }
            .timeline-title {
                font-weight: 600;
                color: var(--text-primary);
                margin-bottom: 4px;
            }
            .timeline-meta {
                font-size: 0.85rem;
                color: var(--text-muted);
            }
            
            .notification-item {
                display: flex;
                align-items: flex-start;
                gap: 12px;
                padding: 14px;
                background: var(--bg-gray);
                border-radius: 10px;
                margin-bottom: 12px;
                border-left: 3px solid #FF7A00;
            }
            .notification-icon {
                width: 36px;
                height: 36px;
                border-radius: 8px;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
            }
            .notification-content {
                flex: 1;
            }
            .notification-title {
                font-weight: 600;
                color: var(--text-primary);
                font-size: 0.9rem;
                margin-bottom: 2px;
            }
            .notification-desc {
                font-size: 0.85rem;
                color: var(--text-secondary);
            }
            
            .category-card {
                background: var(--bg-card);
                border: 1px solid var(--border-color);
                border-radius: 12px;
                padding: 20px;
                text-align: center;
                transition: all 0.3s ease;
                cursor: pointer;
            }
            .category-card::before {
                content: '';
                position: absolute;
                inset: 0;
                background: var(--bg-card);
                border-radius: inherit;
                z-index: -1;
            }
            .category-card:hover {
                transform: translateY(-2px);
                box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
                border-color: #FF7A00;
            }
            .category-icon {
                width: 60px;
                height: 60px;
                margin: 0 auto 12px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 28px;
            }
            .category-name {
                font-weight: 600;
                color: var(--text-primary);
                margin-bottom: 6px;
            }
            .category-count {
                font-size: 0.875rem;
                color: var(--text-secondary);
            }
            
            .progress-bar {
                width: 100%;
                height: 8px;
                background: var(--bg-gray);
                border-radius: 999px;
                overflow: hidden;
                margin-top: 8px;
            }
            .progress-fill {
                height: 100%;
                background: linear-gradient(90deg, #FF7A00, #E53935);
                border-radius: 999px;
                transition: width 0.6s ease;
            }
            
            @media (max-width: 768px) {
                .kpi-grid {
                    grid-template-columns: repeat(2, 1fr);
                }
                .chart-grid {
                    grid-template-columns: 1fr;
                }
                .quick-actions-grid {
                    grid-template-columns: repeat(2, 1fr);
                }
            }
        </style>
        
        <!-- Hero Section -->
        <div class="dashboard-hero">
            <div class="dashboard-hero-content">
                <h1>${greeting}, ${user?.name || 'Admin'}!</h1>
                <p>Welcome to RAM-YUM Product & Inventory Operations System</p>
                <div class="dashboard-hero-meta">
                    <div class="hero-meta-item">
                        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                        <span>${dateStr}</span>
                    </div>
                    <div class="hero-meta-item">
                        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        <span>Main Warehouse</span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- KPI Cards -->
        <div class="kpi-grid">
            <div class="kpi-card">
                <div class="kpi-card-icon" style="background: linear-gradient(135deg, #3B82F6 0%, #1D4ED8 100%);">
                    <svg width="28" height="28" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                </div>
                <div class="kpi-card-label">Total Products</div>
                <div class="kpi-card-value" id="statTotalProducts">—</div>
                <div class="kpi-card-change positive">
                    <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="18 15 12 9 6 15"/></svg>
                    <span id="changeProducts">—</span>
                </div>
            </div>
            
            <div class="kpi-card">
                <div class="kpi-card-icon" style="background: linear-gradient(135deg, #FF7A00 0%, #F59E0B 100%);">
                    <svg width="28" height="28" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M12 9v4"/><path d="M12 17h.01"/><circle cx="12" cy="12" r="10"/></svg>
                </div>
                <div class="kpi-card-label">Low Stock Items</div>
                <div class="kpi-card-value" style="color:#FF7A00;" id="statLowStock">—</div>
                <div class="kpi-card-change" id="changeLowStock">
                    <span>Needs attention</span>
                </div>
            </div>
            
            <div class="kpi-card">
                <div class="kpi-card-icon" style="background: linear-gradient(135deg, #E53935 0%, #DC2626 100%);">
                    <svg width="28" height="28" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/></svg>
                </div>
                <div class="kpi-card-label">Out of Stock</div>
                <div class="kpi-card-value" style="color:#E53935;" id="statOutOfStock">—</div>
                <div class="kpi-card-change" id="changeOutStock">
                    <span>Critical</span>
                </div>
            </div>
            
            <div class="kpi-card">
                <div class="kpi-card-icon" style="background: linear-gradient(135deg, #10B981 0%, #059669 100%);">
                    <svg width="28" height="28" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
                </div>
                <div class="kpi-card-label">Inventory Value</div>
                <div class="kpi-card-value" id="statInventoryValue">—</div>
                <div class="kpi-card-change positive">
                    <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="18 15 12 9 6 15"/></svg>
                    <span>+2.5% this month</span>
                </div>
            </div>
            
            <div class="kpi-card">
                <div class="kpi-card-icon" style="background: linear-gradient(135deg, #10B981 0%, #059669 100%);">
                    <svg width="28" height="28" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/><path d="M9 14l2 2 4-4"/></svg>
                </div>
                <div class="kpi-card-label">Pending POs</div>
                <div class="kpi-card-value" id="statPendingOrders">—</div>
                <div class="kpi-card-change">
                    <span id="changePendingOrders">—</span>
                </div>
            </div>
            
            <div class="kpi-card">
                <div class="kpi-card-icon" style="background: linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%);">
                    <svg width="28" height="28" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M5 13h14M5 13a2 2 0 01-2-2V5a2 2 0 012-2h14a2 2 0 012 2v6a2 2 0 01-2 2M5 13v4a2 2 0 002 2h10a2 2 0 002-2v-4"/><path d="M9 17h6"/></svg>
                </div>
                <div class="kpi-card-label">Today's Received</div>
                <div class="kpi-card-value" id="statReceivedToday">—</div>
                <div class="kpi-card-change">
                    <span>Units</span>
                </div>
            </div>
            
            <div class="kpi-card">
                <div class="kpi-card-icon" style="background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);">
                    <svg width="28" height="28" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M3 6h18M3 12h18M3 18h18"/><path d="M6 3v3M18 3v3M6 21v-3M18 21v-3"/></svg>
                </div>
                <div class="kpi-card-label">Stock Transfers</div>
                <div class="kpi-card-value" id="statStockTransfers">—</div>
                <div class="kpi-card-change">
                    <span id="changeStockTransfers">—</span>
                </div>
            </div>
            
            <div class="kpi-card">
                <div class="kpi-card-icon" style="background: linear-gradient(135deg, #EC4899 0%, #DB2777 100%);">
                    <svg width="28" height="28" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M7 7h10M7 12h10M7 17h10"/><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/></svg>
                </div>
                <div class="kpi-card-label">Product Categories</div>
                <div class="kpi-card-value" id="statCategories">—</div>
                <div class="kpi-card-change">
                    <span>Active</span>
                </div>
            </div>
        </div>
        
        <!-- Charts Section -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(450px, 1fr)); gap: 20px; margin-bottom: 28px;">
            <!-- Sales Trend Chart -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Inventory Value Trend</h3>
                    <span style="font-size: 0.85rem; color: var(--text-muted); font-weight: 500;">Last 7 days</span>
                </div>
                <div style="padding: 20px;">
                    <canvas id="inventoryTrendChart" style="max-height: 300px;"></canvas>
                </div>
            </div>
            
            <!-- Stock Status Chart -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Stock Status Distribution</h3>
                    <span style="font-size: 0.85rem; color: var(--text-muted); font-weight: 500;">Current overview</span>
                </div>
                <div style="padding: 20px;">
                    <canvas id="stockStatusChart" style="max-height: 300px;"></canvas>
                </div>
            </div>
        </div>
        
        <!-- More Charts -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(450px, 1fr)); gap: 20px; margin-bottom: 28px;">
            <!-- Category Distribution Chart -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Products by Category</h3>
                    <span style="font-size: 0.85rem; color: var(--text-muted); font-weight: 500;">Distribution</span>
                </div>
                <div style="padding: 20px;">
                    <canvas id="categoryChart" style="max-height: 300px;"></canvas>
                </div>
            </div>
            
            <!-- Purchase Order Status Chart -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Purchase Orders Status</h3>
                    <span style="font-size: 0.85rem; color: var(--text-muted); font-weight: 500;">Current status</span>
                </div>
                <div style="padding: 20px;">
                    <canvas id="purchaseOrderChart" style="max-height: 300px;"></canvas>
                </div>
            </div>
        </div>
        
        <!-- Top Products Chart -->
        <div class="card" style="margin-bottom: 28px;">
            <div class="card-header">
                <h3 class="card-title">Top 10 Products by Stock Value</h3>
                <span style="font-size: 0.85rem; color: var(--text-muted); font-weight: 500;">Total value in inventory</span>
            </div>
            <div style="padding: 20px;">
                <canvas id="topProductsChart" style="max-height: 400px;"></canvas>
            </div>
        </div>
        
        <!-- Today's Operations Chart -->
        <div class="card" style="margin-bottom: 28px;">
            <div class="card-header">
                <h3 class="card-title">Today's Operations Snapshot</h3>
                <span style="font-size: 0.85rem; color: var(--text-muted); font-weight: 500;">Receiving, transfers & pending approvals</span>
            </div>
            <div style="padding: 20px;">
                <canvas id="operationsSnapshotChart" style="max-height: 280px;"></canvas>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="card" style="margin-bottom: 28px;">
            <div class="card-header">
                <h3 class="card-title">Quick Actions</h3>
            </div>
            <div class="quick-actions-grid">
                <div class="quick-action-btn" onclick="document.querySelector('[data-page=products]').click()">
                    <div class="quick-action-icon">
                        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 4v16m8-8H4"/></svg>
                    </div>
                    <span class="quick-action-label">Add Product</span>
                </div>
                <div class="quick-action-btn" onclick="document.querySelector('[data-page=purchase-orders]').click()">
                    <div class="quick-action-icon">
                        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                    </div>
                    <span class="quick-action-label">New Purchase Order</span>
                </div>
                <div class="quick-action-btn" onclick="document.querySelector('[data-page=receiving]').click()">
                    <div class="quick-action-icon">
                        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 13h14M5 13a2 2 0 01-2-2V5a2 2 0 012-2h14a2 2 0 012 2v6a2 2 0 01-2 2M5 13v4a2 2 0 002 2h10a2 2 0 002-2v-4"/></svg>
                    </div>
                    <span class="quick-action-label">Receive Products</span>
                </div>
                <div class="quick-action-btn" onclick="document.querySelector('[data-page=stock-transfer]').click()">
                    <div class="quick-action-icon">
                        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M8 7h12M8 12h12M8 17h12M3 7h.01M3 12h.01M3 17h.01"/></svg>
                    </div>
                    <span class="quick-action-label">Transfer Stock</span>
                </div>
                <div class="quick-action-btn" onclick="document.querySelector('[data-page=suppliers]').click()">
                    <div class="quick-action-icon">
                        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>
                    </div>
                    <span class="quick-action-label">Manage Suppliers</span>
                </div>
                <div class="quick-action-btn" onclick="document.querySelector('[data-page=reports]').click()">
                    <div class="quick-action-icon">
                        <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
                    </div>
                    <span class="quick-action-label">View Reports</span>
                </div>
            </div>
        </div>
        
        <!-- Operations Today: Pending POs / Today's Receiving / Stock Transfers -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 20px; margin-bottom: 28px;">
            <!-- Pending Purchase Orders -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Pending Purchase Orders</h3>
                    <button class="btn-secondary" style="padding: 6px 12px; font-size: 0.85rem;" onclick="document.querySelector('[data-page=purchase-orders]').click()">
                        View All
                    </button>
                </div>
                <div id="pendingPOsList" style="padding: 8px 0;">
                    <div style="text-align:center; color:var(--text-muted); padding:20px;">Loading...</div>
                </div>
            </div>

            <!-- Today's Receiving (Itemized) -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Today's Receiving</h3>
                    <button class="btn-secondary" style="padding: 6px 12px; font-size: 0.85rem;" onclick="document.querySelector('[data-page=receiving]').click()">
                        View All
                    </button>
                </div>
                <div id="todaysReceivingList" style="padding: 8px 0;">
                    <div style="text-align:center; color:var(--text-muted); padding:20px;">Loading...</div>
                </div>
            </div>

            <!-- Stock Transfers: Inbound / Outbound -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Stock Transfers Today</h3>
                    <button class="btn-secondary" style="padding: 6px 12px; font-size: 0.85rem;" onclick="document.querySelector('[data-page=stock-transfer]').click()">
                        View All
                    </button>
                </div>
                <div id="stockTransferDirectionList" style="padding: 8px 0;">
                    <div style="text-align:center; color:var(--text-muted); padding:20px;">Loading...</div>
                </div>
            </div>
        </div>

        <!-- Two Column Layout -->
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-bottom: 28px;">
            
            <!-- Inventory Overview Table -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Inventory Overview</h3>
                    <button class="btn-secondary" style="padding: 6px 12px; font-size: 0.85rem;" onclick="document.querySelector('[data-page=inventory]').click()">
                        View All
                    </button>
                </div>
                <div style="overflow-x: auto;">
                    <table class="inventory-table">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Category</th>
                                <th>Stock</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody id="inventoryTableBody">
                            <tr><td colspan="4" style="text-align:center; color:var(--text-muted);">Loading...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Notifications Panel -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Notifications</h3>
                    <span class="badge" style="background:#FF7A00; color:white; padding:4px 10px;" id="notificationCount">0</span>
                </div>
                <div id="notificationsPanel">
                    <div style="text-align:center; color:var(--text-muted); padding:20px;">Loading...</div>
                </div>
            </div>
        </div>
        
        <!-- Three Column Layout -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-bottom: 28px;">
            
            <!-- Recent Activities -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Recent Activities</h3>
                </div>
                <div id="recentActivities">
                    <div style="text-align:center; color:var(--text-muted); padding:20px;">Loading...</div>
                </div>
            </div>
            
            <!-- Warehouse Overview -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Warehouse Utilization</h3>
                </div>
                <div style="padding: 12px 0;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 12px;">
                        <span style="color: var(--text-secondary); font-size: 0.9rem; font-weight: 600;">Capacity Used</span>
                        <span style="color: var(--text-primary); font-weight: 700;" id="warehousePercent">—</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" id="warehouseProgress" style="width: 0%;"></div>
                    </div>
                    <div style="margin-top: 20px; display: grid; gap: 12px;">
                        <div style="display: flex; justify-content: space-between; padding: 10px; background: var(--bg-gray); border-radius: 8px;">
                            <span style="color: var(--text-secondary); font-size: 0.875rem;">Total Capacity</span>
                            <span style="color: var(--text-primary); font-weight: 600;" id="warehouseTotal">10,000 units</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 10px; background: var(--bg-gray); border-radius: 8px;">
                            <span style="color: var(--text-secondary); font-size: 0.875rem;">Occupied</span>
                            <span style="color: #FF7A00; font-weight: 700;" id="warehouseOccupied">—</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 10px; background: var(--bg-gray); border-radius: 8px;">
                            <span style="color: var(--text-secondary); font-size: 0.875rem;">Available</span>
                            <span style="color: #10B981; font-weight: 700;" id="warehouseAvailable">—</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Supplier Overview -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Supplier Overview</h3>
                </div>
                <div style="padding: 12px 0;">
                    <div style="display: grid; gap: 12px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px; background: var(--bg-gray); border-radius: 8px;">
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div style="width: 40px; height: 40px; border-radius: 8px; background: linear-gradient(135deg, #10B981, #059669); display: flex; align-items: center; justify-content: center;">
                                    <svg width="20" height="20" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg>
                                </div>
                                <span style="color: var(--text-secondary); font-size: 0.875rem; font-weight: 500;">Total Suppliers</span>
                            </div>
                            <span style="color: var(--text-primary); font-weight: 700; font-size: 1.25rem;" id="statTotalSuppliers">—</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px; background: var(--bg-gray); border-radius: 8px;">
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div style="width: 40px; height: 40px; border-radius: 8px; background: linear-gradient(135deg, #3B82F6, #1D4ED8); display: flex; align-items: center; justify-content: center;">
                                    <svg width="20" height="20" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
                                </div>
                                <span style="color: var(--text-secondary); font-size: 0.875rem; font-weight: 500;">Active Suppliers</span>
                            </div>
                            <span style="color: var(--text-primary); font-weight: 700; font-size: 1.25rem;" id="statActiveSuppliers">—</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; align-items: center; padding: 12px; background: var(--bg-gray); border-radius: 8px;">
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div style="width: 40px; height: 40px; border-radius: 8px; background: linear-gradient(135deg, #F59E0B, #D97706); display: flex; align-items: center; justify-content: center;">
                                    <svg width="20" height="20" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
                                </div>
                                <span style="color: var(--text-secondary); font-size: 0.875rem; font-weight: 500;">Pending Deliveries</span>
                            </div>
                            <span style="color: var(--text-primary); font-weight: 700; font-size: 1.25rem;" id="statPendingDeliveries">—</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Product Categories -->
        <div class="card" style="margin-bottom: 28px;">
            <div class="card-header">
                <h3 class="card-title">Product Categories</h3>
                <span style="font-size: 0.85rem; color: var(--text-muted); font-weight: 500;">Korean & Japanese Specialty Items</span>
            </div>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 16px;">
                <div class="category-card">
                    <div class="category-icon" style="background: linear-gradient(135deg, #FF7A00, #F59E0B);">🍜</div>
                    <div class="category-name">Instant Noodles</div>
                    <div class="category-count" id="catNoodles">— items</div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 4px;">Ramyun/Ramen</div>
                </div>
                <div class="category-card">
                    <div class="category-icon" style="background: linear-gradient(135deg, #E53935, #DC2626);">🌶️</div>
                    <div class="category-name">Sauces & Condiments</div>
                    <div class="category-count" id="catSauces">— items</div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 4px;">Gochujang, Mirin</div>
                </div>
                <div class="category-card">
                    <div class="category-icon" style="background: linear-gradient(135deg, #10B981, #059669);">🥟</div>
                    <div class="category-name">Frozen Foods</div>
                    <div class="category-count" id="catFrozen">— items</div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 4px;">Mandu, Gyoza</div>
                </div>
                <div class="category-card">
                    <div class="category-icon" style="background: linear-gradient(135deg, #3B82F6, #1D4ED8);">🍙</div>
                    <div class="category-name">Rice & Pantry</div>
                    <div class="category-count" id="catRice">— items</div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 4px;">Short-grain rice</div>
                </div>
                <div class="category-card">
                    <div class="category-icon" style="background: linear-gradient(135deg, #8B5CF6, #7C3AED);">🍫</div>
                    <div class="category-name">Snacks</div>
                    <div class="category-count" id="catSnacks">— items</div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 4px;">Pepero, KitKat</div>
                </div>
                <div class="category-card">
                    <div class="category-icon" style="background: linear-gradient(135deg, #EC4899, #DB2777);">🥤</div>
                    <div class="category-name">Beverages</div>
                    <div class="category-count" id="catBeverages">— items</div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 4px;">Banana Milk, Milkis</div>
                </div>
                <div class="category-card">
                    <div class="category-icon" style="background: linear-gradient(135deg, #F59E0B, #D97706);">🥬</div>
                    <div class="category-name">Kimchi & Pickled</div>
                    <div class="category-count" id="catKimchi">— items</div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 4px;">Ready-to-eat</div>
                </div>
                <div class="category-card">
                    <div class="category-icon" style="background: linear-gradient(135deg, #6366F1, #4F46E5);">🍱</div>
                    <div class="category-name">Specialty Items</div>
                    <div class="category-count" id="catSpecialty">— items</div>
                    <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 4px;">Curry, Miso</div>
                </div>
            </div>
        </div>
    `;

    await loadDashboardData();
}

async function loadDashboardData() {
    try {
        const [products, purchaseOrders, suppliers, receivings, stockTransferRecords] = await Promise.all([
            dataService.findAll('products'),
            dataService.findAll('purchase_orders'),
            dataService.findAll('suppliers'),
            dataService.findAll('receivings'),
            dataService.findAll('stock_transfers')
        ]);

        const isToday = (isoDate) => {
            if (!isoDate) return false;
            const d = new Date(isoDate);
            const now = new Date();
            return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate();
        };

        const todaysReceivings = receivings.filter(r => isToday(r.date));
        const todaysTransfers = stockTransferRecords.filter(t => isToday(t.date));
        const pendingPOs = purchaseOrders.filter(po => po.status === 'Draft' || po.status === 'Pending Approval');

        // Calculate stats with automatic stock status
        const totalProducts = products.length;
        
        const lowStockItems = products.filter(p => {
            const qty = typeof p.stock === 'object' ? Object.values(p.stock).reduce((a, b) => a + b, 0) : parseInt(p.stock || 0);
            const status = StockStatus.getStatus(qty);
            return status === 'Low Stock';
        });
        
        const outOfStockItems = products.filter(p => {
            const qty = typeof p.stock === 'object' ? Object.values(p.stock).reduce((a, b) => a + b, 0) : parseInt(p.stock || 0);
            const status = StockStatus.getStatus(qty);
            return status === 'Out of Stock';
        });
        
        const overstockItems = products.filter(p => {
            const qty = typeof p.stock === 'object' ? Object.values(p.stock).reduce((a, b) => a + b, 0) : parseInt(p.stock || 0);
            const status = StockStatus.getStatus(qty);
            return status === 'Overstock';
        });

        const totalInventoryValue = products.reduce((sum, p) => {
            const price = parseFloat(p.sellingPrice || p.price || 0);
            const qty = typeof p.stock === 'object' ? Object.values(p.stock).reduce((a, b) => a + b, 0) : parseInt(p.stock || 0);
            return sum + (price * qty);
        }, 0);
        
        const pendingOrders = purchaseOrders.filter(po => po.status === 'Draft' || po.status === 'Pending Approval').length;
        
        const stockTransfers = todaysTransfers.length;
        const receivedToday = todaysReceivings.reduce((sum, r) => sum + (parseInt(r.accepted || 0)), 0);
        
        // Update KPI values
        document.getElementById('statTotalProducts').textContent = totalProducts.toLocaleString();
        document.getElementById('statLowStock').textContent = lowStockItems.length;
        document.getElementById('statOutOfStock').textContent = outOfStockItems.length;
        document.getElementById('statInventoryValue').textContent = '₱' + totalInventoryValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        document.getElementById('statPendingOrders').textContent = pendingOrders;
        document.getElementById('statReceivedToday').textContent = receivedToday;
        document.getElementById('statStockTransfers').textContent = stockTransfers;
        
        // Categories count
        const categories = {};
        products.forEach(p => {
            const cat = p.category || 'Specialty Items';
            categories[cat] = (categories[cat] || 0) + 1;
        });
        
        document.getElementById('statCategories').textContent = Object.keys(categories).length;
        document.getElementById('changeProducts').textContent = '+' + Math.floor(totalProducts * 0.05) + ' this month';
        document.getElementById('changePendingOrders').textContent = pendingOrders + ' awaiting approval';
        document.getElementById('changeStockTransfers').textContent = 'Pending';
        
        // Update Korean & Japanese category cards
        const categoryMap = {
            'Instant Noodles': 'catNoodles',
            'Ramyun': 'catNoodles',
            'Ramen': 'catNoodles',
            'Noodles': 'catNoodles',
            'Sauces': 'catSauces',
            'Condiments': 'catSauces',
            'Sauces & Condiments': 'catSauces',
            'Frozen': 'catFrozen',
            'Frozen Foods': 'catFrozen',
            'Rice': 'catRice',
            'Pantry': 'catRice',
            'Rice & Pantry': 'catRice',
            'Snacks': 'catSnacks',
            'Beverages': 'catBeverages',
            'Drinks': 'catBeverages',
            'Kimchi': 'catKimchi',
            'Pickled': 'catKimchi',
            'Kimchi & Pickled': 'catKimchi',
            'Specialty': 'catSpecialty',
            'Specialty Items': 'catSpecialty'
        };
        
        // Initialize counts
        const categoryCounts = {
            catNoodles: 0,
            catSauces: 0,
            catFrozen: 0,
            catRice: 0,
            catSnacks: 0,
            catBeverages: 0,
            catKimchi: 0,
            catSpecialty: 0
        };
        
        // Count products by category
        products.forEach(p => {
            const cat = p.category || 'Specialty Items';
            // Find matching category
            for (const [key, elementId] of Object.entries(categoryMap)) {
                if (cat.toLowerCase().includes(key.toLowerCase()) || key.toLowerCase().includes(cat.toLowerCase())) {
                    categoryCounts[elementId]++;
                    break;
                }
            }
        });
        
        // Update UI
        document.getElementById('catNoodles').textContent = categoryCounts.catNoodles + ' items';
        document.getElementById('catSauces').textContent = categoryCounts.catSauces + ' items';
        document.getElementById('catFrozen').textContent = categoryCounts.catFrozen + ' items';
        document.getElementById('catRice').textContent = categoryCounts.catRice + ' items';
        document.getElementById('catSnacks').textContent = categoryCounts.catSnacks + ' items';
        document.getElementById('catBeverages').textContent = categoryCounts.catBeverages + ' items';
        document.getElementById('catKimchi').textContent = categoryCounts.catKimchi + ' items';
        document.getElementById('catSpecialty').textContent = categoryCounts.catSpecialty + ' items';
        
        // Supplier stats
        document.getElementById('statTotalSuppliers').textContent = suppliers.length;
        document.getElementById('statActiveSuppliers').textContent = suppliers.filter(s => s.status === 'Active').length;
        document.getElementById('statPendingDeliveries').textContent = pendingOrders;

        // Warehouse utilization (simulated)
        const totalCapacity = 10000;
        const totalStock = products.reduce((sum, p) => {
            const qty = typeof p.stock === 'object' ? Object.values(p.stock).reduce((a, b) => a + b, 0) : parseInt(p.stock || 0);
            return sum + qty;
        }, 0);
        const utilizationPercent = Math.min(100, Math.round((totalStock / totalCapacity) * 100));
        
        document.getElementById('warehousePercent').textContent = utilizationPercent + '%';
        document.getElementById('warehouseProgress').style.width = utilizationPercent + '%';
        document.getElementById('warehouseOccupied').textContent = totalStock.toLocaleString() + ' units';
        document.getElementById('warehouseAvailable').textContent = (totalCapacity - totalStock).toLocaleString() + ' units';
        
        // Inventory table (top 5 products)
        const tableBody = document.getElementById('inventoryTableBody');
        if (products.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:var(--text-muted); padding:20px;">No products found</td></tr>';
        } else {
            const topProducts = products.slice(0, 5);
            tableBody.innerHTML = topProducts.map(p => {
                const qty = typeof p.stock === 'object' ? Object.values(p.stock).reduce((a, b) => a + b, 0) : parseInt(p.stock || 0);
                const status = StockStatus.getStatus(qty);
                const statusClass = StockStatus.getBadgeClass(status);
                const emoji = StockStatus.getEmoji(status);
                
                return `
                    <tr>
                        <td style="font-weight:500; color:var(--text-primary);">${p.name || 'Unnamed Product'}</td>
                        <td style="color:var(--text-secondary);">${p.category || 'N/A'}</td>
                        <td style="font-weight:600; color:var(--text-primary);">${qty}</td>
                        <td><span class="badge ${statusClass}">${emoji} ${status}</span></td>
                    </tr>
                `;
            }).join('');
        }

        // Notifications
        const notifications = [];
        if (lowStockItems.length > 0) {
            notifications.push({
                icon: '⚠️',
                bg: '#FEF3C7',
                title: `${lowStockItems.length} products need restocking`,
                desc: 'Review inventory and create purchase orders'
            });
        }
        if (outOfStockItems.length > 0) {
            notifications.push({
                icon: '🚨',
                bg: '#FEE2E2',
                title: `${outOfStockItems.length} products are out of stock`,
                desc: 'Immediate attention required'
            });
        }
        if (pendingOrders > 0) {
            notifications.push({
                icon: '📋',
                bg: '#DBEAFE',
                title: `${pendingOrders} pending purchase orders`,
                desc: 'Review and approve orders'
            });
        }
        if (utilizationPercent > 85) {
            notifications.push({
                icon: '📦',
                bg: '#FED7AA',
                title: 'Warehouse almost full',
                desc: `${utilizationPercent}% capacity utilization`
            });
        }
        
        const notifPanel = document.getElementById('notificationsPanel');
        const notifCount = document.getElementById('notificationCount');
        notifCount.textContent = notifications.length;
        
        if (notifications.length === 0) {
            notifPanel.innerHTML = `
                <div style="text-align:center; padding:30px; color:var(--text-muted);">
                    <svg width="48" height="48" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" style="margin:0 auto 12px; opacity:0.4;"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <p style="font-weight:500;">All caught up!</p>
                    <p style="font-size:0.85rem;">No notifications at the moment</p>
                </div>
            `;
        } else {
            notifPanel.innerHTML = notifications.map(n => `
                <div class="notification-item">
                    <div class="notification-icon" style="background:${n.bg};">
                        <span style="font-size:20px;">${n.icon}</span>
                    </div>
                    <div class="notification-content">
                        <div class="notification-title">${n.title}</div>
                        <div class="notification-desc">${n.desc}</div>
                    </div>
                </div>
            `).join('');
        }

        // Recent Activities (simulated)
        const activities = [
            {
                icon: '➕',
                bg: 'linear-gradient(135deg, #10B981, #059669)',
                title: 'Product Added',
                time: '2 minutes ago'
            },
            {
                icon: '✅',
                bg: 'linear-gradient(135deg, #3B82F6, #1D4ED8)',
                title: 'Purchase Order Approved',
                time: '15 minutes ago'
            },
            {
                icon: '📦',
                bg: 'linear-gradient(135deg, #8B5CF6, #7C3AED)',
                title: 'Inventory Updated',
                time: '1 hour ago'
            },
            {
                icon: '🔄',
                bg: 'linear-gradient(135deg, #F59E0B, #D97706)',
                title: 'Stock Transfer Completed',
                time: '2 hours ago'
            },
            {
                icon: '👤',
                bg: 'linear-gradient(135deg, #EC4899, #DB2777)',
                title: 'Supplier Updated',
                time: '3 hours ago'
            }
        ];
        
        const activitiesDiv = document.getElementById('recentActivities');
        activitiesDiv.innerHTML = activities.map(a => `
            <div class="timeline-item">
                <div class="timeline-icon" style="background:${a.bg};">
                    <span style="font-size:18px;">${a.icon}</span>
                </div>
                <div class="timeline-content">
                    <div class="timeline-title">${a.title}</div>
                    <div class="timeline-meta">${a.time}</div>
                </div>
            </div>
        `).join('');
        
        // --- Pending Purchase Orders widget ---
        const pendingPOsList = document.getElementById('pendingPOsList');
        if (pendingPOs.length === 0) {
            pendingPOsList.innerHTML = `<div style="text-align:center; color:var(--text-muted); padding:20px;">No pending purchase orders.</div>`;
        } else {
            pendingPOsList.innerHTML = pendingPOs.slice(0, 6).map(po => `
                <div style="display:flex; justify-content:space-between; align-items:center; padding:10px 4px; border-bottom:1px solid var(--border-color);">
                    <div>
                        <div style="font-weight:600; color:var(--text-primary); font-size:0.9rem;">${po.poNumber || po.id}</div>
                        <div style="font-size:0.8rem; color:var(--text-secondary);">${po.supplier || 'Unknown Supplier'} · ${(po.items || []).length} item(s)</div>
                    </div>
                    <span class="badge" style="background:${po.status === 'Draft' ? '#E5E7EB' : '#DBEAFE'}; color:${po.status === 'Draft' ? '#374151' : '#1D4ED8'}; padding:4px 10px; font-size:0.75rem;">${po.status}</span>
                </div>
            `).join('');
        }

        // --- Today's Receiving widget (itemized) ---
        const todaysReceivingList = document.getElementById('todaysReceivingList');
        if (todaysReceivings.length === 0) {
            todaysReceivingList.innerHTML = `<div style="text-align:center; color:var(--text-muted); padding:20px;">No deliveries received today.</div>`;
        } else {
            todaysReceivingList.innerHTML = todaysReceivings.slice(0, 6).map(r => {
                const itemLines = (r.items && r.items.length)
                    ? r.items.map(it => `${it.productName} (+${it.accepted}${it.damaged ? `, ${it.damaged} damaged` : ''}${it.missing ? `, ${it.missing} missing` : ''})`).join(', ')
                    : `${r.accepted || 0} unit(s) accepted${r.damaged ? `, ${r.damaged} damaged` : ''}${r.missing ? `, ${r.missing} missing` : ''}`;
                return `
                    <div style="padding:10px 4px; border-bottom:1px solid var(--border-color);">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <span style="font-weight:600; color:var(--text-primary); font-size:0.9rem;">${r.poNumber || 'PO'} · ${r.supplier || 'Supplier'}</span>
                            <span style="font-size:0.78rem; color:var(--text-muted);">${new Date(r.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                        <div style="font-size:0.8rem; color:var(--text-secondary); margin-top:2px;">${itemLines}</div>
                    </div>
                `;
            }).join('');
        }

        // --- Stock Transfers widget (inbound / outbound relative to Main Warehouse) ---
        const stockTransferDirectionList = document.getElementById('stockTransferDirectionList');
        if (todaysTransfers.length === 0) {
            stockTransferDirectionList.innerHTML = `<div style="text-align:center; color:var(--text-muted); padding:20px;">No stock transfers today.</div>`;
        } else {
            stockTransferDirectionList.innerHTML = todaysTransfers.slice(0, 6).map(t => {
                const isInbound = t.toLocation === 'Main Warehouse';
                const isOutbound = t.fromLocation === 'Main Warehouse';
                const direction = isInbound ? 'Inbound' : (isOutbound ? 'Outbound' : 'Lateral');
                const dirColor = isInbound ? '#059669' : (isOutbound ? '#DC2626' : '#7C3AED');
                const dirBg = isInbound ? '#D1FAE5' : (isOutbound ? '#FEE2E2' : '#EDE9FE');
                return `
                    <div style="display:flex; justify-content:space-between; align-items:center; padding:10px 4px; border-bottom:1px solid var(--border-color);">
                        <div>
                            <div style="font-weight:600; color:var(--text-primary); font-size:0.9rem;">${t.productName || 'Product'}</div>
                            <div style="font-size:0.8rem; color:var(--text-secondary);">${t.fromLocation} → ${t.toLocation} · ${t.quantity} unit(s)</div>
                        </div>
                        <span class="badge" style="background:${dirBg}; color:${dirColor}; padding:4px 10px; font-size:0.75rem; font-weight:700;">${direction}</span>
                    </div>
                `;
            }).join('');
        }

        // Render Charts
        renderCharts(products, purchaseOrders, categories, todaysReceivings, todaysTransfers);
        
    } catch (error) {
        console.error('Failed to load dashboard data:', error);
        document.getElementById('inventoryTableBody').innerHTML = `
            <tr><td colspan="4" style="text-align:center; color:var(--red-text); padding:20px;">Failed to load data</td></tr>
        `;
    }
}

// Chart rendering function
function renderCharts(products, purchaseOrders, categories, todaysReceivings = [], todaysTransfers = []) {
    // Get chart theme colors
    const isDarkTheme = document.documentElement.getAttribute('data-theme') === 'dark';
    const textColor = isDarkTheme ? '#e5e7eb' : '#374151';
    const gridColor = isDarkTheme ? '#374151' : '#e5e7eb';
    
    // Chart.js default settings
    Chart.defaults.color = textColor;
    Chart.defaults.borderColor = gridColor;
    Chart.defaults.font.family = "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif";
    
    // 1. Inventory Trend Chart (Line Chart)
    const inventoryTrendCtx = document.getElementById('inventoryTrendChart');
    if (inventoryTrendCtx) {
        // Generate mock data for the last 7 days
        const last7Days = [];
        const inventoryValues = [];
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            last7Days.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
            
            // Calculate inventory value with slight variations
            const baseValue = products.reduce((sum, p) => {
                const price = parseFloat(p.sellingPrice || p.price || 0);
                const qty = typeof p.stock === 'object' ? Object.values(p.stock).reduce((a, b) => a + b, 0) : parseInt(p.stock || 0);
                return sum + (price * qty);
            }, 0);
            
            // Add random variation (-5% to +5%)
            const variation = 1 + (Math.random() * 0.1 - 0.05);
            inventoryValues.push(Math.round(baseValue * variation));
        }
        
        new Chart(inventoryTrendCtx, {
            type: 'line',
            data: {
                labels: last7Days,
                datasets: [{
                    label: 'Inventory Value (₱)',
                    data: inventoryValues,
                    borderColor: '#FF7A00',
                    backgroundColor: 'rgba(255, 122, 0, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 5,
                    pointHoverRadius: 7,
                    pointBackgroundColor: '#FF7A00',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'bottom'
                    },
                    tooltip: {
                        backgroundColor: isDarkTheme ? '#1f2937' : '#ffffff',
                        titleColor: textColor,
                        bodyColor: textColor,
                        borderColor: gridColor,
                        borderWidth: 1,
                        padding: 12,
                        displayColors: true,
                        callbacks: {
                            label: function(context) {
                                return 'Value: ₱' + context.parsed.y.toLocaleString();
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + (value / 1000).toFixed(0) + 'k';
                            }
                        },
                        grid: {
                            color: gridColor
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }
    
    // 2. Stock Status Chart (Doughnut Chart)
    const stockStatusCtx = document.getElementById('stockStatusChart');
    if (stockStatusCtx) {
        const inStock = products.filter(p => {
            const qty = typeof p.stock === 'object' ? Object.values(p.stock).reduce((a, b) => a + b, 0) : parseInt(p.stock || 0);
            const reorder = parseInt(p.reorderLevel || 10);
            return qty > reorder;
        }).length;
        
        const lowStock = products.filter(p => {
            const qty = typeof p.stock === 'object' ? Object.values(p.stock).reduce((a, b) => a + b, 0) : parseInt(p.stock || 0);
            const reorder = parseInt(p.reorderLevel || 10);
            return qty > 0 && qty <= reorder;
        }).length;
        
        const outOfStock = products.filter(p => {
            const qty = typeof p.stock === 'object' ? Object.values(p.stock).reduce((a, b) => a + b, 0) : parseInt(p.stock || 0);
            return qty === 0;
        }).length;
        
        new Chart(stockStatusCtx, {
            type: 'doughnut',
            data: {
                labels: ['In Stock', 'Low Stock', 'Out of Stock'],
                datasets: [{
                    data: [inStock, lowStock, outOfStock],
                    backgroundColor: [
                        '#10B981',
                        '#F59E0B',
                        '#EF4444'
                    ],
                    borderWidth: 0,
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'bottom',
                        labels: {
                            padding: 15,
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: {
                        backgroundColor: isDarkTheme ? '#1f2937' : '#ffffff',
                        titleColor: textColor,
                        bodyColor: textColor,
                        borderColor: gridColor,
                        borderWidth: 1,
                        padding: 12,
                        callbacks: {
                            label: function(context) {
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((context.parsed / total) * 100).toFixed(1);
                                return context.label + ': ' + context.parsed + ' (' + percentage + '%)';
                            }
                        }
                    }
                },
                cutout: '65%'
            }
        });
    }
    
    // 3. Category Distribution Chart (Bar Chart)
    const categoryCtx = document.getElementById('categoryChart');
    if (categoryCtx) {
        const categoryData = {};
        products.forEach(p => {
            const cat = p.category || 'Specialty Items';
            categoryData[cat] = (categoryData[cat] || 0) + 1;
        });
        
        const sortedCategories = Object.entries(categoryData)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 8);
        
        new Chart(categoryCtx, {
            type: 'bar',
            data: {
                labels: sortedCategories.map(c => c[0]),
                datasets: [{
                    label: 'Number of Products',
                    data: sortedCategories.map(c => c[1]),
                    backgroundColor: [
                        '#FF7A00',
                        '#E53935',
                        '#10B981',
                        '#3B82F6',
                        '#8B5CF6',
                        '#EC4899',
                        '#F59E0B',
                        '#6366F1'
                    ],
                    borderRadius: 8,
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: isDarkTheme ? '#1f2937' : '#ffffff',
                        titleColor: textColor,
                        bodyColor: textColor,
                        borderColor: gridColor,
                        borderWidth: 1,
                        padding: 12,
                        callbacks: {
                            label: function(context) {
                                const total = sortedCategories.reduce((sum, c) => sum + c[1], 0);
                                const pct = total ? ((context.parsed.y / total) * 100).toFixed(1) : '0.0';
                                return `${context.parsed.y} product(s) · ${pct}% of catalog`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        },
                        grid: {
                            color: gridColor
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            maxRotation: 45,
                            minRotation: 45
                        }
                    }
                }
            }
        });
    }
    
    // 4. Purchase Order Status Chart (Pie Chart)
    const poCtx = document.getElementById('purchaseOrderChart');
    if (poCtx) {
        const poStatusData = {
            'Draft': 0,
            'Pending Approval': 0,
            'Approved': 0,
            'Received': 0,
            'Cancelled': 0
        };
        
        purchaseOrders.forEach(po => {
            const status = po.status || 'Draft';
            if (poStatusData.hasOwnProperty(status)) {
                poStatusData[status]++;
            }
        });
        
        const poLabels = Object.keys(poStatusData).filter(key => poStatusData[key] > 0);
        const poValues = poLabels.map(key => poStatusData[key]);
        
        new Chart(poCtx, {
            type: 'pie',
            data: {
                labels: poLabels,
                datasets: [{
                    data: poValues,
                    backgroundColor: [
                        '#9CA3AF',
                        '#F59E0B',
                        '#10B981',
                        '#3B82F6',
                        '#EF4444'
                    ],
                    borderWidth: 0,
                    hoverOffset: 8
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'bottom',
                        labels: {
                            padding: 15,
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: {
                        backgroundColor: isDarkTheme ? '#1f2937' : '#ffffff',
                        titleColor: textColor,
                        bodyColor: textColor,
                        borderColor: gridColor,
                        borderWidth: 1,
                        padding: 12,
                        callbacks: {
                            label: function(context) {
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((context.parsed / total) * 100).toFixed(1);
                                return context.label + ': ' + context.parsed + ' (' + percentage + '%)';
                            }
                        }
                    }
                }
            }
        });
    }
    
    // 5. Top Products by Value Chart (Horizontal Bar Chart)
    const topProductsCtx = document.getElementById('topProductsChart');
    if (topProductsCtx) {
        const productsWithValue = products.map(p => {
            const price = parseFloat(p.sellingPrice || p.price || 0);
            const qty = typeof p.stock === 'object' ? Object.values(p.stock).reduce((a, b) => a + b, 0) : parseInt(p.stock || 0);
            return {
                name: p.name || 'Unnamed Product',
                value: price * qty
            };
        }).filter(p => p.value > 0)
          .sort((a, b) => b.value - a.value)
          .slice(0, 10);
        
        new Chart(topProductsCtx, {
            type: 'bar',
            data: {
                labels: productsWithValue.map(p => p.name.length > 30 ? p.name.substring(0, 27) + '...' : p.name),
                datasets: [{
                    label: 'Inventory Value (₱)',
                    data: productsWithValue.map(p => p.value),
                    backgroundColor: 'rgba(255, 122, 0, 0.8)',
                    borderColor: '#FF7A00',
                    borderWidth: 1,
                    borderRadius: 6
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: isDarkTheme ? '#1f2937' : '#ffffff',
                        titleColor: textColor,
                        bodyColor: textColor,
                        borderColor: gridColor,
                        borderWidth: 1,
                        padding: 12,
                        callbacks: {
                            label: function(context) {
                                return 'Value: ₱' + context.parsed.x.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₱' + (value / 1000).toFixed(0) + 'k';
                            }
                        },
                        grid: {
                            color: gridColor
                        }
                    },
                    y: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }

    // 6. Today's Operations Snapshot (Bar Chart: Received / Transferred / Pending POs)
    const opsSnapshotCtx = document.getElementById('operationsSnapshotChart');
    if (opsSnapshotCtx) {
        const receivedUnits = todaysReceivings.reduce((sum, r) => sum + (parseInt(r.accepted || 0)), 0);
        const inboundTransfers = todaysTransfers.filter(t => t.toLocation === 'Main Warehouse').length;
        const outboundTransfers = todaysTransfers.filter(t => t.fromLocation === 'Main Warehouse').length;
        const pendingApprovalCount = purchaseOrders.filter(po => po.status === 'Draft' || po.status === 'Pending Approval').length;

        new Chart(opsSnapshotCtx, {
            type: 'bar',
            data: {
                labels: ['Units Received Today', 'Inbound Transfers', 'Outbound Transfers', 'Pending POs'],
                datasets: [{
                    label: 'Count',
                    data: [receivedUnits, inboundTransfers, outboundTransfers, pendingApprovalCount],
                    backgroundColor: ['#10B981', '#3B82F6', '#F59E0B', '#EF4444'],
                    borderRadius: 8,
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: isDarkTheme ? '#1f2937' : '#ffffff',
                        titleColor: textColor,
                        bodyColor: textColor,
                        borderColor: gridColor,
                        borderWidth: 1,
                        padding: 12
                    }
                },
                scales: {
                    y: { beginAtZero: true, ticks: { stepSize: 1 }, grid: { color: gridColor } },
                    x: { grid: { display: false } }
                }
            }
        });
    }
}

