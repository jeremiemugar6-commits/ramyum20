import { DataService } from '../../assets/js/utils/data-service.js';
import { toast } from '../../assets/js/components/toast.js';
import { modal } from '../../assets/js/components/modal.js';
import { DataTable } from '../../assets/js/components/table.js';
import { store } from '../../assets/js/store.js';
import { formatCurrency } from '../../assets/js/utils/format.js';
import { BadgeHelper } from '../../assets/js/utils/badge-helper.js';

const dataService = new DataService();

// Demo Integration Mode Configuration
let demoConfig = null;

async function loadDemoConfig() {
    if (!demoConfig) {
        try {
            const response = await fetch('api/demo-config.php');
            const result = await response.json();
            demoConfig = result.success ? result.data : { demoMode: false, demoMessage: '' };
        } catch (error) {
            console.warn('Could not load demo config:', error);
            demoConfig = { demoMode: false, demoMessage: '' };
        }
    }
    return demoConfig;
}

// Generate receiving numbers in GR-YYYY-NNNN format
async function generateReceivingNumber() {
    const currentYear = new Date().getFullYear();
    const allReceivings = await dataService.findAll('receivings');
    
    // Find the highest receiving number for current year
    const yearReceivings = allReceivings.filter(gr => 
        gr.receivingNumber && gr.receivingNumber.startsWith(`GR-${currentYear}-`)
    );
    
    let maxNumber = 0;
    yearReceivings.forEach(gr => {
        const match = gr.receivingNumber.match(/GR-\d{4}-(\d{4})/);
        if (match) {
            maxNumber = Math.max(maxNumber, parseInt(match[1]));
        }
    });
    
    const nextNumber = (maxNumber + 1).toString().padStart(4, '0');
    return `GR-${currentYear}-${nextNumber}`;
}

// --- RENDER FUNCTION ---
export async function renderReceiving() {
    const container = document.getElementById('appContent');
    const userRole = store.getState().role;
    const canReceive = userRole === 'admin' || userRole === 'manager' || userRole === 'staff';
    
    // Load demo configuration
    const config = await loadDemoConfig();

    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:26px; flex-wrap:wrap; gap:16px; background:var(--bg-card); padding:22px 26px; border-radius:12px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm);">
            <div>
                <h1 class="page-title">📦 Receiving & Inspection (Consolidated)</h1>
                <p class="page-subtitle">Inspect deliveries BEFORE adding to inventory. Accept/reject items in real-time.</p>
                ${config.demoMode ? BadgeHelper.getDemoIndicator(config.demoMessage) : ''}
            </div>
            ${canReceive ? `<button id="viewPOBtn" style="background:var(--secondary-orange); color:white; padding:10px 20px; border:none; border-radius:8px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:8px;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
                Receive & Inspect Delivery
            </button>` : ''}
        </div>

        <!-- View Toggle -->
        <div style="display:flex; gap:8px; margin-bottom:16px; border-bottom:1px solid var(--border-color); padding-bottom:12px;">
            <button class="view-tab active" data-view="pending" style="padding:8px 16px; background:transparent; border:none; border-bottom:2px solid var(--primary-red); color:var(--primary-red); font-weight:500; cursor:pointer;">Pending Deliveries</button>
            <button class="view-tab" data-view="history" style="padding:8px 16px; background:transparent; border:none; color:var(--text-secondary); cursor:pointer;">Receiving History</button>
        </div>

        <!-- Table Container -->
        <div id="receivingDataContainer"></div>
    `;

    // Attach Tab Event Listeners
    document.querySelectorAll('.view-tab').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            document.querySelectorAll('.view-tab').forEach(b => {
                b.style.borderBottom = 'none';
                b.style.color = 'var(--text-secondary)';
                b.classList.remove('active');
            });
            
            const target = e.target;
            target.style.borderBottom = '2px solid var(--primary-red)';
            target.style.color = 'var(--primary-red)';
            target.classList.add('active');

            if (target.dataset.view === 'history') {
                await renderHistoryView();
            } else {
                await renderPendingView();
            }
        });
    });

    document.getElementById('viewPOBtn')?.addEventListener('click', () => openReceivingModal());

    // Initial Load
    await renderPendingView();
}

// --- RENDER: PENDING DELIVERIES ---
async function renderPendingView() {
    const container = document.getElementById('receivingDataContainer');
    
    // Fetch all approved POs that haven't been fully received
    const allPOs = await dataService.findAll('purchase_orders');
    const pendingPOs = allPOs.filter(po => 
        po.status === 'Approved' || po.status === 'Partially Received'
    );

    if (pendingPOs.length === 0) {
        container.innerHTML = `
            <div class="card" style="text-align:center; padding:40px;">
                <p style="color:var(--text-secondary); font-size:1.1rem;">No pending deliveries.</p>
                <p style="color:var(--text-secondary); font-size:0.9rem;">Approved Purchase Orders will appear here for receiving.</p>
            </div>
        `;
        return;
    }

    const columns = [
        { key: 'poNumber', label: 'PO #' },
        { key: 'supplier', label: 'Supplier' },
        { key: 'orderDate', label: 'Ordered On' },
        { key: 'total', label: 'Total Value' },
        { key: 'receivingStatus', label: 'Receiving Status' },
        { key: 'actions', label: '' }
    ];

    const formattedData = pendingPOs.map(po => {
        // Calculate receiving progress
        const totalItems = po.items.reduce((sum, item) => sum + item.quantity, 0);
        const receivedItems = po.items.reduce((sum, item) => sum + (item.receivedQuantity || 0), 0);
        const receivingProgress = totalItems > 0 ? ((receivedItems / totalItems) * 100).toFixed(1) : 0;
        
        let statusBadge = '';
        if (po.status === 'Approved') {
            statusBadge = BadgeHelper.getReceivingStatusBadge('Not Started');
        } else if (po.status === 'Partially Received') {
            statusBadge = BadgeHelper.getReceivingProgressBadge(receivedItems, totalItems);
        }
        
        return {
            ...po,
            supplier: po.supplier_name || po.supplier || 'Unknown Supplier',
            orderDate: new Date(po.orderDate).toLocaleDateString(),
            total: BadgeHelper.formatCurrency(po.total),
            receivingStatus: statusBadge,
            actions: `<button class="receive-btn" data-id="${po.id}" style="background:#10B981; color:white; border:none; padding:6px 12px; border-radius:4px; cursor:pointer; font-weight:500;">Receive Items</button>`
        };
    });

    container.innerHTML = `<div id="pendingTableContainer"></div>`;
    new DataTable('pendingTableContainer', columns, formattedData, { actions: false });

    // Attach Receive Button Listeners
    container.querySelectorAll('.receive-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const poId = e.target.dataset.id;
            const poData = await dataService.findById('purchase_orders', poId);
            openReceivingModal(poData);
        });
    });
}

// --- RENDER: RECEIVING HISTORY ---
async function renderHistoryView() {
    const container = document.getElementById('receivingDataContainer');
    
    let history = await dataService.findAll('receivings');
    
    if (history.length === 0) {
        container.innerHTML = `
            <div class="card" style="text-align:center; padding:40px;">
                <p style="color:var(--text-secondary); font-size:1.1rem;">No receiving history yet.</p>
                <p style="color:var(--text-secondary); font-size:0.9rem;">Completed receiving transactions will appear here.</p>
            </div>
        `;
        return;
    }

    history.sort((a, b) => new Date(b.receivedDate || b.date) - new Date(a.receivedDate || a.date));

    // Check POR status for each receiving
    const historyWithPOR = await Promise.all(history.map(async (h) => {
        try {
            const porResponse = await fetch(`api/por.php?action=list&receiving_id=${h.id}`);
            const porData = await porResponse.json();
            return {
                ...h,
                hasPOR: porData.success && porData.data && porData.data.length > 0,
                porData: porData.success && porData.data && porData.data.length > 0 ? porData.data[0] : null
            };
        } catch (error) {
            return { ...h, hasPOR: false, porData: null };
        }
    }));

    const columns = [
        { key: 'receivingNumber', label: 'GR #' },
        { key: 'receivedDate', label: 'Received Date' },
        { key: 'poNumber', label: 'PO #' },
        { key: 'supplier', label: 'Supplier' },
        { key: 'itemsReceived', label: 'Items Received' },
        { key: 'totalValue', label: 'Value' },
        { key: 'porStatus', label: 'POR Status' },
        { key: 'actions', label: 'Actions' }
    ];

    const formattedData = historyWithPOR.map(h => {
        let porStatusHTML = '';
        let actionsHTML = '';
        
        if (h.hasPOR && h.porData) {
            const statusColor = h.porData.status === 'Completed' ? '#10B981' : '#F59E0B';
            porStatusHTML = `<span style="background:${statusColor}; color:white; padding:3px 8px; border-radius:4px; font-size:0.8rem; font-weight:500;">${h.porData.status}</span>`;
            actionsHTML = `<button class="view-por-btn" data-por-id="${h.porData.id}" style="background:#3B82F6; color:white; border:none; padding:4px 10px; border-radius:4px; cursor:pointer; font-size:0.85rem; margin-right:4px;">View POR</button>`;
        } else {
            porStatusHTML = '<span style="color:#9CA3AF; font-size:0.85rem;">No POR (Legacy)</span>';
            actionsHTML = `<span style="color:#9CA3AF; font-size:0.8rem; font-style:italic;">Old workflow</span>`;
        }
        
        actionsHTML += `<button class="view-details-btn" data-id="${h.id}" style="background:#6B7280; color:white; border:none; padding:4px 10px; border-radius:4px; cursor:pointer; font-size:0.85rem; margin-left:4px;">Details</button>`;
        
        return {
            ...h,
            supplier: h.supplierName || h.supplier || 'Unknown Supplier',
            receivedDate: new Date(h.receivedDate || h.date).toLocaleString(),
            itemsReceived: `<span style="color:#10B981; font-weight:600;">${h.totalReceived || h.accepted || 0}</span>`,
            totalValue: h.totalValue ? `₱${formatCurrency(h.totalValue)}` : 'N/A',
            receivingNumber: h.receivingNumber || `GR-${h.id?.slice(-4) || '0000'}`,
            porStatus: porStatusHTML,
            actions: actionsHTML
        };
    });

    container.innerHTML = `<div id="historyTableContainer"></div>`;
    new DataTable('historyTableContainer', columns, formattedData, { actions: false });
    
    // Attach event listeners for POR actions
    container.querySelectorAll('.view-por-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const porId = e.target.dataset.porId;
            viewPORDetails(porId);
        });
    });
    
    container.querySelectorAll('.view-details-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const receivingId = e.target.dataset.id;
            const receivingData = await dataService.findById('receivings', receivingId);
            viewReceivingDetails(receivingData);
        });
    });
}

// --- CORE FEATURE: RECEIVING MODAL ---
async function openReceivingModal(existingPO = null) {
    let targetPO = existingPO;

    // If no specific PO is passed, show a selection dropdown
    if (!targetPO) {
        const allPOs = await dataService.findAll('purchase_orders');
        const pendingPOs = allPOs.filter(p => 
            p.status === 'Approved' || p.status === 'Partially Received'
        );

        if (pendingPOs.length === 0) {
            toast.show('No approved POs awaiting delivery.', 'info');
            return;
        }

        const selectHTML = `
            <div style="margin-bottom:16px;">
                <label style="display:block; font-weight:500; margin-bottom:4px;">Select Purchase Order to Receive *</label>
                <select id="deliverySelect" class="form-input">
                    <option value="">-- Select PO --</option>
                    ${pendingPOs.map(po => {
                        const totalItems = po.items.reduce((sum, item) => sum + item.quantity, 0);
                        const receivedItems = po.items.reduce((sum, item) => sum + (item.receivedQuantity || 0), 0);
                        const progress = totalItems > 0 ? ` (${receivedItems}/${totalItems} received)` : '';
                        return `<option value="${po.id}">${po.poNumber} - ${po.supplier}${progress} - ₱${formatCurrency(po.total)}</option>`;
                    }).join('')}
                </select>
            </div>
        `;

        modal.open('Select Purchase Order', selectHTML, {
            confirmText: 'Start Receiving',
            onConfirm: async () => {
                const selectedId = document.getElementById('deliverySelect').value;
                if (!selectedId) { toast.show('Please select a PO.', 'error'); return; }
                const poData = await dataService.findById('purchase_orders', selectedId);
                modal.close();
                renderReceivingForm(poData);
            }
        });
    } else {
        renderReceivingForm(targetPO);
    }
}

async function renderReceivingForm(poData) {
    const title = `Receive & Inspect Delivery: ${poData.poNumber}`;

    // Load locations/branches from Locations module API (same source as Locations page)
    let locations = [];
    try {
        const res = await fetch('api/locations.php?action=all');
        const body = await res.json();
        if (body.success && Array.isArray(body.data)) {
            locations = body.data;
        }
        // Prefer Active; still show others if status is missing
        locations = (locations || [])
            .filter(l => {
                const s = (l.status || 'Active').toString().toLowerCase();
                return s === 'active' || s === '';
            })
            .sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), undefined, { sensitivity: 'base' }));
    } catch (e) {
        console.warn('Could not load locations from api/locations.php', e);
    }
    const locationOptions = locations.length
        ? locations.map(l => {
            const type = l.type ? ` · ${l.type}` : '';
            const code = l.code ? ` (${l.code})` : '';
            return `<option value="${String(l.id).replace(/"/g, '&quot;')}">${String(l.name || l.id).replace(/</g, '&lt;')}${code}${type}</option>`;
          }).join('')
        : '<option value="" disabled>No locations found — add them in Locations module</option>';
    const todayStr = new Date().toISOString().slice(0, 10);

    // Build dynamic receiving items form with INSPECTION fields
    let itemsHTML = poData.items.map((item, index) => {
        const receivedQty = item.receivedQuantity || 0;
        const remainingQty = item.quantity - receivedQty;
        const maxReceivable = remainingQty;
        const batchVal = item.batchNumber || item.batch_number || '';
        const expVal = item.expirationDate || item.expiration_date || '';
        
        return `
            <div class="receiving-item" data-product-id="${item.productId || ''}" style="border:1px solid var(--border-color); border-radius:8px; margin-bottom:12px; padding:12px; background:var(--bg-card);">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; padding-bottom:8px; border-bottom:1px solid var(--border-color);">
                    <div>
                        <div style="font-weight:600; color:var(--text-primary); font-size:1rem;">${item.productName}</div>
                        <div style="font-size:0.85rem; color:var(--text-secondary);">SKU: ${item.sku || 'N/A'} | Unit: ${item.unit || 'pcs'} | Unit Cost: ₱${formatCurrency(item.unitCost)}</div>
                    </div>
                    <div style="text-align:right;">
                        <div style="font-size:0.8rem; color:var(--text-secondary);">Ordered: <strong>${item.quantity}</strong></div>
                        <div style="font-size:0.8rem; color:var(--text-secondary);">Remaining: <strong style="color:#F59E0B;">${remainingQty}</strong></div>
                    </div>
                </div>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:12px;">
                    <div>
                        <label style="font-size:0.85rem; display:block; margin-bottom:4px; color:var(--text-primary); font-weight:500;">Batch No. *</label>
                        <input type="text" class="item-batch-no" value="${batchVal}" placeholder="e.g. SAM-2026-001"
                               data-item-index="${index}"
                               style="width:100%; padding:8px; border:1px solid var(--border-color); border-radius:6px;">
                    </div>
                    <div>
                        <label style="font-size:0.85rem; display:block; margin-bottom:4px; color:var(--text-primary); font-weight:500;">Expiration Date *</label>
                        <input type="date" class="item-expiration" value="${expVal}"
                               data-item-index="${index}"
                               style="width:100%; padding:8px; border:1px solid var(--border-color); border-radius:6px;">
                    </div>
                </div>
                
                <div style="display:grid; grid-template-columns:repeat(4, 1fr); gap:12px;">
                    <div>
                        <label style="font-size:0.85rem; display:block; margin-bottom:4px; color:var(--text-primary); font-weight:500;">Received Qty *</label>
                        <input type="number" 
                               class="receive-qty" 
                               min="0" 
                               max="${maxReceivable}" 
                               value="${maxReceivable}" 
                               data-item-index="${index}"
                               data-max="${maxReceivable}"
                               style="width:100%; padding:8px; border:1px solid var(--border-color); border-radius:6px; text-align:center; font-weight:600;">
                        <div style="font-size:0.75rem; color:var(--text-secondary); margin-top:2px; text-align:center;">Total delivered</div>
                    </div>
                    
                    <div>
                        <label style="font-size:0.85rem; display:block; margin-bottom:4px; color:#10B981; font-weight:500;">Accepted *</label>
                        <input type="number" 
                               class="accepted-qty" 
                               min="0" 
                               value="${maxReceivable}" 
                               data-item-index="${index}"
                               style="width:100%; padding:8px; border:1px solid #10B981; border-radius:6px; text-align:center; font-weight:600; background:#F0FDF4;">
                        <div style="font-size:0.75rem; color:#10B981; margin-top:2px; text-align:center;">Good quality</div>
                    </div>
                    
                    <div>
                        <label style="font-size:0.85rem; display:block; margin-bottom:4px; color:#EF4444; font-weight:500;">Rejected</label>
                        <input type="number" 
                               class="rejected-qty" 
                               min="0" 
                               value="0" 
                               data-item-index="${index}"
                               style="width:100%; padding:8px; border:1px solid #EF4444; border-radius:6px; text-align:center; font-weight:600; background:#FEF2F2;">
                        <div style="font-size:0.75rem; color:#EF4444; margin-top:2px; text-align:center;">Poor quality</div>
                    </div>
                    
                    <div>
                        <label style="font-size:0.85rem; display:block; margin-bottom:4px; color:#F59E0B; font-weight:500;">Damaged</label>
                        <input type="number" 
                               class="damaged-qty" 
                               min="0" 
                               value="0" 
                               data-item-index="${index}"
                               style="width:100%; padding:8px; border:1px solid #F59E0B; border-radius:6px; text-align:center; font-weight:600; background:#FFFBEB;">
                        <div style="font-size:0.75rem; color:#F59E0B; margin-top:2px; text-align:center;">Broken/damaged</div>
                    </div>
                </div>
                
                <div style="margin-top:8px; padding:8px; background:#F9FAFB; border-radius:4px; font-size:0.8rem; color:var(--text-secondary);">
                    <strong>Note:</strong> Accepted + Rejected + Damaged must equal Received quantity. Only <strong style="color:#10B981;">accepted items</strong> will be added to inventory.
                </div>

                <div class="damage-evidence-section" style="margin-top:12px; padding:12px; background:#FFFBEB; border:1px solid #F59E0B; border-radius:6px; display:none;">
                    <div style="font-weight:600; color:#92400E; margin-bottom:8px;">⚠️ Damage Evidence</div>
                    <div style="margin-bottom:8px;">
                        <label style="font-size:0.85rem; display:block; margin-bottom:4px;">Damage Reason / Description</label>
                        <input type="text" class="damage-reason" placeholder="e.g. Damaged packaging, crushed boxes..."
                               style="width:100%; padding:8px; border:1px solid var(--border-color); border-radius:6px;">
                    </div>
                    <div>
                        <label style="font-size:0.85rem; display:block; margin-bottom:4px;">Damage Photo / Evidence</label>
                        <input type="file" class="damage-photo-input" accept="image/jpeg,image/png,image/gif,image/webp,image/*" capture="environment"
                               style="width:100%; padding:6px; border:1px solid var(--border-color); border-radius:6px; background:#fff;">
                        <input type="hidden" class="damage-photo-path" value="">
                        <div class="damage-photo-preview" style="margin-top:8px; display:none;">
                            <img src="" alt="Damage evidence" style="max-width:160px; max-height:120px; border-radius:6px; border:1px solid var(--border-color);">
                            <div style="font-size:0.75rem; color:#10B981; margin-top:4px;">Photo attached ✓</div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }).join('');

    const formHTML = `
        <div style="background:#F0F9FF; padding:12px; border-radius:8px; margin-bottom:16px; border-left:4px solid #3B82F6;">
            <div style="display:flex; gap:16px; flex-wrap:wrap;">
                <div><strong>Supplier:</strong> ${poData.supplier_name || poData.supplier || 'Unknown'}</div>
                <div><strong>PO Number:</strong> ${poData.poNumber}</div>
                <div><strong>Order Date:</strong> ${new Date(poData.orderDate).toLocaleDateString()}</div>
                <div><strong>Status:</strong> <span style="color:#10B981; font-weight:600;">${poData.status}</span></div>
            </div>
        </div>
        
        <div style="background:#FEF3C7; padding:12px; border-radius:8px; margin-bottom:16px; border-left:4px solid #F59E0B;">
            <strong style="color:#92400E;">⚠️ NEW CONSOLIDATED WORKFLOW:</strong>
            <p style="margin:4px 0 0 0; color:#78350F; font-size:0.9rem;">
                Inspect items BEFORE receiving. Only <strong>accepted quantities</strong> will be added to inventory immediately. 
                This creates both Receiving record (historical) and Proof of Receiving (inspection results) in one transaction.
            </p>
        </div>
        
        <div style="border-top:1px solid var(--border-color); padding-top:16px;">
            <h4 style="margin-bottom:12px; color:var(--text-primary);">📦 Items to Receive & Inspect</h4>
            <div id="receivingItemsContainer">
                ${itemsHTML}
            </div>
        </div>

        <div style="margin-top:16px; padding:14px; background:#FFF7ED; border:1px solid #FDBA74; border-radius:8px;">
            <h4 style="margin:0 0 12px 0; color:#9A3412; font-size:0.95rem;">📍 Delivery Information (Location – Date of Delivery in the Store)</h4>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                <div>
                    <label style="display:block; font-weight:500; margin-bottom:4px; color:var(--text-primary);">Delivery Date *</label>
                    <input type="date" id="receivingDeliveryDate" class="form-input" value="${todayStr}" required>
                    <small style="color:var(--text-secondary); font-size:0.75rem;">When products arrived at the store</small>
                </div>
                <div>
                    <label style="display:block; font-weight:500; margin-bottom:4px; color:var(--text-primary);">Store Location *</label>
                    <select id="receivingStoreLocation" class="form-input" required>
                        <option value="">-- Select store / warehouse --</option>
                        ${locationOptions}
                    </select>
                    <small style="color:var(--text-secondary); font-size:0.75rem;">Where stock will be recorded</small>
                </div>
            </div>
        </div>

        <div style="margin-top:16px;">
            <label style="display:block; font-weight:500; margin-bottom:4px; color:var(--text-primary);">📝 Inspection Notes</label>
            <textarea id="receivingNotes" rows="3" class="form-input" style="resize:vertical;" placeholder="Record any observations about quality, damages, discrepancies, or special handling instructions..."></textarea>
        </div>
    `;

    modal.open(title, formHTML, {
        confirmText: '✓ Complete Receiving & Inspection',
        width: '900px',
        onConfirm: async () => {
            await processConsolidatedReceiving(poData);
        }
    });
    
    // Add real-time validation for inspection quantities
    document.querySelectorAll('.receiving-item').forEach((itemDiv, index) => {
        const receivedInput = itemDiv.querySelector('.receive-qty');
        const acceptedInput = itemDiv.querySelector('.accepted-qty');
        const rejectedInput = itemDiv.querySelector('.rejected-qty');
        const damagedInput = itemDiv.querySelector('.damaged-qty');
        
        // Validate received quantity max
        receivedInput.addEventListener('input', (e) => {
            const max = parseInt(e.target.dataset.max);
            const value = parseInt(e.target.value) || 0;
            
            if (value > max) {
                e.target.value = max;
                toast.show(`Cannot receive more than remaining quantity (${max})`, 'warning');
            }
            
            // Auto-adjust accepted to match received
            const currentAccepted = parseInt(acceptedInput.value) || 0;
            const currentRejected = parseInt(rejectedInput.value) || 0;
            const currentDamaged = parseInt(damagedInput.value) || 0;
            const totalInspection = currentAccepted + currentRejected + currentDamaged;
            
            if (totalInspection === 0 || currentAccepted === totalInspection) {
                acceptedInput.value = value;
            }
        });
        
        // Validate inspection quantities sum
        const validateInspectionSum = () => {
            const received = parseInt(receivedInput.value) || 0;
            const accepted = parseInt(acceptedInput.value) || 0;
            const rejected = parseInt(rejectedInput.value) || 0;
            const damaged = parseInt(damagedInput.value) || 0;
            const sum = accepted + rejected + damaged;
            
            // Visual feedback
            const border = sum === received ? '1px solid #10B981' : sum > received ? '1px solid #EF4444' : '1px solid #F59E0B';
            acceptedInput.style.border = border;
            rejectedInput.style.border = border;
            damagedInput.style.border = border;
            
            if (sum > received) {
                toast.show('Inspection total cannot exceed received quantity', 'warning');
            }
        };
        
        acceptedInput.addEventListener('input', validateInspectionSum);
        rejectedInput.addEventListener('input', validateInspectionSum);
        damagedInput.addEventListener('input', () => {
            validateInspectionSum();
            const dmgSection = itemDiv.querySelector('.damage-evidence-section');
            const dmgQty = parseInt(damagedInput.value) || 0;
            if (dmgSection) {
                dmgSection.style.display = dmgQty > 0 ? 'block' : 'none';
            }
        });

        // Damage photo upload
        const photoInput = itemDiv.querySelector('.damage-photo-input');
        const photoPath = itemDiv.querySelector('.damage-photo-path');
        const photoPreview = itemDiv.querySelector('.damage-photo-preview');
        if (photoInput) {
            photoInput.addEventListener('change', async (e) => {
                const file = e.target.files && e.target.files[0];
                if (!file) return;
                const allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
                if (!allowed.includes(file.type)) {
                    toast.show('Only JPEG, PNG, GIF, or WebP images are allowed.', 'error');
                    photoInput.value = '';
                    return;
                }
                if (file.size > 5 * 1024 * 1024) {
                    toast.show('Image must be under 5MB.', 'error');
                    photoInput.value = '';
                    return;
                }
                try {
                    const formData = new FormData();
                    formData.append('image', file);
                    formData.append('type', 'damage');
                    const resp = await fetch('api/upload-image.php', { method: 'POST', body: formData });
                    const result = await resp.json();
                    if (result.success && (result.data?.path || result.path)) {
                        const uploadedPath = result.data?.path || result.path;
                        photoPath.value = uploadedPath;
                        const img = photoPreview.querySelector('img');
                        if (img) img.src = uploadedPath;
                        photoPreview.style.display = 'block';
                        toast.show('Damage photo uploaded.', 'success');
                    } else {
                        toast.show(result.error || 'Upload failed', 'error');
                    }
                } catch (err) {
                    console.error(err);
                    toast.show('Failed to upload damage photo.', 'error');
                }
            });
        }
    });
}

// NEW: Consolidated Receiving + Inspection in one transaction
async function processConsolidatedReceiving(poData) {
    const receivingItems = document.querySelectorAll('.receiving-item');
    const notes = document.getElementById('receivingNotes').value.trim();
    const deliveryDate = document.getElementById('receivingDeliveryDate')?.value || '';
    const storeLocationId = document.getElementById('receivingStoreLocation')?.value || '';
    const storeLocationSelect = document.getElementById('receivingStoreLocation');
    const storeLocationName = storeLocationSelect?.selectedOptions?.[0]?.text?.trim() || '';
    
    let inspectionItems = [];
    let hasItemsToReceive = false;
    let validationErrors = [];

    if (!deliveryDate) {
        validationErrors.push('Delivery Date is required');
    }
    if (!storeLocationId) {
        validationErrors.push('Store Location is required');
    }
    
    // Collect and validate inspection data
    receivingItems.forEach((itemDiv, index) => {
        const item = poData.items[index];
        
        const received = parseInt(itemDiv.querySelector('.receive-qty').value) || 0;
        const accepted = parseInt(itemDiv.querySelector('.accepted-qty').value) || 0;
        const rejected = parseInt(itemDiv.querySelector('.rejected-qty').value) || 0;
        const damaged = parseInt(itemDiv.querySelector('.damaged-qty').value) || 0;
        const batchNumber = (itemDiv.querySelector('.item-batch-no')?.value || '').trim();
        const expirationDate = (itemDiv.querySelector('.item-expiration')?.value || '').trim();
        const damageReason = (itemDiv.querySelector('.damage-reason')?.value || '').trim();
        const damagePhotoPath = (itemDiv.querySelector('.damage-photo-path')?.value || '').trim();
        
        const inspectionSum = accepted + rejected + damaged;
        
        // Validation
        if (received > 0) {
            hasItemsToReceive = true;
            if (!batchNumber) {
                validationErrors.push(`${item.productName}: Batch Number is required`);
            }
            if (!expirationDate) {
                validationErrors.push(`${item.productName}: Expiration Date is required`);
            }
            if (damaged > 0 && !damageReason) {
                validationErrors.push(`${item.productName}: Damage reason is required when damaged quantity > 0`);
            }
            
            if (inspectionSum !== received) {
                validationErrors.push(
                    `${item.productName}: Inspection quantities (${inspectionSum}) don't match received (${received})`
                );
            }
            
            if (accepted < 0 || rejected < 0 || damaged < 0) {
                validationErrors.push(`${item.productName}: Quantities cannot be negative`);
            }
        }
        
        inspectionItems.push({
            product_id: item.productId,
            sku: item.sku || 'N/A',
            product_name: item.productName,
            unit: item.unit || 'pcs',
            ordered_quantity: item.quantity,
            received_quantity: received,
            accepted_quantity: accepted,
            rejected_quantity: rejected,
            damaged_quantity: damaged,
            unit_cost: item.unitCost,
            batch_number: batchNumber || null,
            expiration_date: expirationDate || null,
            damage_reason: damaged > 0 ? (damageReason || null) : null,
            damage_photo_path: damaged > 0 ? (damagePhotoPath || null) : null,
            inspection_result: accepted === received ? 'Passed' : 
                             accepted > 0 ? 'Conditional' : 'Failed'
        });
    });
    
    // Validation checks
    if (!hasItemsToReceive) {
        toast.show('Please enter quantities to receive.', 'warning');
        return;
    }
    
    if (validationErrors.length > 0) {
        toast.show('Validation: ' + validationErrors[0] + (validationErrors.length > 1 ? ` (+${validationErrors.length - 1} more)` : ''), 'error');
        return;
    }
    
    // Confirm before proceeding
    const totalReceived = inspectionItems.reduce((sum, item) => sum + item.received_quantity, 0);
    const totalAccepted = inspectionItems.reduce((sum, item) => sum + item.accepted_quantity, 0);
    const totalRejected = inspectionItems.reduce((sum, item) => sum + item.rejected_quantity, 0);
    const totalDamaged = inspectionItems.reduce((sum, item) => sum + item.damaged_quantity, 0);
    
    const confirmMessage = 
        `Ready to process receiving & inspection:\n\n` +
        `📦 Received: ${totalReceived} items\n` +
        `✅ Accepted: ${totalAccepted} items (will be added to inventory)\n` +
        `❌ Rejected: ${totalRejected} items (will NOT be added)\n` +
        `⚠️ Damaged: ${totalDamaged} items (will NOT be added)\n\n` +
        `This will create both Receiving and POR records in one transaction.\n` +
        `Continue?`;
    
    if (!confirm(confirmMessage)) {
        return;
    }
    
    try {
        toast.show('Processing receiving & inspection...', 'info');
        
        // Call new consolidated workflow API
        const response = await fetch('api/workflow-processor.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'receive_and_inspect_items',
                purchase_order_id: poData.id,
                items: inspectionItems,
                inspection_notes: notes,
                received_by: store.getState().user?.name || 'System',
                delivery_date: deliveryDate,
                store_location_id: storeLocationId,
                store_location_name: storeLocationName
            })
        });
        
        const result = await response.json();
        
        if (!result.success) {
            throw new Error(result.error || result.message || 'Failed to process receiving');
        }
        
        // Success!
        const data = result.data;
        
        toast.show(
            `✓ Receiving & Inspection Complete!\n` +
            `📋 Receiving: ${data.receiving_number}\n` +
            `📋 POR ${data.por_number} auto-created (${data.inspection_status})\n` +
            `✅ ${totalAccepted} items added to inventory`,
            'success'
        );
        
        modal.close();
        
        // Dispatch event for POR module to update counts
        console.log('📤 [Receiving] Dispatching porCreated event...', {
            por_id: data.por_id,
            por_number: data.por_number,
            inspection_status: data.inspection_status
        });
        
        window.dispatchEvent(new CustomEvent('porCreated', {
            detail: {
                por_id: data.por_id,
                por_number: data.por_number,
                inspection_status: data.inspection_status
            }
        }));
        
        console.log('✅ [Receiving] porCreated event dispatched successfully');
        
        // Refresh the view
        await renderPendingView();
        
        // Show detailed results
        setTimeout(() => {
            showReceivingResults(data);
        }, 500);
        
    } catch (error) {
        console.error('Consolidated Receiving Error:', error);
        toast.show('Error: ' + error.message, 'error');
    }
}

// Show detailed results modal after successful receiving
function showReceivingResults(data) {
    const itemsHTML = data.inspection_results ? data.inspection_results.map(item => {
        const statusColor = item.inspection_result === 'Passed' ? '#10B981' : 
                          item.inspection_result === 'Conditional' ? '#F59E0B' : '#EF4444';
        const statusIcon = item.inspection_result === 'Passed' ? '✓' : 
                          item.inspection_result === 'Conditional' ? '⚠' : '✗';
        
        return `
            <div style="display:grid; grid-template-columns:2fr repeat(4, 1fr) 100px; gap:8px; padding:12px; border-bottom:1px solid var(--border-color); align-items:center;">
                <div>
                    <div style="font-weight:500;">${item.product_name}</div>
                    <div style="font-size:0.8rem; color:var(--text-secondary);">SKU: ${item.sku}</div>
                </div>
                <div style="text-align:center;">${item.received_quantity}</div>
                <div style="text-align:center; color:#10B981; font-weight:600;">${item.accepted_quantity}</div>
                <div style="text-align:center; color:#EF4444;">${item.rejected_quantity}</div>
                <div style="text-align:center; color:#F59E0B;">${item.damaged_quantity}</div>
                <div style="text-align:center;">
                    <span style="background:${statusColor}; color:white; padding:4px 8px; border-radius:4px; font-size:0.85rem; font-weight:500;">
                        ${statusIcon} ${item.inspection_result}
                    </span>
                </div>
            </div>
        `;
    }).join('') : '';
    
    const bodyHTML = `
        <div id="receiptContent">
            <div style="background:#F0F9FF; padding:16px; border-radius:8px; margin-bottom:16px; border-left:4px solid #3B82F6;">
                <div style="display:grid; grid-template-columns:repeat(2, 1fr); gap:12px;">
                    <div><strong>Receiving Number:</strong> ${data.receiving_number}</div>
                    <div><strong>POR Number:</strong> ${data.por_number}</div>
                    <div><strong>PO Number:</strong> ${data.po_number}</div>
                    <div><strong>Status:</strong> <span style="color:#10B981; font-weight:600;">${data.po_status}</span></div>
                </div>
            </div>
            
            <div style="display:grid; grid-template-columns:repeat(4, 1fr); gap:12px; margin-bottom:16px;">
                <div style="background:#F0FDF4; padding:12px; border-radius:8px; text-align:center; border:2px solid #10B981;">
                    <div style="font-size:0.8rem; color:#15803D; margin-bottom:4px;">✅ Accepted</div>
                    <div style="font-size:1.5rem; font-weight:700; color:#10B981;">${data.total_accepted || 0}</div>
                    <div style="font-size:0.75rem; color:#15803D;">Added to inventory</div>
                </div>
                <div style="background:#FEF2F2; padding:12px; border-radius:8px; text-align:center; border:2px solid #EF4444;">
                    <div style="font-size:0.8rem; color:#991B1B; margin-bottom:4px;">❌ Rejected</div>
                    <div style="font-size:1.5rem; font-weight:700; color:#EF4444;">${data.total_rejected || 0}</div>
                    <div style="font-size:0.75rem; color:#991B1B;">Not added</div>
                </div>
                <div style="background:#FFFBEB; padding:12px; border-radius:8px; text-align:center; border:2px solid #F59E0B;">
                    <div style="font-size:0.8rem; color:#92400E; margin-bottom:4px;">⚠️ Damaged</div>
                    <div style="font-size:1.5rem; font-weight:700; color:#F59E0B;">${data.total_damaged || 0}</div>
                    <div style="font-size:0.75rem; color:#92400E;">Not added</div>
                </div>
                <div style="background:#F3F4F6; padding:12px; border-radius:8px; text-align:center; border:2px solid #6B7280;">
                    <div style="font-size:0.8rem; color:#374151; margin-bottom:4px;">📦 Total Received</div>
                    <div style="font-size:1.5rem; font-weight:700; color:#6B7280;">${data.total_received || 0}</div>
                    <div style="font-size:0.75rem; color:#374151;">Physical count</div>
                </div>
            </div>
            
            <div style="border-top:2px solid var(--border-color); padding-top:16px;">
                <div style="display:grid; grid-template-columns:2fr repeat(4, 1fr) 100px; gap:8px; padding:8px; background:var(--bg-secondary); font-weight:600; font-size:0.85rem; border-radius:4px; margin-bottom:8px;">
                    <div>Product</div>
                    <div style="text-align:center;">Received</div>
                    <div style="text-align:center;">Accepted</div>
                    <div style="text-align:center;">Rejected</div>
                    <div style="text-align:center;">Damaged</div>
                    <div style="text-align:center;">Result</div>
                </div>
                ${itemsHTML}
            </div>
            
            ${data.inventory_updated ? `
                <div style="margin-top:16px; background:#F0FDF4; padding:12px; border-radius:8px; border-left:4px solid #10B981;">
                    <strong style="color:#15803D;">✓ Inventory Updated Successfully</strong>
                    <p style="margin:4px 0 0 0; color:#15803D; font-size:0.9rem;">
                        Stock levels have been updated for all accepted items. Stock status badges recalculated.
                    </p>
                </div>
            ` : ''}
            
            <div style="margin-top:16px; padding-top:16px; border-top:1px solid var(--border-color); font-size:0.8rem; color:var(--text-secondary); text-align:center;">
                Generated on ${new Date().toLocaleString()} | RAM-YUM Inventory System
            </div>
        </div>
    `;
    
    modal.open('📋 Receiving & Inspection Results', bodyHTML, {
        confirmText: 'Close',
        cancelText: 'Save Receipt',
        width: '1000px',
        onCancel: () => saveReceivingReceipt(data),
        onConfirm: () => modal.close()
    });
}

// Function to view receiving details
function viewReceivingDetails(receivingData) {
    const title = `Receiving Details: ${receivingData.receivingNumber}`;
    
    const itemsHTML = receivingData.items ? receivingData.items.map(item => `
        <div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid var(--border-color); font-size:0.9rem;">
            <div style="flex:2;">
                <div style="font-weight:500;">${item.productName}</div>
                <div style="font-size:0.8rem; color:var(--text-secondary);">₱${formatCurrency(item.unitCost)} each</div>
            </div>
            <div style="text-align:right; color:#10B981; font-weight:600;">${item.quantityReceived}</div>
        </div>
    `).join('') : '<p style="color:var(--text-secondary);">No item details available.</p>';
    
    const bodyHTML = `
        <div style="display:grid; gap:12px; margin-bottom:16px;">
            <p><strong>PO Number:</strong> ${receivingData.poNumber}</p>
            <p><strong>Supplier:</strong> ${receivingData.supplier}</p>
            <p><strong>Received Date:</strong> ${new Date(receivingData.receivedDate || receivingData.date).toLocaleString()}</p>
            <p><strong>Received By:</strong> ${receivingData.receivedBy}</p>
            ${receivingData.totalValue ? `<p><strong>Total Value:</strong> ₱${formatCurrency(receivingData.totalValue)}</p>` : ''}
            ${receivingData.notes ? `<p><strong>Notes:</strong> ${receivingData.notes}</p>` : ''}
        </div>
        
        <div style="border-top:1px solid var(--border-color); padding-top:16px;">
            <h4 style="margin-bottom:8px;">Items Received</h4>
            ${itemsHTML}
        </div>
    `;
    
    modal.open(title, bodyHTML, {
        confirmText: 'Close',
        onConfirm: () => modal.close()
    });
}

// Create POR from receiving record
async function createPORFromReceiving(receivingId) {
    try {
        // Show loading state
        toast.show('Creating Proof of Receiving...', 'info');
        
        const response = await fetch('api/por.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                action: 'create-from-receiving',
                receiving_id: receivingId
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            toast.show('Proof of Receiving created successfully!', 'success');
            
            // Refresh the history view to update POR status
            await renderHistoryView();
            
            // Optionally, open the POR for inspection
            const confirmInspect = confirm('POR created successfully. Would you like to open it for inspection now?');
            if (confirmInspect && result.por_id) {
                viewPORDetails(result.por_id);
            }
        } else {
            throw new Error(result.message || 'Failed to create POR');
        }
    } catch (error) {
        console.error('Error creating POR:', error);
        toast.show('Error creating POR: ' + error.message, 'error');
    }
}

// View POR details (redirects to POR module)
async function viewPORDetails(porId) {
    try {
        // Fetch POR data to display preview
        const response = await fetch(`api/por.php?action=details&id=${porId}`);
        const result = await response.json();
        
        if (result.success) {
            const por = result.data;
            
            const itemsHTML = por.items ? por.items.map(item => {
                const acceptanceRate = item.received_quantity > 0 
                    ? ((item.accepted_quantity / item.received_quantity) * 100).toFixed(1)
                    : 0;
                const statusColor = item.inspection_result === 'Passed' ? '#10B981' : 
                                  item.inspection_result === 'Failed' ? '#EF4444' : 
                                  item.inspection_result === 'Conditional' ? '#F59E0B' : '#9CA3AF';
                
                return `
                    <div style="display:grid; grid-template-columns:2fr 1fr 1fr 1fr 1fr 1fr; gap:8px; padding:8px; border-bottom:1px solid var(--border-color); font-size:0.85rem; align-items:center;">
                        <div>
                            <div style="font-weight:500;">${item.product_name}</div>
                            <div style="font-size:0.75rem; color:var(--text-secondary);">SKU: ${item.sku}</div>
                        </div>
                        <div style="text-align:center;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Ordered</div>
                            <div style="font-weight:600;">${item.ordered_quantity}</div>
                        </div>
                        <div style="text-align:center;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Received</div>
                            <div style="font-weight:600; color:#3B82F6;">${item.received_quantity}</div>
                        </div>
                        <div style="text-align:center;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Accepted</div>
                            <div style="font-weight:600; color:#10B981;">${item.accepted_quantity}</div>
                        </div>
                        <div style="text-align:center;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Rejected</div>
                            <div style="font-weight:600; color:#EF4444;">${item.rejected_quantity}</div>
                        </div>
                        <div style="text-align:center;">
                            <span style="background:${statusColor}; color:white; padding:2px 6px; border-radius:4px; font-size:0.75rem; font-weight:500;">${item.inspection_result}</span>
                        </div>
                    </div>
                `;
            }).join('') : '<p style="color:var(--text-secondary);">No items available.</p>';
            
            const statusColor = por.status === 'Completed' ? '#10B981' : 
                              por.status === 'Draft' ? '#F59E0B' : '#EF4444';
            const inspectionColor = ({ Passed: '#10B981', Completed: '#10B981', Partial: '#F97316', 'In Progress': '#3B82F6', Failed: '#EF4444' })[por.inspection_status] || '#F59E0B';
            
            const bodyHTML = `
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:16px;">
                    <div>
                        <p style="margin-bottom:8px;"><strong>POR Number:</strong> ${por.por_number}</p>
                        <p style="margin-bottom:8px;"><strong>PO Number:</strong> ${por.purchase_order_number || 'N/A'}</p>
                        <p style="margin-bottom:8px;"><strong>Supplier:</strong> ${por.supplier_name}</p>
                        <p style="margin-bottom:8px;"><strong>Receiving Date:</strong> ${new Date(por.receiving_date).toLocaleDateString()}</p>
                    </div>
                    <div>
                        <p style="margin-bottom:8px;"><strong>Status:</strong> <span style="background:${statusColor}; color:white; padding:3px 8px; border-radius:4px; font-size:0.85rem; font-weight:500;">${por.status}</span></p>
                        <p style="margin-bottom:8px;"><strong>Inspection:</strong> <span style="background:${inspectionColor}; color:white; padding:3px 8px; border-radius:4px; font-size:0.85rem; font-weight:500;">${por.inspection_status}</span></p>
                        <p style="margin-bottom:8px;"><strong>Inventory Updated:</strong> ${por.inventory_updated == 1 ? '<span style="color:#10B981;">✓ Yes</span>' : '<span style="color:#9CA3AF;">✗ No</span>'}</p>
                    </div>
                </div>
                
                ${por.notes ? `<div style="margin-bottom:16px;"><strong>Notes:</strong><br><p style="color:var(--text-secondary); font-size:0.9rem;">${por.notes}</p></div>` : ''}
                ${por.inspection_notes ? `<div style="margin-bottom:16px;"><strong>Inspection Notes:</strong><br><p style="color:var(--text-secondary); font-size:0.9rem;">${por.inspection_notes}</p></div>` : ''}
                
                <div style="border-top:1px solid var(--border-color); padding-top:16px; margin-top:16px;">
                    <h4 style="margin-bottom:12px;">Inspection Results</h4>
                    <div style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:12px; margin-bottom:16px;">
                        <div style="text-align:center; padding:10px; background:var(--bg-gray); border-radius:6px;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Total Received</div>
                            <div style="font-size:1.3rem; font-weight:700; color:#3B82F6;">${por.total_received || 0}</div>
                        </div>
                        <div style="text-align:center; padding:10px; background:var(--bg-gray); border-radius:6px;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Accepted</div>
                            <div style="font-size:1.3rem; font-weight:700; color:#10B981;">${por.total_accepted || 0}</div>
                        </div>
                        <div style="text-align:center; padding:10px; background:var(--bg-gray); border-radius:6px;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Rejected</div>
                            <div style="font-size:1.3rem; font-weight:700; color:#EF4444;">${por.total_rejected || 0}</div>
                        </div>
                        <div style="text-align:center; padding:10px; background:var(--bg-gray); border-radius:6px;">
                            <div style="font-size:0.75rem; color:var(--text-secondary);">Acceptance Rate</div>
                            <div style="font-size:1.3rem; font-weight:700; color:${por.total_received > 0 && ((por.total_accepted / por.total_received) * 100) >= 95 ? '#10B981' : '#F59E0B'};">${por.total_received > 0 ? ((por.total_accepted / por.total_received) * 100).toFixed(1) : 0}%</div>
                        </div>
                    </div>
                    ${itemsHTML}
                </div>
                
                <div style="margin-top:16px; padding:12px; background:#EFF6FF; border-radius:6px; border-left:4px solid #3B82F6;">
                    <p style="font-size:0.9rem; color:#1E40AF; margin:0;">
                        <strong>Note:</strong> To edit inspection results or complete this POR, please visit the <strong>Proof of Receiving</strong> module.
                    </p>
                </div>
            `;
            
            modal.open(`POR Details: ${por.por_number}`, bodyHTML, {
                confirmText: 'Go to POR Module',
                cancelText: 'Close',
                onConfirm: () => {
                    modal.close();
                    // Navigate to POR module
                    window.location.hash = '#por';
                    // Trigger navigation
                    document.querySelector('.nav-item[data-page="por"]')?.click();
                }
            });
        } else {
            throw new Error(result.message || 'Failed to load POR details');
        }
    } catch (error) {
        console.error('Error viewing POR:', error);
        toast.show('Error loading POR details: ' + error.message, 'error');
    }
}


// Save receiving receipt as PDF/Print
function saveReceivingReceipt(data) {
    // Create a printable receipt document
    const receiptWindow = window.open('', '_blank', 'width=800,height=600');
    
    const itemsHTML = data.inspection_results ? data.inspection_results.map(item => `
        <tr>
            <td style="padding:8px; border:1px solid #ddd;">
                <strong>${item.product_name}</strong><br>
                <small style="color:#666;">SKU: ${item.sku}</small>
            </td>
            <td style="padding:8px; border:1px solid #ddd; text-align:center;">${item.received_quantity}</td>
            <td style="padding:8px; border:1px solid #ddd; text-align:center; color:#10B981; font-weight:bold;">${item.accepted_quantity}</td>
            <td style="padding:8px; border:1px solid #ddd; text-align:center; color:#EF4444; font-weight:bold;">${item.rejected_quantity}</td>
            <td style="padding:8px; border:1px solid #ddd; text-align:center; color:#F59E0B; font-weight:bold;">${item.damaged_quantity}</td>
            <td style="padding:8px; border:1px solid #ddd; text-align:center;">
                <span style="padding:2px 8px; border-radius:3px; font-size:0.85em; background:${item.inspection_result === 'Passed' ? '#10B981' : item.inspection_result === 'Conditional' ? '#F59E0B' : '#EF4444'}; color:white;">
                    ${item.inspection_result}
                </span>
            </td>
        </tr>
    `).join('') : '';
    
    receiptWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Receiving Receipt - ${data.receiving_number}</title>
            <style>
                @media print {
                    .no-print { display: none; }
                    body { margin: 0; }
                }
                
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    max-width: 1000px;
                    margin: 20px auto;
                    padding: 20px;
                    background: #fff;
                }
                
                .header {
                    text-align: center;
                    border-bottom: 3px solid #FF7A00;
                    padding-bottom: 20px;
                    margin-bottom: 30px;
                }
                
                .header h1 {
                    color: #FF7A00;
                    margin: 0;
                    font-size: 2em;
                }
                
                .header p {
                    color: #666;
                    margin: 5px 0;
                }
                
                .document-title {
                    background: linear-gradient(135deg, #FF7A00, #DC143C);
                    color: white;
                    padding: 15px;
                    text-align: center;
                    font-size: 1.5em;
                    font-weight: bold;
                    border-radius: 8px;
                    margin-bottom: 20px;
                }
                
                .info-section {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 15px;
                    margin-bottom: 25px;
                    padding: 15px;
                    background: #F0F9FF;
                    border-left: 4px solid #3B82F6;
                    border-radius: 5px;
                }
                
                .info-item {
                    font-size: 0.95em;
                }
                
                .info-item strong {
                    color: #333;
                }
                
                .summary-cards {
                    display: grid;
                    grid-template-columns: repeat(4, 1fr);
                    gap: 15px;
                    margin-bottom: 25px;
                }
                
                .summary-card {
                    padding: 15px;
                    border-radius: 8px;
                    text-align: center;
                    border: 2px solid;
                }
                
                .summary-card.accepted {
                    background: #F0FDF4;
                    border-color: #10B981;
                }
                
                .summary-card.rejected {
                    background: #FEF2F2;
                    border-color: #EF4444;
                }
                
                .summary-card.damaged {
                    background: #FFFBEB;
                    border-color: #F59E0B;
                }
                
                .summary-card.total {
                    background: #F3F4F6;
                    border-color: #6B7280;
                }
                
                .summary-card .label {
                    font-size: 0.85em;
                    margin-bottom: 5px;
                }
                
                .summary-card .value {
                    font-size: 2em;
                    font-weight: bold;
                }
                
                .summary-card .note {
                    font-size: 0.75em;
                    margin-top: 5px;
                }
                
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin: 20px 0;
                }
                
                th {
                    background: #333;
                    color: white;
                    padding: 10px;
                    text-align: left;
                    font-weight: 600;
                }
                
                td {
                    padding: 8px;
                    border: 1px solid #ddd;
                }
                
                tr:nth-child(even) {
                    background: #f9f9f9;
                }
                
                .footer {
                    margin-top: 40px;
                    padding-top: 20px;
                    border-top: 2px solid #ddd;
                    text-align: center;
                    color: #666;
                    font-size: 0.9em;
                }
                
                .signatures {
                    display: grid;
                    grid-template-columns: 1fr 1fr 1fr;
                    gap: 40px;
                    margin: 40px 0;
                }
                
                .signature-box {
                    text-align: center;
                    padding-top: 50px;
                    border-top: 2px solid #333;
                }
                
                .signature-box strong {
                    display: block;
                    margin-top: 10px;
                }
                
                .inventory-notice {
                    background: #F0FDF4;
                    padding: 15px;
                    border-left: 4px solid #10B981;
                    border-radius: 5px;
                    margin: 20px 0;
                }
                
                .inventory-notice strong {
                    color: #15803D;
                }
                
                .print-button {
                    background: #FF7A00;
                    color: white;
                    border: none;
                    padding: 12px 30px;
                    font-size: 1em;
                    font-weight: bold;
                    border-radius: 5px;
                    cursor: pointer;
                    display: block;
                    margin: 20px auto;
                }
                
                .print-button:hover {
                    background: #DC143C;
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>🍜 RAM-YUM</h1>
                <p>Product & Inventory Operations System</p>
                <p>Product Supply Chain Management</p>
            </div>
            
            <div class="document-title">
                📋 RECEIVING & INSPECTION RECEIPT
            </div>
            
            <div class="info-section">
                <div class="info-item">
                    <strong>Receiving Number:</strong> ${data.receiving_number}
                </div>
                <div class="info-item">
                    <strong>POR Number:</strong> ${data.por_number}
                </div>
                <div class="info-item">
                    <strong>PO Number:</strong> ${data.po_number}
                </div>
                <div class="info-item">
                    <strong>Status:</strong> <span style="color:#10B981; font-weight:bold;">${data.po_status}</span>
                </div>
                <div class="info-item">
                    <strong>Date:</strong> ${new Date().toLocaleString()}
                </div>
                <div class="info-item">
                    <strong>Received By:</strong> ${store.getState().user?.name || 'System'}
                </div>
            </div>
            
            <h3 style="color:#333; margin-top:30px;">📊 Inspection Summary</h3>
            <div class="summary-cards">
                <div class="summary-card accepted">
                    <div class="label" style="color:#15803D;">✅ Accepted</div>
                    <div class="value" style="color:#10B981;">${data.total_accepted || 0}</div>
                    <div class="note" style="color:#15803D;">Added to inventory</div>
                </div>
                <div class="summary-card rejected">
                    <div class="label" style="color:#991B1B;">❌ Rejected</div>
                    <div class="value" style="color:#EF4444;">${data.total_rejected || 0}</div>
                    <div class="note" style="color:#991B1B;">Not added</div>
                </div>
                <div class="summary-card damaged">
                    <div class="label" style="color:#92400E;">⚠️ Damaged</div>
                    <div class="value" style="color:#F59E0B;">${data.total_damaged || 0}</div>
                    <div class="note" style="color:#92400E;">Not added</div>
                </div>
                <div class="summary-card total">
                    <div class="label" style="color:#374151;">📦 Total Received</div>
                    <div class="value" style="color:#6B7280;">${data.total_received || 0}</div>
                    <div class="note" style="color:#374151;">Physical count</div>
                </div>
            </div>
            
            <h3 style="color:#333; margin-top:30px;">📦 Items Inspection Details</h3>
            <table>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th style="text-align:center;">Received</th>
                        <th style="text-align:center;">Accepted</th>
                        <th style="text-align:center;">Rejected</th>
                        <th style="text-align:center;">Damaged</th>
                        <th style="text-align:center;">Result</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemsHTML}
                </tbody>
            </table>
            
            ${data.inventory_updated ? `
                <div class="inventory-notice">
                    <strong>✓ Inventory Updated Successfully</strong>
                    <p style="margin:5px 0 0 0; color:#15803D;">
                        Stock levels have been updated for all accepted items. Stock status badges recalculated.
                    </p>
                </div>
            ` : ''}
            
            <div class="signatures">
                <div class="signature-box">
                    <strong>Received By</strong>
                    <p style="color:#666; font-size:0.9em; margin-top:5px;">${store.getState().user?.name || 'System'}</p>
                </div>
                <div class="signature-box">
                    <strong>Inspected By</strong>
                    <p style="color:#666; font-size:0.9em; margin-top:5px;">Quality Control</p>
                </div>
                <div class="signature-box">
                    <strong>Approved By</strong>
                    <p style="color:#666; font-size:0.9em; margin-top:5px;">Manager</p>
                </div>
            </div>
            
            <div class="footer">
                <p><strong>This is an official receiving receipt</strong></p>
                <p>Generated by RAM-YUM Inventory System | ${new Date().toLocaleString()}</p>
                <p style="font-size:0.85em; color:#999; margin-top:10px;">
                    This document serves as proof of receiving and inspection. Keep for records.
                </p>
            </div>
            
            <button class="print-button no-print" onclick="window.print()">🖨️ Print Receipt</button>
        </body>
        </html>
    `);
    
    receiptWindow.document.close();
    
    // Auto-print after a short delay
    setTimeout(() => {
        receiptWindow.focus();
    }, 250);
    
    toast.show('Receipt opened in new window. Click Print button to save as PDF.', 'success');
}
