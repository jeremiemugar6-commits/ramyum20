/**
 * Proof of Receiving (POR) Module
 * Manages receiving inspections from suppliers with quality control
 */

const PORModule = (() => {
    let currentPORs = [];
    let currentPOR = null;
    let selectedReceivingId = null;

    // Initialize module
    function init() {
        console.log('POR Module initialized');
        loadPORList();
        attachEventListeners();
    }

    // Attach event listeners
    function attachEventListeners() {
        // Use vanilla JS if jQuery not available
        const $ = window.jQuery || window.$;
        
        if (!$) {
            console.warn('jQuery not available, using vanilla JavaScript');
            
            // Vanilla JS event listeners
            const statusFilter = document.getElementById('porStatusFilter');
            const inspectionFilter = document.getElementById('porInspectionFilter');
            const searchInput = document.getElementById('porSearchInput');
            const refreshBtn = document.getElementById('refreshPORList');
            const createFromReceivingBtn = document.getElementById('createFromReceivingBtn');
            
            if (statusFilter) statusFilter.addEventListener('change', loadPORList);
            if (inspectionFilter) inspectionFilter.addEventListener('change', loadPORList);
            if (searchInput) searchInput.addEventListener('input', debounce(loadPORList, 300));
            if (refreshBtn) refreshBtn.addEventListener('click', loadPORList);
            if (createFromReceivingBtn) createFromReceivingBtn.addEventListener('click', showReceivingSelectionModal);
            
            return;
        }
        
        // jQuery event listeners (original)
        $('#porStatusFilter').on('change', loadPORList);
        $('#porInspectionFilter').on('change', loadPORList);
        $('#porSearchInput').on('input', debounce(loadPORList, 300));
        
        // Refresh button
        $('#refreshPORList').on('click', loadPORList);
        
        // Create POR button
        $('#createPORBtn').on('click', showCreatePORModal);
        
        // Create from receiving button
        $('#createFromReceivingBtn').on('click', showReceivingSelectionModal);
    }

    // Load POR list with filters
    async function loadPORList() {
        const statusElem = document.getElementById('porStatusFilter');
        const inspectionElem = document.getElementById('porInspectionFilter');
        const searchElem = document.getElementById('porSearchInput');
        
        const status = statusElem ? statusElem.value : '';
        const inspectionStatus = inspectionElem ? inspectionElem.value : '';
        const search = searchElem ? searchElem.value.trim() : '';

        try {
            showTableLoading('#porTableBody');

            const params = new URLSearchParams({
                action: 'list'
            });

            if (status) params.append('status', status);
            if (inspectionStatus) params.append('inspection_status', inspectionStatus);
            if (search) params.append('search', search);

            const response = await fetchAPI(`api/por.php?${params.toString()}`);

            if (response.success) {
                currentPORs = response.data || [];
                renderPORTable(currentPORs);
                updatePORSummary(response.summary || {});
            } else {
                throw new Error(response.message || 'Failed to load POR list');
            }
        } catch (error) {
            console.error('Error loading POR list:', error);
            showToast('Error loading POR list: ' + error.message, 'error');
            const tbody = document.getElementById('porTableBody');
            if (tbody) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="10" class="text-center text-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            Error loading data: ${sanitizeHTML(error.message)}
                        </td>
                    </tr>
                `;
            }
        }
    }

        try {
            showTableLoading('#porTableBody');

            const params = new URLSearchParams({
                action: 'list'
            });

            if (status) params.append('status', status);
            if (inspectionStatus) params.append('inspection_status', inspectionStatus);
            if (search) params.append('search', search);

            const response = await fetchAPI(`api/por.php?${params.toString()}`);

            if (response.success) {
                currentPORs = response.data || [];
                renderPORTable(currentPORs);
                updatePORSummary(response.summary || {});
            } else {
                throw new Error(response.message || 'Failed to load POR list');
            }
        } catch (error) {
            console.error('Error loading POR list:', error);
            showToast('Error loading POR list: ' + error.message, 'error');
            $('#porTableBody').html(`
                <tr>
                    <td colspan="10" class="text-center text-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Error loading data: ${sanitizeHTML(error.message)}
                    </td>
                </tr>
            `);
        }
    }

    // Render POR table
    function renderPORTable(pors) {
        const tbody = document.getElementById('porTableBody');
        
        if (!tbody) {
            console.error('porTableBody element not found');
            return;
        }

        if (!pors || pors.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="10" class="text-center text-muted">
                        <i class="fas fa-inbox me-2"></i>
                        No proof of receiving records found
                    </td>
                </tr>
            `;
            return;
        }

        const rows = pors.map(por => {
            const statusBadge = getStatusBadge(por.status);
            const inspectionBadge = getInspectionBadge(por.inspection_status);
            const receivedValue = parseFloat(por.total_value || 0);
            const acceptedValue = parseFloat(por.accepted_value || 0);
            const acceptanceRate = por.total_received > 0 
                ? ((por.total_accepted / por.total_received) * 100).toFixed(1) 
                : 0;

            return `
                <tr>
                    <td>
                        <strong>${sanitizeHTML(por.por_number)}</strong><br>
                        <small class="text-muted">${sanitizeHTML(por.purchase_order_number || 'N/A')}</small>
                    </td>
                    <td>${sanitizeHTML(por.supplier_name || 'Unknown')}</td>
                    <td>${formatDate(por.receiving_date)}</td>
                    <td class="text-end">
                        <div>${por.total_ordered || 0}</div>
                        <small class="text-muted">ordered</small>
                    </td>
                    <td class="text-end">
                        <div class="text-primary">${por.total_received || 0}</div>
                        <small class="text-muted">received</small>
                    </td>
                    <td class="text-end">
                        <div class="text-success">${por.total_accepted || 0}</div>
                        <small class="text-muted">accepted</small>
                    </td>
                    <td class="text-end">
                        <div class="text-danger">${por.total_rejected || 0}</div>
                        <small class="text-muted">rejected</small>
                    </td>
                    <td class="text-end">
                        <div>₱${formatCurrency(receivedValue)}</div>
                        <small class="text-success">₱${formatCurrency(acceptedValue)}</small>
                    </td>
                    <td>
                        ${statusBadge}
                        ${inspectionBadge}
                        ${por.inventory_updated == 1 ? '<span class="badge bg-info">Inventoried</span>' : ''}
                    </td>
                    <td>
                        <div class="btn-group btn-group-sm">
                            <button class="btn btn-outline-primary" onclick="PORModule.viewPORDetails(${por.id})" title="View Details">
                                <i class="fas fa-eye"></i>
                            </button>
                            ${por.status === 'Draft' ? `
                                <button class="btn btn-outline-success" onclick="PORModule.completePOR(${por.id})" title="Complete POR">
                                    <i class="fas fa-check"></i>
                                </button>
                                <button class="btn btn-outline-warning" onclick="PORModule.editPOR(${por.id})" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                            ` : ''}
                            <button class="btn btn-outline-info" onclick="PORModule.printPOR(${por.id})" title="Print">
                                <i class="fas fa-print"></i>
                            </button>
                            ${por.status === 'Draft' ? `
                                <button class="btn btn-outline-danger" onclick="PORModule.cancelPOR(${por.id})" title="Cancel">
                                    <i class="fas fa-times"></i>
                                </button>
                            ` : ''}
                        </div>
                    </td>
                </tr>
            `;
        }).join('');

        tbody.innerHTML = rows;
    }

    // Update summary statistics
    function updatePORSummary(summary) {
        const totalPORsElem = document.getElementById('totalPORs');
        const pendingElem = document.getElementById('pendingInspection');
        const completedElem = document.getElementById('completedPORs');
        const acceptedValueElem = document.getElementById('totalAcceptedValue');
        
        if (totalPORsElem) totalPORsElem.textContent = summary.total_pors || 0;
        if (pendingElem) pendingElem.textContent = summary.pending_inspection || 0;
        if (completedElem) completedElem.textContent = summary.completed || 0;
        if (acceptedValueElem) acceptedValueElem.textContent = '₱' + formatCurrency(summary.total_accepted_value || 0);
    }

    // View POR details
    async function viewPORDetails(porId) {
        try {
            const response = await fetchAPI(`api/por.php?action=details&id=${porId}`);

            if (response.success) {
                currentPOR = response.data;
                displayPORDetails(currentPOR);
                $('#porDetailsModal').modal('show');
            } else {
                throw new Error(response.message || 'Failed to load POR details');
            }
        } catch (error) {
            console.error('Error loading POR details:', error);
            showToast('Error loading POR details: ' + error.message, 'error');
        }
    }

    // Display POR details in modal
    function displayPORDetails(por) {
        // Header information
        $('#detailPORNumber').text(por.por_number);
        $('#detailPONumber').text(por.purchase_order_number || 'N/A');
        $('#detailSupplier').text(por.supplier_name);
        $('#detailReceivingDate').text(formatDate(por.receiving_date));
        $('#detailStatus').html(getStatusBadge(por.status));
        $('#detailInspectionStatus').html(getInspectionBadge(por.inspection_status));
        $('#detailInventoryUpdated').html(
            por.inventory_updated == 1 
                ? '<span class="badge bg-info">Yes - ' + formatDateTime(por.inventory_updated_at) + '</span>'
                : '<span class="badge bg-secondary">No</span>'
        );

        // Notes
        $('#detailNotes').text(por.notes || 'No notes');
        $('#detailInspectionNotes').text(por.inspection_notes || 'No inspection notes');

        // Items table
        const itemsHtml = por.items.map(item => {
            const acceptanceRate = item.received_quantity > 0 
                ? ((item.accepted_quantity / item.received_quantity) * 100).toFixed(1) 
                : 0;
            const inspectionBadge = getItemInspectionBadge(item.inspection_result);

            return `
                <tr>
                    <td>
                        <strong>${sanitizeHTML(item.product_name)}</strong><br>
                        <small class="text-muted">SKU: ${sanitizeHTML(item.sku)}</small>
                        ${item.batch_number ? `<br><small class="badge bg-secondary">Batch: ${sanitizeHTML(item.batch_number)}</small>` : ''}
                        ${item.expiration_date ? `<br><small class="badge bg-warning">Exp: ${formatDate(item.expiration_date)}</small>` : ''}
                    </td>
                    <td class="text-end">${item.ordered_quantity || 0}</td>
                    <td class="text-end text-primary">${item.received_quantity || 0}</td>
                    <td class="text-end text-success">${item.accepted_quantity || 0}</td>
                    <td class="text-end text-danger">${item.rejected_quantity || 0}</td>
                    <td class="text-end text-warning">${item.damaged_quantity || 0}</td>
                    <td class="text-end">
                        <span class="badge ${acceptanceRate >= 95 ? 'bg-success' : acceptanceRate >= 80 ? 'bg-warning' : 'bg-danger'}">
                            ${acceptanceRate}%
                        </span>
                    </td>
                    <td>${inspectionBadge}</td>
                    <td class="text-end">₱${formatCurrency(item.unit_price)}</td>
                    <td class="text-end">
                        <strong>₱${formatCurrency(item.received_quantity * item.unit_price)}</strong><br>
                        <small class="text-success">₱${formatCurrency(item.accepted_quantity * item.unit_price)}</small>
                    </td>
                </tr>
            `;
        }).join('');

        $('#detailItemsTable tbody').html(itemsHtml || '<tr><td colspan="10" class="text-center">No items</td></tr>');

        // Totals
        $('#detailTotalOrdered').text(por.total_ordered || 0);
        $('#detailTotalReceived').text(por.total_received || 0);
        $('#detailTotalAccepted').text(por.total_accepted || 0);
        $('#detailTotalRejected').text(por.total_rejected || 0);
        $('#detailTotalValue').text('₱' + formatCurrency(por.total_value || 0));
        $('#detailAcceptedValue').text('₱' + formatCurrency(por.accepted_value || 0));

        // Evidence files
        if (por.evidence_files && por.evidence_files.length > 0) {
            const evidenceHtml = por.evidence_files.map(file => `
                <a href="${sanitizeHTML(file)}" target="_blank" class="btn btn-sm btn-outline-primary me-2 mb-2">
                    <i class="fas fa-image me-1"></i> View Evidence
                </a>
            `).join('');
            $('#detailEvidenceFiles').html(evidenceHtml);
        } else {
            $('#detailEvidenceFiles').html('<span class="text-muted">No evidence files</span>');
        }

        // Action buttons
        const actionsHtml = [];
        if (por.status === 'Draft') {
            actionsHtml.push(`
                <button class="btn btn-success" onclick="PORModule.completePOR(${por.id})">
                    <i class="fas fa-check me-1"></i> Complete POR
                </button>
                <button class="btn btn-warning" onclick="PORModule.editPOR(${por.id})">
                    <i class="fas fa-edit me-1"></i> Edit
                </button>
                <button class="btn btn-danger" onclick="PORModule.cancelPOR(${por.id})">
                    <i class="fas fa-times me-1"></i> Cancel
                </button>
            `);
        }
        actionsHtml.push(`
            <button class="btn btn-info" onclick="PORModule.printPOR(${por.id})">
                <i class="fas fa-print me-1"></i> Print
            </button>
        `);
        $('#detailActions').html(actionsHtml.join(''));
    }

    // Show create POR modal
    function showCreatePORModal() {
        $('#createPORForm')[0].reset();
        $('#porItemsContainer').html('');
        $('#createPORModal').modal('show');
        loadSuppliersForPOR();
        loadProductsForPOR();
    }

    // Show receiving selection modal for creating POR from receiving
    async function showReceivingSelectionModal() {
        try {
            // Load receivings without POR
            const response = await fetchAPI('api/por.php?action=list&without_por=1');
            
            if (response.success) {
                const receivings = response.receivings || [];
                renderReceivingSelection(receivings);
                $('#receivingSelectionModal').modal('show');
            } else {
                throw new Error(response.message || 'Failed to load receivings');
            }
        } catch (error) {
            console.error('Error loading receivings:', error);
            showToast('Error loading receivings: ' + error.message, 'error');
        }
    }

    // Render receiving selection list
    function renderReceivingSelection(receivings) {
        const container = $('#receivingSelectionList');

        if (!receivings || receivings.length === 0) {
            container.html('<div class="alert alert-info">No receivings without POR found</div>');
            return;
        }

        const html = receivings.map(receiving => `
            <div class="card mb-2">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h6 class="mb-1">PO: ${sanitizeHTML(receiving.purchase_order_number || 'N/A')}</h6>
                            <p class="mb-0 text-muted">
                                Supplier: ${sanitizeHTML(receiving.supplier_name || 'Unknown')} | 
                                Date: ${formatDate(receiving.receiving_date)} | 
                                Items: ${receiving.total_items || 0}
                            </p>
                        </div>
                        <div class="col-md-4 text-end">
                            <button class="btn btn-primary btn-sm" onclick="PORModule.createPORFromReceiving(${receiving.id})">
                                <i class="fas fa-plus me-1"></i> Create POR
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');

        container.html(html);
    }

    // Create POR from receiving
    async function createPORFromReceiving(receivingId) {
        try {
            const data = {
                action: 'create-from-receiving',
                receiving_id: receivingId
            };

            const response = await fetchAPI('api/por.php', {
                method: 'POST',
                body: JSON.stringify(data)
            });

            if (response.success) {
                showToast('POR created successfully from receiving', 'success');
                $('#receivingSelectionModal').modal('hide');
                loadPORList();
                
                // Open the newly created POR for inspection
                if (response.por_id) {
                    setTimeout(() => viewPORDetails(response.por_id), 500);
                }
            } else {
                throw new Error(response.message || 'Failed to create POR');
            }
        } catch (error) {
            console.error('Error creating POR from receiving:', error);
            showToast('Error creating POR: ' + error.message, 'error');
        }
    }

    // Complete POR (mark as completed and update inventory)
    async function completePOR(porId) {
        const confirmed = await showConfirmDialog(
            'Complete Proof of Receiving',
            'This will mark the POR as completed and update inventory with the accepted quantities. This action cannot be undone. Continue?'
        );

        if (!confirmed) return;

        try {
            const data = {
                action: 'complete',
                por_id: porId
            };

            const response = await fetchAPI('api/por.php', {
                method: 'POST',
                body: JSON.stringify(data)
            });

            if (response.success) {
                showToast('POR completed and inventory updated successfully', 'success');
                $('#porDetailsModal').modal('hide');
                loadPORList();
            } else {
                throw new Error(response.message || 'Failed to complete POR');
            }
        } catch (error) {
            console.error('Error completing POR:', error);
            showToast('Error completing POR: ' + error.message, 'error');
        }
    }

    // Edit POR
    async function editPOR(porId) {
        try {
            const response = await fetchAPI(`api/por.php?action=details&id=${porId}`);

            if (response.success) {
                currentPOR = response.data;
                populateEditForm(currentPOR);
                $('#porDetailsModal').modal('hide');
                $('#editPORModal').modal('show');
            } else {
                throw new Error(response.message || 'Failed to load POR for editing');
            }
        } catch (error) {
            console.error('Error loading POR for editing:', error);
            showToast('Error loading POR: ' + error.message, 'error');
        }
    }

    // Populate edit form
    function populateEditForm(por) {
        $('#editPORId').val(por.id);
        $('#editInspectionStatus').val(por.inspection_status);
        $('#editInspectionNotes').val(por.inspection_notes);
        $('#editNotes').val(por.notes);

        // Populate items
        const itemsHtml = por.items.map((item, index) => `
            <div class="card mb-3" data-item-id="${item.id}">
                <div class="card-body">
                    <h6>${sanitizeHTML(item.product_name)} (SKU: ${sanitizeHTML(item.sku)})</h6>
                    <div class="row">
                        <div class="col-md-3">
                            <label class="form-label">Ordered</label>
                            <input type="number" class="form-control" value="${item.ordered_quantity}" readonly>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Received</label>
                            <input type="number" class="form-control" value="${item.received_quantity}" readonly>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Accepted *</label>
                            <input type="number" class="form-control item-accepted" name="items[${index}][accepted_quantity]" 
                                   value="${item.accepted_quantity}" min="0" max="${item.received_quantity}" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Rejected *</label>
                            <input type="number" class="form-control item-rejected" name="items[${index}][rejected_quantity]" 
                                   value="${item.rejected_quantity}" min="0" max="${item.received_quantity}" required>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-md-3">
                            <label class="form-label">Damaged</label>
                            <input type="number" class="form-control" name="items[${index}][damaged_quantity]" 
                                   value="${item.damaged_quantity || 0}" min="0">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Batch Number</label>
                            <input type="text" class="form-control" name="items[${index}][batch_number]" 
                                   value="${item.batch_number || ''}" maxlength="50">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Expiration Date</label>
                            <input type="date" class="form-control" name="items[${index}][expiration_date]" 
                                   value="${item.expiration_date || ''}">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Inspection Result</label>
                            <select class="form-select" name="items[${index}][inspection_result]">
                                <option value="Pending" ${item.inspection_result === 'Pending' ? 'selected' : ''}>Pending</option>
                                <option value="Passed" ${item.inspection_result === 'Passed' ? 'selected' : ''}>Passed</option>
                                <option value="Failed" ${item.inspection_result === 'Failed' ? 'selected' : ''}>Failed</option>
                                <option value="Conditional" ${item.inspection_result === 'Conditional' ? 'selected' : ''}>Conditional</option>
                            </select>
                        </div>
                    </div>
                    <input type="hidden" name="items[${index}][item_id]" value="${item.id}">
                </div>
            </div>
        `).join('');

        $('#editPORItemsContainer').html(itemsHtml);

        // Add validation listeners
        $('.item-accepted, .item-rejected').on('input', validateItemQuantities);
    }

    // Validate item quantities (accepted + rejected <= received)
    function validateItemQuantities(event) {
        const card = $(event.target).closest('.card');
        const received = parseFloat(card.find('input[readonly]').eq(1).val());
        const accepted = parseFloat(card.find('.item-accepted').val()) || 0;
        const rejected = parseFloat(card.find('.item-rejected').val()) || 0;

        if (accepted + rejected > received) {
            showToast('Accepted + Rejected cannot exceed Received quantity', 'warning');
            event.target.setCustomValidity('Sum exceeds received quantity');
        } else {
            event.target.setCustomValidity('');
        }
    }

    // Save POR changes
    async function savePORChanges(event) {
        event.preventDefault();

        const formData = new FormData(event.target);
        const porId = $('#editPORId').val();

        const data = {
            action: 'update',
            por_id: parseInt(porId),
            inspection_status: formData.get('inspection_status'),
            inspection_notes: formData.get('inspection_notes'),
            notes: formData.get('notes'),
            items: []
        };

        // Collect item updates
        $('#editPORItemsContainer .card').each(function(index) {
            const itemId = $(this).find('input[name*="[item_id]"]').val();
            const accepted = $(this).find('.item-accepted').val();
            const rejected = $(this).find('.item-rejected').val();
            const damaged = $(this).find('input[name*="[damaged_quantity]"]').val();
            const batch = $(this).find('input[name*="[batch_number]"]').val();
            const expiration = $(this).find('input[name*="[expiration_date]"]').val();
            const inspectionResult = $(this).find('select[name*="[inspection_result]"]').val();

            data.items.push({
                item_id: parseInt(itemId),
                accepted_quantity: parseFloat(accepted),
                rejected_quantity: parseFloat(rejected),
                damaged_quantity: parseFloat(damaged) || 0,
                batch_number: batch || null,
                expiration_date: expiration || null,
                inspection_result: inspectionResult
            });
        });

        try {
            const response = await fetchAPI('api/por.php', {
                method: 'POST',
                body: JSON.stringify(data)
            });

            if (response.success) {
                showToast('POR updated successfully', 'success');
                $('#editPORModal').modal('hide');
                loadPORList();
            } else {
                throw new Error(response.message || 'Failed to update POR');
            }
        } catch (error) {
            console.error('Error updating POR:', error);
            showToast('Error updating POR: ' + error.message, 'error');
        }
    }

    // Cancel POR
    async function cancelPOR(porId) {
        const confirmed = await showConfirmDialog(
            'Cancel Proof of Receiving',
            'Are you sure you want to cancel this POR? This action cannot be undone.'
        );

        if (!confirmed) return;

        try {
            const data = {
                action: 'cancel',
                por_id: porId
            };

            const response = await fetchAPI('api/por.php', {
                method: 'POST',
                body: JSON.stringify(data)
            });

            if (response.success) {
                showToast('POR cancelled successfully', 'success');
                $('#porDetailsModal').modal('hide');
                loadPORList();
            } else {
                throw new Error(response.message || 'Failed to cancel POR');
            }
        } catch (error) {
            console.error('Error cancelling POR:', error);
            showToast('Error cancelling POR: ' + error.message, 'error');
        }
    }

    // Print POR document
    function printPOR(porId) {
        window.open(`por-document.php?id=${porId}`, '_blank');
    }

    // Get status badge HTML
    function getStatusBadge(status) {
        const badges = {
            'Draft': 'secondary',
            'Completed': 'success',
            'Cancelled': 'danger'
        };
        const color = badges[status] || 'secondary';
        return `<span class="badge bg-${color}">${sanitizeHTML(status)}</span>`;
    }

    // Get inspection status badge HTML
    function getInspectionBadge(status) {
        const badges = {
            'Pending': 'warning',
            'In Progress': 'info',
            'Completed': 'success',
            'Failed': 'danger'
        };
        const color = badges[status] || 'secondary';
        return `<span class="badge bg-${color}">${sanitizeHTML(status)}</span>`;
    }

    // Get item inspection result badge HTML
    function getItemInspectionBadge(result) {
        const badges = {
            'Pending': 'secondary',
            'Passed': 'success',
            'Failed': 'danger',
            'Conditional': 'warning'
        };
        const color = badges[result] || 'secondary';
        return `<span class="badge bg-${color}">${sanitizeHTML(result)}</span>`;
    }

    // Helper: Show table loading state
    function showTableLoading(selector) {
        const elem = typeof selector === 'string' ? document.querySelector(selector) : selector;
        if (elem) {
            elem.innerHTML = `
                <tr>
                    <td colspan="10" class="text-center">
                        <div class="spinner-border spinner-border-sm me-2" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        Loading...
                    </td>
                </tr>
            `;
        }
    }

    // Helper: Debounce function
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Helper: Fetch API wrapper
    async function fetchAPI(url, options = {}) {
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        };

        const response = await fetch(url, { ...defaultOptions, ...options });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return await response.json();
    }

    // Helper: Format date
    function formatDate(dateString) {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
    }

    // Helper: Format date time
    function formatDateTime(dateString) {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        return date.toLocaleString('en-US', { 
            year: 'numeric', month: 'short', day: 'numeric',
            hour: '2-digit', minute: '2-digit'
        });
    }

    // Helper: Format currency
    function formatCurrency(value) {
        return parseFloat(value || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    // Helper: Sanitize HTML
    function sanitizeHTML(str) {
        if (!str) return '';
        const temp = document.createElement('div');
        temp.textContent = str;
        return temp.innerHTML;
    }

    // Helper: Show toast notification
    function showToast(message, type = 'info') {
        // Integrate with existing toast component
        if (window.Toast && typeof window.Toast.show === 'function') {
            window.Toast.show(message, type);
        } else {
            alert(message);
        }
    }

    // Helper: Show confirm dialog
    async function showConfirmDialog(title, message) {
        return new Promise((resolve) => {
            if (confirm(`${title}\n\n${message}`)) {
                resolve(true);
            } else {
                resolve(false);
            }
        });
    }

    // Public API
    return {
        init,
        loadPORList,
        viewPORDetails,
        createPORFromReceiving,
        completePOR,
        editPOR,
        cancelPOR,
        printPOR,
        savePORChanges
    };
})();

// Initialize on DOM ready - NO jQuery required
document.addEventListener('DOMContentLoaded', () => {
    const porModule = document.getElementById('porModule');
    if (porModule) {
        PORModule.init();
    }
});

// Make globally accessible for inline onclick handlers
window.PORModule = PORModule;

// Export render function for dynamic module loading
export async function renderPOR() {
    const appContent = document.getElementById('appContent');
    
    if (!appContent) {
        console.error('appContent element not found');
        return;
    }
    
    // Show loading state
    appContent.innerHTML = `
        <div style="padding: 40px; text-align: center;">
            <div style="display: inline-block; width: 40px; height: 40px; border: 4px solid #f3f3f3; border-top: 4px solid #E31C1C; border-radius: 50%; animation: spin 1s linear infinite;"></div>
            <p style="margin-top: 20px; color: #666;">Loading Proof of Receiving Module...</p>
        </div>
        <style>
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        </style>
    `;
    
    try {
        // Try to load the simple version first for testing
        console.log('🔍 Attempting to load POR module HTML...');
        const response = await fetch('modules/por/por-simple.html');
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const html = await response.text();
        console.log(`✅ HTML loaded: ${html.length} characters`);
        
        if (!html || html.trim().length === 0) {
            throw new Error('Module HTML is empty');
        }
        
        appContent.innerHTML = html;
        console.log('✅ HTML rendered to page');
        
        // Note: Full initialization skipped in simple mode
        console.log('ℹ️ Using simplified POR module for testing');
        console.log('ℹ️ Check the page - you should see the POR interface now');
        
    } catch (error) {
        console.error('❌ Error loading POR module:', error);
        appContent.innerHTML = `
            <div style="padding: 40px; max-width: 800px; margin: 0 auto;">
                <div style="background: #FEE2E2; border-left: 4px solid #EF4444; padding: 30px; border-radius: 8px;">
                    <h2 style="color: #EF4444; margin-top: 0;">❌ Module Load Error</h2>
                    <p style="color: #991B1B; font-size: 1.1rem; margin: 15px 0;">
                        <strong>Error:</strong> ${error.message}
                    </p>
                    
                    <div style="background: white; padding: 20px; border-radius: 6px; margin: 20px 0;">
                        <h3 style="margin-top: 0; color: #333;">Troubleshooting Steps:</h3>
                        <ol style="color: #666; line-height: 1.8;">
                            <li>Open browser console (Press F12) and check for errors</li>
                            <li>Verify file exists: <code>modules/por/por-simple.html</code></li>
                            <li>Check web server is running (XAMPP Apache)</li>
                            <li>Try the test page: <a href="test-por-module.html" target="_blank">test-por-module.html</a></li>
                            <li>Check file permissions</li>
                        </ol>
                    </div>
                    
                    <details style="margin-top: 20px;">
                        <summary style="cursor: pointer; color: #EF4444; font-weight: 600; padding: 10px 0;">
                            🔍 Technical Details
                        </summary>
                        <pre style="background: #FFF; padding: 15px; border-radius: 4px; overflow-x: auto; margin-top: 10px; font-size: 0.85rem; color: #333;">${error.stack || error.message}</pre>
                    </details>
                    
                    <div style="margin-top: 20px; display: flex; gap: 10px;">
                        <button onclick="location.reload()" style="padding: 12px 24px; background: #E31C1C; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600;">
                            🔄 Reload Page
                        </button>
                        <button onclick="window.open('test-por-module.html', '_blank')" style="padding: 12px 24px; background: #3B82F6; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600;">
                            🧪 Run Diagnostic Test
                        </button>
                    </div>
                </div>
            </div>
        `;
    }
}
