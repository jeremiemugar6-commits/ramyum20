import { toast } from '../../assets/js/components/toast.js';
import { modal } from '../../assets/js/components/modal.js';
import { DataTable } from '../../assets/js/components/table.js';
import { store } from '../../assets/js/store.js';

let currentLocations = [];
let locationsTable = null;

class LocationService {
    constructor() {
        this.baseUrl = 'api/locations.php';
    }

    async _handle(response) {
        let body;
        try {
            body = await response.json();
        } catch (e) {
            throw new Error('Unexpected server response.');
        }
        if (!response.ok || !body.success) {
            throw new Error(body.error || 'Request failed.');
        }
        return body;
    }

    async getAllLocations() {
        const res = await fetch(`${this.baseUrl}?action=all`);
        return this._handle(res);
    }

    async getLocation(id) {
        const res = await fetch(`${this.baseUrl}?action=location&id=${encodeURIComponent(id)}`);
        return this._handle(res);
    }

    async getLocationInventorySummary(locationId) {
        const res = await fetch(`${this.baseUrl}?action=inventory-summary&locationId=${encodeURIComponent(locationId)}`);
        return this._handle(res);
    }

    async getLocationTransfers(locationId) {
        const res = await fetch(`${this.baseUrl}?action=transfers&locationId=${encodeURIComponent(locationId)}`);
        return this._handle(res);
    }

    async getStatistics() {
        const res = await fetch(`${this.baseUrl}?action=statistics`);
        return this._handle(res);
    }

    async createLocation(locationData) {
        const res = await fetch(`${this.baseUrl}?action=create`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(locationData)
        });
        return this._handle(res);
    }

    async updateLocation(locationData) {
        const res = await fetch(`${this.baseUrl}?action=update`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(locationData)
        });
        return this._handle(res);
    }

    async deleteLocation(locationId) {
        const res = await fetch(`${this.baseUrl}?action=delete&id=${encodeURIComponent(locationId)}`, {
            method: 'DELETE'
        });
        return this._handle(res);
    }
}

const locationService = new LocationService();

// --- MAIN RENDER FUNCTION ---
export async function renderLocations() {
    const container = document.getElementById('appContent');
    const userRole = store.getState().role;
    const canManage = userRole === 'admin' || userRole === 'manager';

    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:26px; flex-wrap:wrap; gap:16px; background:var(--bg-card); padding:22px 26px; border-radius:12px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm);">
            <div>
                <h1 class="page-title">Locations & Branches</h1>
                <p class="page-subtitle">Manage storage locations and inventory distribution.</p>
            </div>
            ${canManage ? `<button id="addLocationBtn" style="background:var(--primary-red); color:white; padding:10px 20px; border:none; border-radius:8px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:8px;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
                Add Location
            </button>` : ''}
        </div>

        <!-- Statistics Cards -->
        <div class="grid-4" style="margin-bottom:24px;" id="statisticsContainer">
            <div style="display:flex; align-items:center; justify-content:center; padding:20px; color:var(--text-muted);">
                <div class="loading-spinner" style="margin-right:12px;"></div>
                <span>Loading statistics...</span>
            </div>
        </div>

        <!-- Locations Table -->
        <div class="card">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                <h3>All Locations</h3>
                <div style="display:flex; gap:12px;">
                    <input type="text" id="locationSearch" placeholder="Search locations..." style="padding:8px 12px; border:1px solid var(--border-color); border-radius:6px; background:var(--bg-white);">
                    <select id="typeFilter" style="padding:8px 12px; border:1px solid var(--border-color); border-radius:6px; background:var(--bg-white);">
                        <option value="">All Types</option>
                        <option value="Warehouse">Warehouse</option>
                        <option value="Branch">Branch</option>
                        <option value="Storage">Storage</option>
                    </select>
                </div>
            </div>
            <div id="locationsTableContainer"></div>
        </div>
    `;

    // Event Listeners
    document.getElementById('addLocationBtn')?.addEventListener('click', () => openLocationModal());
    document.getElementById('locationSearch')?.addEventListener('input', filterLocations);
    document.getElementById('typeFilter')?.addEventListener('change', filterLocations);

    // Load data
    await loadData();
}

// --- LOAD DATA ---
async function loadData() {
    try {
        const [locationsResult, statisticsResult] = await Promise.all([
            locationService.getAllLocations(),
            locationService.getStatistics()
        ]);

        currentLocations = locationsResult.data || [];
        renderStatistics(statisticsResult.data || {});
        renderLocationsTable(currentLocations);

    } catch (error) {
        console.error('Error loading locations data:', error);
        toast.show('Failed to load locations data.', 'error');
    }
}

// --- RENDER STATISTICS ---
function renderStatistics(stats) {
    const container = document.getElementById('statisticsContainer');
    
    container.innerHTML = `
        <div class="card" style="border-left: 4px solid #3B82F6;">
            <p style="color:var(--text-secondary); font-size:0.9rem;">Total Locations</p>
            <h3 style="font-size:1.8rem; color:var(--text-primary);">${stats.totalLocations || 0}</h3>
            <small style="color:var(--text-muted);">All locations</small>
        </div>
        <div class="card" style="border-left: 4px solid #10B981;">
            <p style="color:var(--text-secondary); font-size:0.9rem;">Active Locations</p>
            <h3 style="font-size:1.8rem; color:var(--text-primary);">${stats.activeLocations || 0}</h3>
            <small style="color:var(--text-muted);">Operational</small>
        </div>
        <div class="card" style="border-left: 4px solid #F59E0B;">
            <p style="color:var(--text-secondary); font-size:0.9rem;">Total Inventory Value</p>
            <h3 style="font-size:1.8rem; color:var(--text-primary);">₱${formatCurrency(stats.totalInventoryValue || 0)}</h3>
            <small style="color:var(--text-muted);">Across all locations</small>
        </div>
        <div class="card" style="border-left: 4px solid #8B5CF6;">
            <p style="color:var(--text-secondary); font-size:0.9rem;">Average per Location</p>
            <h3 style="font-size:1.8rem; color:var(--text-primary);">₱${formatCurrency(stats.averageInventoryPerLocation || 0)}</h3>
            <small style="color:var(--text-muted);">Inventory value</small>
        </div>
    `;
}

// --- RENDER LOCATIONS TABLE ---
function renderLocationsTable(locations) {
    const userRole = store.getState().role;
    const canManage = userRole === 'admin' || userRole === 'manager';
    const canDelete = userRole === 'admin';

    const columns = [
        { key: 'name', label: 'Location Name' },
        { key: 'code', label: 'Code' },
        { key: 'type', label: 'Type' },
        { key: 'manager', label: 'Manager' },
        { key: 'inventoryInfo', label: 'Inventory' },
        { key: 'status', label: 'Status' }
    ];

    const formattedData = locations.map(location => ({
        ...location,
        inventoryInfo: `${location.inventoryCount || 0} products${location.openTransfers ? ` · ${location.openTransfers} open transfer${location.openTransfers > 1 ? 's' : ''}` : ''}`,
        status: getLocationStatusBadge(location.status),
        rawStatus: location.status
    }));

    if (!locationsTable) {
        locationsTable = new DataTable('locationsTableContainer', columns, formattedData, {
            actions: canManage,
            onEdit: (rowData) => viewLocationDetails(rowData.id),
            editLabel: 'Details',
            onDelete: canManage ? (rowData) => openLocationModal(rowData) : null,
            deleteLabel: 'Edit',
            deleteVariant: 'secondary'
        });
    } else {
        locationsTable.updateData(formattedData);
    }
}
// --- FILTER LOCATIONS ---
function filterLocations() {
    const searchTerm = document.getElementById('locationSearch').value.toLowerCase();
    const typeFilter = document.getElementById('typeFilter').value;

    const filtered = currentLocations.filter(location => {
        const matchesSearch = !searchTerm || 
            location.name.toLowerCase().includes(searchTerm) ||
            location.code.toLowerCase().includes(searchTerm) ||
            (location.manager && location.manager.toLowerCase().includes(searchTerm));

        const matchesType = !typeFilter || location.type === typeFilter;

        return matchesSearch && matchesType;
    });

    renderLocationsTable(filtered);
}

// --- LOCATION STATUS BADGE ---
function getLocationStatusBadge(status) {
    const badges = {
        'Active': {
            class: 'status-active',
            text: 'Active',
            color: '#10B981',
            bg: '#D1FAE5'
        },
        'Inactive': {
            class: 'status-inactive',
            text: 'Inactive',
            color: '#6B7280',
            bg: '#F3F4F6'
        },
        'Maintenance': {
            class: 'status-maintenance',
            text: 'Maintenance',
            color: '#F59E0B',
            bg: '#FEF3C7'
        }
    };

    const badge = badges[status] || badges['Active'];
    return `<span class="status-badge ${badge.class}" style="background:${badge.bg}; color:${badge.color}; padding:4px 8px; border-radius:12px; font-size:0.75rem; font-weight:600;">${badge.text}</span>`;
}

// --- OPEN LOCATION MODAL ---
function openLocationModal(existingLocation = null) {
    const isEdit = !!existingLocation;
    const title = isEdit ? `Edit Location: ${existingLocation.name}` : 'Add New Location';

    const formHTML = `
        <form id="locationForm" style="display:grid; gap:16px;">
            <div style="display:grid; grid-template-columns:2fr 1fr; gap:16px;">
                <div>
                    <label style="display:block; font-weight:600; margin-bottom:6px;">Location Name *</label>
                    <input type="text" id="locationName" value="${isEdit ? existingLocation.name : ''}" class="form-input" required>
                </div>
                <div>
                    <label style="display:block; font-weight:600; margin-bottom:6px;">Code *</label>
                    <input type="text" id="locationCode" value="${isEdit ? existingLocation.code : ''}" class="form-input" required maxlength="10" style="text-transform:uppercase;">
                </div>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                <div>
                    <label style="display:block; font-weight:600; margin-bottom:6px;">Type *</label>
                    <select id="locationType" class="form-input" required>
                        <option value="">-- Select Type --</option>
                        <option value="Warehouse" ${isEdit && existingLocation.type === 'Warehouse' ? 'selected' : ''}>Warehouse</option>
                        <option value="Branch" ${isEdit && existingLocation.type === 'Branch' ? 'selected' : ''}>Branch</option>
                        <option value="Storage" ${isEdit && existingLocation.type === 'Storage' ? 'selected' : ''}>Storage</option>
                    </select>
                </div>
                <div>
                    <label style="display:block; font-weight:600; margin-bottom:6px;">Status</label>
                    <select id="locationStatus" class="form-input">
                        <option value="Active" ${isEdit && existingLocation.status === 'Active' ? 'selected' : ''}>Active</option>
                        <option value="Inactive" ${isEdit && existingLocation.status === 'Inactive' ? 'selected' : ''}>Inactive</option>
                        <option value="Maintenance" ${isEdit && existingLocation.status === 'Maintenance' ? 'selected' : ''}>Maintenance</option>
                    </select>
                </div>
            </div>

            <div>
                <label style="display:block; font-weight:600; margin-bottom:6px;">Address</label>
                <textarea id="locationAddress" class="form-input" rows="2">${isEdit ? existingLocation.address || '' : ''}</textarea>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px;">
                <div>
                    <label style="display:block; font-weight:600; margin-bottom:6px;">Manager</label>
                    <input type="text" id="locationManager" value="${isEdit ? existingLocation.manager || '' : ''}" class="form-input">
                </div>
                <div>
                    <label style="display:block; font-weight:600; margin-bottom:6px;">Phone</label>
                    <input type="tel" id="locationPhone" value="${isEdit ? existingLocation.phone || '' : ''}" class="form-input">
                </div>
                <div>
                    <label style="display:block; font-weight:600; margin-bottom:6px;">Email</label>
                    <input type="email" id="locationEmail" value="${isEdit ? existingLocation.email || '' : ''}" class="form-input">
                </div>
            </div>

            <div style="display:grid; grid-template-columns:1fr 2fr; gap:16px;">
                <div>
                    <label style="display:block; font-weight:600; margin-bottom:6px;">Capacity</label>
                    <input type="number" id="locationCapacity" value="${isEdit ? existingLocation.capacity || '' : '1000'}" class="form-input" min="0" step="100">
                    <small style="color:var(--text-muted); font-size:0.8rem;">Storage capacity (units)</small>
                </div>
                <div>
                    <label style="display:block; font-weight:600; margin-bottom:6px;">Description</label>
                    <textarea id="locationDescription" class="form-input" rows="2">${isEdit ? existingLocation.description || '' : ''}</textarea>
                </div>
            </div>
        </form>
    `;

    modal.open(title, formHTML, {
        confirmText: isEdit ? 'Update Location' : 'Add Location',
        onConfirm: async () => {
            await submitLocation(existingLocation);
        },
        width: 'large'
    });

    // Auto-generate code based on name if creating new location
    if (!isEdit) {
        document.getElementById('locationName').addEventListener('input', (e) => {
            const codeInput = document.getElementById('locationCode');
            if (!codeInput.value) {
                const name = e.target.value;
                const code = name.substring(0, 6).toUpperCase().replace(/[^A-Z0-9]/g, '');
                codeInput.value = code;
            }
        });
    }
}

// --- SUBMIT LOCATION ---
async function submitLocation(existingLocation = null) {
    const name = document.getElementById('locationName').value.trim();
    const code = document.getElementById('locationCode').value.trim().toUpperCase();
    const type = document.getElementById('locationType').value;
    const status = document.getElementById('locationStatus').value;
    const address = document.getElementById('locationAddress').value.trim();
    const manager = document.getElementById('locationManager').value.trim();
    const phone = document.getElementById('locationPhone').value.trim();
    const email = document.getElementById('locationEmail').value.trim();
    const capacity = parseFloat(document.getElementById('locationCapacity').value) || 1000;
    const description = document.getElementById('locationDescription').value.trim();

    // Validation
    if (!name) {
        toast.show('Location name is required', 'error');
        return;
    }

    if (!code) {
        toast.show('Location code is required', 'error');
        return;
    }

    if (code.length < 2 || code.length > 10) {
        toast.show('Location code must be between 2 and 10 characters', 'error');
        return;
    }

    if (!type) {
        toast.show('Location type is required', 'error');
        return;
    }

    if (email && !isValidEmail(email)) {
        toast.show('Invalid email address', 'error');
        return;
    }

    const locationData = {
        name,
        code,
        type,
        status,
        address,
        manager,
        phone,
        email,
        capacity,
        description
    };

    if (existingLocation) {
        locationData.id = existingLocation.id;
    }

    try {
        let result;
        if (existingLocation) {
            result = await locationService.updateLocation(locationData);
        } else {
            result = await locationService.createLocation(locationData);
        }

        toast.show(result.message || 'Location saved successfully!', 'success');
        modal.close();
        await loadData();

    } catch (error) {
        console.error('Error saving location:', error);
        toast.show(error.message || 'Failed to save location', 'error');
    }
}

// --- VIEW LOCATION DETAILS ---
async function viewLocationDetails(locationId) {
    try {
        const [locationResult, inventoryResult, transfersResult] = await Promise.all([
            locationService.getLocation(locationId),
            locationService.getLocationInventorySummary(locationId),
            locationService.getLocationTransfers(locationId).catch(() => ({ data: { outgoing: [], incoming: [], counts: {} } }))
        ]);

        const location = locationResult.data;
        const inventoryData = inventoryResult.data;
        const transferData = transfersResult.data || { outgoing: [], incoming: [], counts: {} };

        if (!location) {
            toast.show('Location not found', 'error');
            return;
        }

        const detailsHTML = `
            <div style="display:grid; gap:20px;">
                <!-- Location Info -->
                <div style="background:var(--bg-gray); padding:20px; border-radius:8px;">
                    <div style="display:flex; justify-content:space-between; align-items:start; margin-bottom:16px;">
                        <div>
                            <h3 style="color:var(--text-primary); margin-bottom:4px;">${location.name}</h3>
                            <p style="color:var(--text-secondary);">Code: ${location.code} | Type: ${location.type}</p>
                        </div>
                        ${getLocationStatusBadge(location.status)}
                    </div>

                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
                        <div>
                            ${location.manager ? `<p><strong>Manager:</strong> ${location.manager}</p>` : ''}
                            ${location.phone ? `<p><strong>Phone:</strong> ${location.phone}</p>` : ''}
                            ${location.email ? `<p><strong>Email:</strong> ${location.email}</p>` : ''}
                        </div>
                        <div>
                            <p><strong>Capacity:</strong> ${location.capacity ? formatNumber(location.capacity) + ' units' : 'Not specified'}</p>
                            <p><strong>Created:</strong> ${formatDate(location.createdAt)}</p>
                            ${location.updatedAt ? `<p><strong>Updated:</strong> ${formatDate(location.updatedAt)}</p>` : ''}
                        </div>
                    </div>

                    ${location.address ? `
                        <div style="margin-top:16px; padding-top:16px; border-top:1px solid var(--border-color);">
                            <p><strong>Address:</strong> ${location.address}</p>
                        </div>
                    ` : ''}

                    ${location.description ? `
                        <div style="margin-top:16px; padding-top:16px; border-top:1px solid var(--border-color);">
                            <p><strong>Description:</strong> ${location.description}</p>
                        </div>
                    ` : ''}
                </div>

                <!-- Inventory Summary -->
                <div>
                    <h4 style="margin-bottom:16px;">Inventory Summary</h4>
                    
                    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(150px, 1fr)); gap:12px; margin-bottom:20px;">
                        <div class="card" style="text-align:center; padding:16px;">
                            <h4 style="color:var(--primary-red);">${inventoryData.summary.totalProducts}</h4>
                            <p style="font-size:0.9rem; color:var(--text-secondary);">Products</p>
                        </div>
                        <div class="card" style="text-align:center; padding:16px;">
                            <h4 style="color:var(--primary-red);">${formatNumber(inventoryData.summary.totalQuantity)}</h4>
                            <p style="font-size:0.9rem; color:var(--text-secondary);">Total Qty</p>
                        </div>
                        <div class="card" style="text-align:center; padding:16px;">
                            <h4 style="color:var(--primary-red);">₱${formatCurrency(inventoryData.summary.totalValue)}</h4>
                            <p style="font-size:0.9rem; color:var(--text-secondary);">Total Value</p>
                        </div>
                        <div class="card" style="text-align:center; padding:16px;">
                            <h4 style="color:${inventoryData.summary.lowStockItems > 0 ? '#F59E0B' : '#10B981'};">${inventoryData.summary.lowStockItems}</h4>
                            <p style="font-size:0.9rem; color:var(--text-secondary);">Low Stock</p>
                        </div>
                    </div>

                    ${inventoryData.inventory.length > 0 ? `
                        <div style="border:1px solid var(--border-color); border-radius:8px; overflow:hidden; max-height:300px; overflow-y:auto;">
                            <div style="background:var(--bg-gray); padding:12px; border-bottom:1px solid var(--border-color); font-weight:600; display:grid; grid-template-columns:2fr 1fr 1fr 1fr; gap:12px; position:sticky; top:0;">
                                <div>Product</div>
                                <div>SKU</div>
                                <div>Quantity</div>
                                <div>Status</div>
                            </div>
                            ${inventoryData.inventory.slice(0, 20).map(item => `
                                <div style="padding:12px; border-bottom:1px solid var(--border-color); display:grid; grid-template-columns:2fr 1fr 1fr 1fr; gap:12px;">
                                    <div style="font-weight:500;">${item.productName}</div>
                                    <div style="color:var(--text-secondary);">${item.sku}</div>
                                    <div>${formatNumber(item.quantity)}</div>
                                    <div>${getStockStatusBadge(item.status)}</div>
                                </div>
                            `).join('')}
                            ${inventoryData.inventory.length > 20 ? `
                                <div style="padding:12px; text-align:center; color:var(--text-secondary); font-style:italic;">
                                    And ${inventoryData.inventory.length - 20} more items...
                                </div>
                            ` : ''}
                        </div>
                    ` : `
                        <div style="text-align:center; padding:40px; color:var(--text-muted);">
                            <p>No inventory items at this location</p>
                        </div>
                    `}
                </div>

                <!-- Stock Transfer Activity -->
                <div>
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; flex-wrap:wrap; gap:8px;">
                        <h4>Stock Transfer Activity</h4>
                        <button type="button" onclick="goToStockTransfer()" style="background:var(--primary-red); color:white; padding:8px 16px; border:none; border-radius:6px; cursor:pointer; font-weight:600; font-size:0.9rem;">
                            Go to Stock Transfer
                        </button>
                    </div>
                    <div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:12px; font-size:0.85rem;">
                        <span style="background:#FEF3C7; color:#92400E; padding:4px 10px; border-radius:12px; font-weight:600;">Pending: ${transferData.counts?.pending || 0}</span>
                        <span style="background:#D1FAE5; color:#065F46; padding:4px 10px; border-radius:12px; font-weight:600;">Approved: ${transferData.counts?.approved || 0}</span>
                        <span style="background:#DBEAFE; color:#1E40AF; padding:4px 10px; border-radius:12px; font-weight:600;">In Transit: ${transferData.counts?.inTransit || 0}</span>
                        <span style="background:#E5E7EB; color:#374151; padding:4px 10px; border-radius:12px; font-weight:600;">Completed: ${transferData.counts?.completed || 0}</span>
                    </div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                        ${renderTransferColumn('Outgoing (this location sends)', transferData.outgoing, 'destinationLocationName', '→')}
                        ${renderTransferColumn('Incoming (this location receives)', transferData.incoming, 'sourceLocationName', '←')}
                    </div>
                </div>
            </div>
        `;

        modal.open(`Location Details - ${location.name}`, detailsHTML, {
            confirmText: 'Close',
            onConfirm: () => modal.close(),
            width: 'large'
        });

    } catch (error) {
        console.error('Error loading location details:', error);
        toast.show('Failed to load location details', 'error');
    }
}

// --- TRANSFER ACTIVITY HELPERS ---
function escapeHtml(v) {
    return String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function renderTransferColumn(title, transfers, otherKey, arrow) {
    const rows = (transfers || []).slice(0, 5).map(t => `
        <div style="padding:10px 12px; border-bottom:1px solid var(--border-color); font-size:0.88rem;">
            <div style="display:flex; justify-content:space-between; gap:8px;">
                <strong>${escapeHtml(t.transferNumber)}</strong>
                <span style="color:var(--text-secondary);">${escapeHtml(t.status)}</span>
            </div>
            <div style="color:var(--text-secondary);">${arrow} ${escapeHtml(t[otherKey])} · ${t.totalItems || 0} units</div>
            ${t.products && t.products.length ? `<div style="color:var(--text-muted); font-size:0.8rem;">${t.products.map(escapeHtml).join(', ')}</div>` : ''}
        </div>
    `).join('');

    return `
        <div style="border:1px solid var(--border-color); border-radius:8px; overflow:hidden;">
            <div style="background:var(--bg-gray); padding:10px 12px; font-weight:600; font-size:0.9rem;">${title}</div>
            ${rows || '<div style="padding:16px; text-align:center; color:var(--text-muted); font-size:0.88rem;">No transfers</div>'}
        </div>
    `;
}

window.goToStockTransfer = function () {
    modal.close();
    document.querySelector('[data-page="stock-transfer"]')?.click();
};

// --- HELPER FUNCTIONS ---
function formatCurrency(amount) {
    return (amount || 0).toLocaleString('en-PH', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function formatNumber(number) {
    return (number || 0).toLocaleString();
}

function formatDate(dateString) {
    if (!dateString) return '—';
    return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function getStockStatusBadge(status) {
    const colors = {
        'In Stock': { bg: '#D1FAE5', color: '#065F46' },
        'Low Stock': { bg: '#FEF3C7', color: '#92400E' },
        'Out of Stock': { bg: '#FEE2E2', color: '#991B1B' }
    };
    const style = colors[status] || colors['In Stock'];
    return `<span style="background:${style.bg}; color:${style.color}; padding:4px 8px; border-radius:12px; font-size:0.75rem; font-weight:600;">${status}</span>`;
}

// Make functions global for onclick handlers
window.openLocationModal = openLocationModal;
window.viewLocationDetails = viewLocationDetails;