import { DataService } from '../../assets/js/utils/data-service.js';
import { toast } from '../../assets/js/components/toast.js';
import { store } from '../../assets/js/store.js';
import { formatCurrency } from '../../assets/js/utils/format.js';
import { BadgeHelper } from '../../assets/js/utils/badge-helper.js';

const dataService = new DataService();

// --- RENDER FUNCTION ---
export async function renderReports() {
    const container = document.getElementById('appContent');

    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:26px; flex-wrap:wrap; gap:16px; background:var(--bg-card); padding:22px 26px; border-radius:12px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm);">
            <div>
                <h1 class="page-title">Reports & Analytics</h1>
                <p class="page-subtitle">Generate operational reports for printing or export.</p>
            </div>
        </div>

        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap:20px;" id="reportCards">
            ${createReportCard('Purchase Order Workflow', 'Complete PO lifecycle from creation to receiving', 'workflow')}
            ${createReportCard('Audit Trail', 'All system activities and user actions', 'audit')}
            ${createReportCard('Stock Movements', 'Inventory changes and transaction history', 'movements')}
            ${createReportCard('Inventory Report', 'Current stock levels, values, and alerts', 'inventory')}
            ${createReportCard('Purchase Orders', 'History of all vendor orders and costs', 'purchase-orders')}
            ${createReportCard('Receiving Log', 'Inspection logs and received items', 'receiving')}
            ${createReportCard('Supplier Analysis', 'Vendor performance and contact information', 'suppliers')}
        </div>
        
        <!-- Dynamic Report View Area -->
        <div id="reportViewArea" style="margin-top:24px;"></div>
    `;

    // Attach Event Listeners
    document.querySelectorAll('.generate-report-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const type = e.target.dataset.type;
            generateReport(type);
        });
    });
}

// --- HELPER: REPORT CARD HTML ---
function createReportCard(title, description, type) {
    const iconMap = {
        'workflow': '<path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>',
        'audit': '<path d="M9 12l2 2 4-4M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>',
        'movements': '<path d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4"/>',
        'inventory': '<path d="M4 7h16M4 12h16M4 17h16"/>',
        'purchase-orders': '<path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>',
        'receiving': '<path d="M5 13h14M5 13a2 2 0 01-2-2V5a2 2 0 012-2h14a2 2 0 012 2v6a2 2 0 01-2 2M5 13v4a2 2 0 002 2h10a2 2 0 002-2v-4"/>',
        'suppliers': '<path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/><path d="M3.3 7l8.7 5 8.7-5M12 22V12"/>'
    };

    return `
        <div class="card" style="display:flex; flex-direction:column; justify-content:space-between; min-height:180px;">
            <div>
                <div style="margin-bottom:12px;">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#B91C1C" stroke-width="2">${iconMap[type]}</svg>
                </div>
                <h3 style="font-size:1.1rem; margin-bottom:4px;">${title}</h3>
                <p style="font-size:0.9rem; color:var(--text-secondary);">${description}</p>
            </div>
            <button class="generate-report-btn" data-type="${type}" style="margin-top:16px; background:#1F2937; color:white; padding:8px 16px; border:none; border-radius:6px; cursor:pointer; font-weight:500; width:fit-content;">Generate Report</button>
        </div>
    `;
}

// --- MAIN REPORT GENERATOR ---
async function generateReport(type) {
    const viewArea = document.getElementById('reportViewArea');
    viewArea.innerHTML = `<div style="text-align:center; padding:40px; color:var(--text-secondary);">Generating report...</div>`;

    let html = '';

    switch (type) {
        case 'workflow':
            html = await generateWorkflowReport();
            break;
        case 'audit':
            html = await generateAuditReport();
            break;
        case 'movements':
            html = await generateMovementsReport();
            break;
        case 'inventory':
            html = await generateInventoryReport();
            break;
        case 'purchase-orders':
            html = await generatePOReport();
            break;
        case 'receiving':
            html = await generateReceivingReport();
            break;
        case 'suppliers':
            html = await generateSupplierReport();
            break;
        default:
            html = `<p>Invalid report type.</p>`;
    }

    viewArea.innerHTML = html;
    
    // Attach Export/Print Listeners to the newly generated report
    document.getElementById('printReportBtn')?.addEventListener('click', () => window.print());
    document.getElementById('exportCsvBtn')?.addEventListener('click', () => exportToCSV(type));
}

// --- INDIVIDUAL REPORT GENERATORS ---

async function generateWorkflowReport() {
    const pos = await dataService.findAll('purchase_orders');
    const receivings = await dataService.findAll('receivings');
    const movements = await dataService.findAll('inventory_movements');

    // Process workflow data
    const workflowData = pos.map(po => {
        const poReceivings = receivings.filter(r => r.poId === po.id || r.poNumber === po.poNumber);
        const poMovements = movements.filter(m => m.referencePO === po.poNumber);
        
        return {
            po,
            receivings: poReceivings,
            movements: poMovements,
            receivingProgress: po.receivedItems || 0,
            totalItems: po.totalItems || 0,
            completionRate: po.totalItems ? ((po.receivedItems || 0) / po.totalItems * 100).toFixed(1) : 0
        };
    });

    const sortedWorkflow = workflowData.sort((a, b) => new Date(b.po.orderDate) - new Date(a.po.orderDate));

    const rows = sortedWorkflow.map(w => {
        const statusBadge = BadgeHelper.getPOStatusBadge(w.po.status);
        const progressBadge = BadgeHelper.getReceivingProgressBadge(w.receivingProgress, w.totalItems);
        
        return `
            <tr style="border-bottom:1px solid #E5E7EB;">
                <td style="padding:12px; text-align:left;">
                    <div style="font-weight:600; margin-bottom:2px;">${w.po.poNumber}</div>
                    <div style="font-size:0.8rem; color:var(--text-secondary);">${new Date(w.po.orderDate).toLocaleDateString()}</div>
                </td>
                <td style="padding:12px; text-align:left;">
                    <div style="font-weight:500; margin-bottom:2px;">${w.po.supplier}</div>
                    <div style="font-size:0.8rem; color:var(--text-secondary);">${w.po.items?.length || 0} item types</div>
                </td>
                <td style="padding:12px; text-align:center;">${statusBadge}</td>
                <td style="padding:12px; text-align:center;">${progressBadge}</td>
                <td style="padding:12px; text-align:center;">
                    <div style="font-weight:600;">${w.receivings.length}</div>
                    <div style="font-size:0.8rem; color:var(--text-secondary);">receipts</div>
                </td>
                <td style="padding:12px; text-align:center;">
                    <div style="font-weight:600;">${w.movements.length}</div>
                    <div style="font-size:0.8rem; color:var(--text-secondary);">movements</div>
                </td>
                <td style="padding:12px; text-align:right; font-weight:600;">₱${formatCurrency(w.po.total || 0)}</td>
            </tr>
        `;
    }).join('');

    const totalPOs = pos.length;
    const completedPOs = pos.filter(po => po.status === 'Fully Received').length;
    const totalValue = pos.reduce((sum, po) => sum + (po.total || 0), 0);
    const avgCompletionRate = workflowData.reduce((sum, w) => sum + parseFloat(w.completionRate), 0) / workflowData.length || 0;

    return `
        <div class="card" style="padding:24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; flex-wrap:wrap;">
                <div>
                    <h2 style="font-size:1.5rem;">Purchase Order Workflow Report</h2>
                    <p style="color:var(--text-secondary);">Complete lifecycle tracking from creation to receiving</p>
                </div>
                <div style="display:flex; gap:8px;">
                    <button id="exportCsvBtn" style="padding:8px 12px; background:#F3F4F6; border:1px solid #E5E7EB; border-radius:6px; cursor:pointer;">Export CSV</button>
                    <button id="printReportBtn" style="padding:8px 12px; background:#B91C1C; color:white; border:none; border-radius:6px; cursor:pointer;">Print / PDF</button>
                </div>
            </div>

            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap:16px; margin-bottom:24px; background:#F9FAFB; padding:20px; border-radius:8px;">
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Total POs</div>
                    <div style="font-size:1.8rem; font-weight:700; color:#1F2937;">${totalPOs}</div>
                </div>
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Completed</div>
                    <div style="font-size:1.8rem; font-weight:700; color:#10B981;">${completedPOs}</div>
                </div>
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Total Value</div>
                    <div style="font-size:1.4rem; font-weight:700; color:#E53935;">₱${formatCurrency(totalValue)}</div>
                </div>
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Avg Completion</div>
                    <div style="font-size:1.8rem; font-weight:700; color:#F59E0B;">${avgCompletionRate.toFixed(1)}%</div>
                </div>
            </div>

            <table style="width:100%; border-collapse:collapse; margin-top:16px;">
                <thead>
                    <tr style="background:#1F2937; color:white;">
                        <th style="padding:12px; text-align:left;">Purchase Order</th>
                        <th style="padding:12px; text-align:left;">Supplier</th>
                        <th style="padding:12px; text-align:center;">Status</th>
                        <th style="padding:12px; text-align:center;">Progress</th>
                        <th style="padding:12px; text-align:center;">Receivings</th>
                        <th style="padding:12px; text-align:center;">Movements</th>
                        <th style="padding:12px; text-align:right;">Value</th>
                    </tr>
                </thead>
                <tbody>${rows}</tbody>
            </table>
        </div>
    `;
}

async function generateAuditReport() {
    const movements = await dataService.findAll('inventory_movements');
    const pos = await dataService.findAll('purchase_orders');
    const receivings = await dataService.findAll('receivings');

    // Create audit trail entries
    const auditEntries = [];

    // PO activities
    pos.forEach(po => {
        auditEntries.push({
            timestamp: new Date(po.orderDate),
            type: 'Purchase Order',
            action: 'Created',
            description: `PO ${po.poNumber} created for ${po.supplier}`,
            user: po.createdBy || 'System',
            reference: po.poNumber,
            value: po.total || 0
        });

        if (po.status === 'Approved') {
            auditEntries.push({
                timestamp: new Date(po.orderDate),
                type: 'Purchase Order',
                action: 'Approved',
                description: `PO ${po.poNumber} approved`,
                user: 'System',
                reference: po.poNumber,
                value: po.total || 0
            });
        }
    });

    // Receiving activities
    receivings.forEach(gr => {
        auditEntries.push({
            timestamp: new Date(gr.receivedDate),
            type: 'Receiving',
            action: 'Items Received',
            description: `Received ${gr.totalReceived || 0} items for ${gr.poNumber}`,
            user: gr.receivedBy || 'System',
            reference: gr.receivingNumber,
            value: gr.totalValue || 0
        });
    });

    // Inventory movements
    movements.forEach(mov => {
        auditEntries.push({
            timestamp: new Date(mov.date),
            type: 'Inventory',
            action: mov.type,
            description: `${mov.productName}: ${mov.type} of ${mov.quantity} units`,
            user: mov.user || 'System',
            reference: mov.referenceId || mov.reason,
            value: (mov.quantity || 0) * (mov.unitCost || 0)
        });
    });

    // Sort by timestamp (newest first)
    auditEntries.sort((a, b) => b.timestamp - a.timestamp);

    const rows = auditEntries.map(entry => {
        const typeColor = {
            'Purchase Order': '#3B82F6',
            'Receiving': '#10B981',
            'Inventory': '#F59E0B'
        }[entry.type] || '#6B7280';

        return `
            <tr style="border-bottom:1px solid #E5E7EB;">
                <td style="padding:10px 12px; text-align:left;">
                    <div style="font-weight:500; margin-bottom:2px;">${entry.timestamp.toLocaleDateString()}</div>
                    <div style="font-size:0.8rem; color:var(--text-secondary);">${entry.timestamp.toLocaleTimeString()}</div>
                </td>
                <td style="padding:10px 12px; text-align:center;">
                    <span style="background:${typeColor}; color:white; padding:4px 8px; border-radius:12px; font-size:0.8rem; font-weight:500;">
                        ${entry.type}
                    </span>
                </td>
                <td style="padding:10px 12px; text-align:left;">
                    <div style="font-weight:500; margin-bottom:2px;">${entry.action}</div>
                    <div style="font-size:0.85rem; color:var(--text-secondary);">${entry.description}</div>
                </td>
                <td style="padding:10px 12px; text-align:left; font-weight:500;">${entry.user}</td>
                <td style="padding:10px 12px; text-align:left; font-family:monospace; font-size:0.9rem;">${entry.reference}</td>
                <td style="padding:10px 12px; text-align:right; font-weight:600;">₱${formatCurrency(entry.value)}</td>
            </tr>
        `;
    }).join('');

    const totalEntries = auditEntries.length;
    const todayEntries = auditEntries.filter(e => e.timestamp.toDateString() === new Date().toDateString()).length;
    const totalValue = auditEntries.reduce((sum, e) => sum + e.value, 0);

    return `
        <div class="card" style="padding:24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; flex-wrap:wrap;">
                <div>
                    <h2 style="font-size:1.5rem;">System Audit Trail</h2>
                    <p style="color:var(--text-secondary);">Complete activity log and user actions</p>
                </div>
                <div style="display:flex; gap:8px;">
                    <button id="exportCsvBtn" style="padding:8px 12px; background:#F3F4F6; border:1px solid #E5E7EB; border-radius:6px; cursor:pointer;">Export CSV</button>
                    <button id="printReportBtn" style="padding:8px 12px; background:#B91C1C; color:white; border:none; border-radius:6px; cursor:pointer;">Print / PDF</button>
                </div>
            </div>

            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap:16px; margin-bottom:24px; background:#F9FAFB; padding:20px; border-radius:8px;">
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Total Activities</div>
                    <div style="font-size:1.8rem; font-weight:700; color:#1F2937;">${totalEntries}</div>
                </div>
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Today</div>
                    <div style="font-size:1.8rem; font-weight:700; color:#10B981;">${todayEntries}</div>
                </div>
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Total Value</div>
                    <div style="font-size:1.4rem; font-weight:700; color:#E53935;">₱${formatCurrency(totalValue)}</div>
                </div>
            </div>

            <div style="max-height:600px; overflow-y:auto; border:1px solid #E5E7EB; border-radius:8px;">
                <table style="width:100%; border-collapse:collapse;">
                    <thead style="position:sticky; top:0; z-index:10;">
                        <tr style="background:#1F2937; color:white;">
                            <th style="padding:12px; text-align:left;">Timestamp</th>
                            <th style="padding:12px; text-align:center;">Type</th>
                            <th style="padding:12px; text-align:left;">Activity</th>
                            <th style="padding:12px; text-align:left;">User</th>
                            <th style="padding:12px; text-align:left;">Reference</th>
                            <th style="padding:12px; text-align:right;">Value</th>
                        </tr>
                    </thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>
        </div>
    `;
}

async function generateMovementsReport() {
    const movements = await dataService.findAll('inventory_movements');
    const products = await dataService.findAll('products');
    
    const sortedMovements = movements.sort((a, b) => new Date(b.date) - new Date(a.date));

    const rows = sortedMovements.map(mov => {
        const typeColors = {
            'Stock In': { bg: '#D1FAE5', color: '#065F46' },
            'Stock Out': { bg: '#FEE2E2', color: '#991B1B' },
            'Adjustment': { bg: '#FEF3C7', color: '#92400E' }
        };
        
        const typeStyle = typeColors[mov.type] || { bg: '#F3F4F6', color: '#4B5563' };
        const changePrefix = mov.change > 0 ? '+' : '';
        
        return `
            <tr style="border-bottom:1px solid #E5E7EB;">
                <td style="padding:10px 12px; text-align:left;">
                    <div style="font-weight:500; margin-bottom:2px;">${new Date(mov.date).toLocaleDateString()}</div>
                    <div style="font-size:0.8rem; color:var(--text-secondary);">${new Date(mov.date).toLocaleTimeString()}</div>
                </td>
                <td style="padding:10px 12px; text-align:left;">
                    <div style="font-weight:500; margin-bottom:2px;">${mov.productName}</div>
                    <div style="font-size:0.8rem; color:var(--text-secondary);">${mov.sku || 'N/A'}</div>
                </td>
                <td style="padding:10px 12px; text-align:center;">
                    <span style="background:${typeStyle.bg}; color:${typeStyle.color}; padding:4px 8px; border-radius:12px; font-size:0.8rem; font-weight:500;">
                        ${mov.type}
                    </span>
                </td>
                <td style="padding:10px 12px; text-align:center; font-weight:600;">
                    <span style="color:${mov.change > 0 ? '#10B981' : '#EF4444'};">
                        ${changePrefix}${mov.change || mov.quantity || 0}
                    </span>
                </td>
                <td style="padding:10px 12px; text-align:center;">
                    <div>${mov.previousBalance || 0} → ${mov.newBalance || 0}</div>
                </td>
                <td style="padding:10px 12px; text-align:left;">
                    <div style="font-weight:500; margin-bottom:2px;">${mov.reason || 'N/A'}</div>
                    <div style="font-size:0.8rem; color:var(--text-secondary);">${mov.referenceId || mov.referencePO || 'N/A'}</div>
                </td>
                <td style="padding:10px 12px; text-align:left; font-weight:500;">${mov.user || 'System'}</td>
                <td style="padding:10px 12px; text-align:right; font-weight:600;">₱${formatCurrency((mov.quantity || 0) * (mov.unitCost || 0))}</td>
            </tr>
        `;
    }).join('');

    const totalMovements = movements.length;
    const stockInCount = movements.filter(m => m.type === 'Stock In').length;
    const stockOutCount = movements.filter(m => m.type === 'Stock Out').length;
    const adjustmentCount = movements.filter(m => m.type === 'Adjustment').length;
    const totalValue = movements.reduce((sum, m) => sum + ((m.quantity || 0) * (m.unitCost || 0)), 0);

    return `
        <div class="card" style="padding:24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; flex-wrap:wrap;">
                <div>
                    <h2 style="font-size:1.5rem;">Stock Movement Report</h2>
                    <p style="color:var(--text-secondary);">Detailed inventory transaction history</p>
                </div>
                <div style="display:flex; gap:8px;">
                    <button id="exportCsvBtn" style="padding:8px 12px; background:#F3F4F6; border:1px solid #E5E7EB; border-radius:6px; cursor:pointer;">Export CSV</button>
                    <button id="printReportBtn" style="padding:8px 12px; background:#B91C1C; color:white; border:none; border-radius:6px; cursor:pointer;">Print / PDF</button>
                </div>
            </div>

            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap:16px; margin-bottom:24px; background:#F9FAFB; padding:20px; border-radius:8px;">
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Total Movements</div>
                    <div style="font-size:1.8rem; font-weight:700; color:#1F2937;">${totalMovements}</div>
                </div>
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Stock In</div>
                    <div style="font-size:1.8rem; font-weight:700; color:#10B981;">${stockInCount}</div>
                </div>
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Stock Out</div>
                    <div style="font-size:1.8rem; font-weight:700; color:#EF4444;">${stockOutCount}</div>
                </div>
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Adjustments</div>
                    <div style="font-size:1.8rem; font-weight:700; color:#F59E0B;">${adjustmentCount}</div>
                </div>
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Total Value</div>
                    <div style="font-size:1.4rem; font-weight:700; color:#E53935;">₱${formatCurrency(totalValue)}</div>
                </div>
            </div>

            <div style="max-height:600px; overflow-y:auto; border:1px solid #E5E7EB; border-radius:8px;">
                <table style="width:100%; border-collapse:collapse;">
                    <thead style="position:sticky; top:0; z-index:10;">
                        <tr style="background:#1F2937; color:white;">
                            <th style="padding:12px; text-align:left;">Date</th>
                            <th style="padding:12px; text-align:left;">Product</th>
                            <th style="padding:12px; text-align:center;">Type</th>
                            <th style="padding:12px; text-align:center;">Change</th>
                            <th style="padding:12px; text-align:center;">Balance</th>
                            <th style="padding:12px; text-align:left;">Reason</th>
                            <th style="padding:12px; text-align:left;">User</th>
                            <th style="padding:12px; text-align:right;">Value</th>
                        </tr>
                    </thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>
        </div>
    `;
}

// --- INDIVIDUAL REPORT GENERATORS ---

async function generateInventoryReport() {
    const products = await dataService.findAll('products');
    let totalValue = 0;
    let lowStock = 0;
    let outOfStock = 0;

    const rows = products.map(p => {
        // Calculate total stock across all locations
        let totalQty = 0;
        if (typeof p.stock === 'object') {
            totalQty = Object.values(p.stock).reduce((a, b) => a + b, 0);
        } else {
            totalQty = parseInt(p.stock || 0);
        }
        
        const value = totalQty * parseFloat(p.price || 0);
        totalValue += value;

        if (totalQty === 0) outOfStock++;
        else if (totalQty <= (p.reorderLevel || 10)) lowStock++;

        return `<tr style="border-bottom:1px solid #E5E7EB;">
            <td style="padding:8px 12px; text-align:left;">${p.sku || '-'}</td>
            <td style="padding:8px 12px; text-align:left;">${p.name}</td>
            <td style="padding:8px 12px; text-align:center;">${totalQty}</td>
            <td style="padding:8px 12px; text-align:center;">${p.reorderLevel || 10}</td>
            <td style="padding:8px 12px; text-align:right;">₱${formatCurrency(p.price)}</td>
            <td style="padding:8px 12px; text-align:right; font-weight:600;">₱${formatCurrency(value)}</td>
            <td style="padding:8px 12px; text-align:center;">${p.expirationDate ? new Date(p.expirationDate).toLocaleDateString() : '-'}</td>
        </tr>`;
    }).join('');

    return `
        <div class="card" style="padding:24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; flex-wrap:wrap;">
                <div>
                    <h2 style="font-size:1.5rem;">Inventory Summary Report</h2>
                    <p style="color:var(--text-secondary);">Generated on ${new Date().toLocaleString()}</p>
                </div>
                <div style="display:flex; gap:8px;">
                    <button id="exportCsvBtn" style="padding:8px 12px; background:#F3F4F6; border:1px solid #E5E7EB; border-radius:6px; cursor:pointer;">Export CSV</button>
                    <button id="printReportBtn" style="padding:8px 12px; background:#B91C1C; color:white; border:none; border-radius:6px; cursor:pointer;">Print / PDF</button>
                </div>
            </div>

            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap:16px; margin-bottom:24px; background:#F9FAFB; padding:16px; border-radius:8px;">
                <div><span style="color:var(--text-secondary);">Total Items</span><br><strong style="font-size:1.2rem;">${products.length}</strong></div>
                <div><span style="color:var(--text-secondary);">Total Value</span><br><strong style="font-size:1.2rem; color:#10B981;">₱${formatCurrency(totalValue)}</strong></div>
                <div><span style="color:var(--text-secondary);">Low Stock</span><br><strong style="font-size:1.2rem; color:#F59E0B;">${lowStock}</strong></div>
                <div><span style="color:var(--text-secondary);">Out of Stock</span><br><strong style="font-size:1.2rem; color:#EF4444;">${outOfStock}</strong></div>
            </div>

            <table style="width:100%; border-collapse:collapse; margin-top:16px;">
                <thead>
                    <tr style="background:#1F2937; color:white;">
                        <th style="padding:12px; text-align:left;">SKU</th>
                        <th style="padding:12px; text-align:left;">Product</th>
                        <th style="padding:12px; text-align:center;">Stock</th>
                        <th style="padding:12px; text-align:center;">Reorder</th>
                        <th style="padding:12px; text-align:right;">Price</th>
                        <th style="padding:12px; text-align:right;">Total Value</th>
                        <th style="padding:12px; text-align:center;">Expiration</th>
                    </tr>
                </thead>
                <tbody>${rows}</tbody>
            </table>
        </div>
    `;
}

async function generatePOReport() {
    const pos = await dataService.findAll('purchase_orders');
    const sorted = pos.sort((a, b) => new Date(b.orderDate) - new Date(a.orderDate));

    const rows = sorted.map(po => `
        <tr style="border-bottom:1px solid #E5E7EB;">
            <td style="padding:8px 12px; text-align:left; font-weight:500;">${po.poNumber}</td>
            <td style="padding:8px 12px; text-align:left;">${po.supplier}</td>
            <td style="padding:8px 12px; text-align:center;">${new Date(po.orderDate).toLocaleDateString()}</td>
            <td style="padding:8px 12px; text-align:center;">${po.items ? po.items.reduce((sum, i) => sum + i.quantity, 0) : 0}</td>
            <td style="padding:8px 12px; text-align:right; font-weight:600;">₱${formatCurrency(po.total)}</td>
            <td style="padding:8px 12px; text-align:center;"><span style="background:${po.status === 'Received' ? '#D1FAE5' : '#FEF3C7'}; color:${po.status === 'Received' ? '#065F46' : '#92400E'}; padding:2px 8px; border-radius:999px; font-size:0.8rem;">${po.status}</span></td>
        </tr>
    `).join('');

    return `
        <div class="card" style="padding:24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
                <div>
                    <h2 style="font-size:1.5rem;">Purchase Order History</h2>
                    <p style="color:var(--text-secondary);">Total Orders: ${sorted.length}</p>
                </div>
                <div style="display:flex; gap:8px;">
                    <button id="exportCsvBtn" style="padding:8px 12px; background:#F3F4F6; border:1px solid #E5E7EB; border-radius:6px; cursor:pointer;">Export CSV</button>
                    <button id="printReportBtn" style="padding:8px 12px; background:#B91C1C; color:white; border:none; border-radius:6px; cursor:pointer;">Print / PDF</button>
                </div>
            </div>
            <table style="width:100%; border-collapse:collapse; margin-top:16px;">
                <thead>
                    <tr style="background:#1F2937; color:white;">
                        <th style="padding:12px; text-align:left;">PO #</th>
                        <th style="padding:12px; text-align:left;">Supplier</th>
                        <th style="padding:12px; text-align:center;">Date</th>
                        <th style="padding:12px; text-align:center;">Items</th>
                        <th style="padding:12px; text-align:right;">Total</th>
                        <th style="padding:12px; text-align:center;">Status</th>
                    </tr>
                </thead>
                <tbody>${rows}</tbody>
            </table>
        </div>
    `;
}

async function generateReceivingReport() {
    const receivings = await dataService.findAll('receivings');
    const sorted = receivings.sort((a, b) => new Date(b.receivedDate) - new Date(a.receivedDate));

    const rows = sorted.map(r => {
        const statusBadge = BadgeHelper.getReceivingStatusBadge(r.status);
        
        return `
            <tr style="border-bottom:1px solid #E5E7EB;">
                <td style="padding:10px 12px; text-align:left;">
                    <div style="font-weight:600; margin-bottom:2px;">${r.receivingNumber}</div>
                    <div style="font-size:0.8rem; color:var(--text-secondary);">${new Date(r.receivedDate).toLocaleDateString()}</div>
                </td>
                <td style="padding:10px 12px; text-align:left;">
                    <div style="font-weight:500; margin-bottom:2px;">${r.poNumber}</div>
                    <div style="font-size:0.8rem; color:var(--text-secondary);">${r.supplier}</div>
                </td>
                <td style="padding:10px 12px; text-align:center; font-weight:600; color:#10B981;">${r.totalReceived || 0}</td>
                <td style="padding:10px 12px; text-align:right; font-weight:600;">₱${formatCurrency(r.totalValue || 0)}</td>
                <td style="padding:10px 12px; text-align:center;">${statusBadge}</td>
                <td style="padding:10px 12px; text-align:left; font-weight:500;">${r.receivedBy}</td>
                <td style="padding:10px 12px; text-align:left;">
                    <div style="font-size:0.85rem;">${r.items?.length || 0} item types</div>
                </td>
            </tr>
        `;
    }).join('');

    const totalReceivings = receivings.length;
    const totalItems = receivings.reduce((sum, r) => sum + (r.totalReceived || 0), 0);
    const totalValue = receivings.reduce((sum, r) => sum + (r.totalValue || 0), 0);
    const completedReceivings = receivings.filter(r => r.status === 'Completed').length;

    return `
        <div class="card" style="padding:24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px; flex-wrap:wrap;">
                <div>
                    <h2 style="font-size:1.5rem;">Receiving & Inspection Log</h2>
                    <p style="color:var(--text-secondary);">Goods receipt and quality control records</p>
                </div>
                <div style="display:flex; gap:8px;">
                    <button id="exportCsvBtn" style="padding:8px 12px; background:#F3F4F6; border:1px solid #E5E7EB; border-radius:6px; cursor:pointer;">Export CSV</button>
                    <button id="printReportBtn" style="padding:8px 12px; background:#B91C1C; color:white; border:none; border-radius:6px; cursor:pointer;">Print / PDF</button>
                </div>
            </div>

            <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap:16px; margin-bottom:24px; background:#F9FAFB; padding:20px; border-radius:8px;">
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Total Receivings</div>
                    <div style="font-size:1.8rem; font-weight:700; color:#1F2937;">${totalReceivings}</div>
                </div>
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Items Received</div>
                    <div style="font-size:1.8rem; font-weight:700; color:#10B981;">${totalItems}</div>
                </div>
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Total Value</div>
                    <div style="font-size:1.4rem; font-weight:700; color:#E53935;">₱${formatCurrency(totalValue)}</div>
                </div>
                <div class="metric-card">
                    <div style="color:var(--text-secondary); font-size:0.9rem;">Completed</div>
                    <div style="font-size:1.8rem; font-weight:700; color:#10B981;">${completedReceivings}</div>
                </div>
            </div>

            <table style="width:100%; border-collapse:collapse; margin-top:16px;">
                <thead>
                    <tr style="background:#1F2937; color:white;">
                        <th style="padding:12px; text-align:left;">Receiving #</th>
                        <th style="padding:12px; text-align:left;">Purchase Order</th>
                        <th style="padding:12px; text-align:center;">Items</th>
                        <th style="padding:12px; text-align:right;">Value</th>
                        <th style="padding:12px; text-align:center;">Status</th>
                        <th style="padding:12px; text-align:left;">Inspector</th>
                        <th style="padding:12px; text-align:left;">Details</th>
                    </tr>
                </thead>
                <tbody>${rows}</tbody>
            </table>
        </div>
    `;
}

async function generateTransferReport() {
    // Placeholder for future stock transfer functionality
    return `
        <div class="card" style="padding:24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
                <div>
                    <h2 style="font-size:1.5rem;">Stock Transfer History</h2>
                    <p style="color:var(--text-secondary);">Multi-location movement tracking (Coming Soon)</p>
                </div>
            </div>
            <div style="text-align:center; padding:60px; color:var(--text-secondary);">
                <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-bottom:16px; opacity:0.5;">
                    <path d="M3 6h18M3 12h18M3 18h18"/><path d="M6 3v3M18 3v3M6 21v-3M18 21v-3"/>
                </svg>
                <h3 style="margin-bottom:8px;">Stock Transfer Module</h3>
                <p>This feature will be available in future releases for multi-location inventory management.</p>
            </div>
        </div>
    `;
}

async function generateSupplierReport() {
    const suppliers = await dataService.findAll('suppliers');

    const rows = suppliers.map(s => `
        <tr style="border-bottom:1px solid #E5E7EB;">
            <td style="padding:8px 12px; text-align:left; font-weight:500;">${s.company}</td>
            <td style="padding:8px 12px; text-align:left;">${s.contactPerson}</td>
            <td style="padding:8px 12px; text-align:left;"><a href="mailto:${s.email}" style="color:#B91C1C;">${s.email}</a></td>
            <td style="padding:8px 12px; text-align:center;">${s.phone}</td>
            <td style="padding:8px 12px; text-align:center;">${s.productCount || 0}</td>
        </tr>
    `).join('');

    return `
        <div class="card" style="padding:24px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
                <div>
                    <h2 style="font-size:1.5rem;">Supplier Directory</h2>
                    <p style="color:var(--text-secondary);">Active vendors and contact details.</p>
                </div>
                <div style="display:flex; gap:8px;">
                    <button id="exportCsvBtn" style="padding:8px 12px; background:#F3F4F6; border:1px solid #E5E7EB; border-radius:6px; cursor:pointer;">Export CSV</button>
                    <button id="printReportBtn" style="padding:8px 12px; background:#B91C1C; color:white; border:none; border-radius:6px; cursor:pointer;">Print / PDF</button>
                </div>
            </div>
            <table style="width:100%; border-collapse:collapse; margin-top:16px;">
                <thead>
                    <tr style="background:#1F2937; color:white;">
                        <th style="padding:12px; text-align:left;">Company</th>
                        <th style="padding:12px; text-align:left;">Contact Person</th>
                        <th style="padding:12px; text-align:left;">Email</th>
                        <th style="padding:12px; text-align:center;">Phone</th>
                        <th style="padding:12px; text-align:center;">Products</th>
                    </tr>
                </thead>
                <tbody>${rows}</tbody>
            </table>
        </div>
    `;
}

// --- EXPORT UTILITY ---
async function exportToCSV(type) {
    let data = [];
    // Each column maps a display header to the real field name (and an optional formatter/computed value)
    let columns = [];
    let fileName = '';

    switch(type) {
        case 'workflow':
            const pos = await dataService.findAll('purchase_orders');
            const receivings = await dataService.findAll('receivings');
            data = pos.map(po => ({
                ...po,
                receivingCount: receivings.filter(r => r.poId === po.id || r.poNumber === po.poNumber).length,
                completionRate: po.totalItems ? ((po.receivedItems || 0) / po.totalItems * 100).toFixed(1) : 0
            }));
            columns = [
                { header: 'PO Number', key: 'poNumber' },
                { header: 'Supplier', key: 'supplier' },
                { header: 'Date', value: po => new Date(po.orderDate).toLocaleDateString() },
                { header: 'Status', key: 'status' },
                { header: 'Total Items', key: 'totalItems' },
                { header: 'Received Items', key: 'receivedItems' },
                { header: 'Completion %', key: 'completionRate' },
                { header: 'Receivings', key: 'receivingCount' },
                { header: 'Total Value', value: po => parseFloat(po.total || 0).toFixed(2) }
            ];
            fileName = 'workflow_report';
            break;
        case 'audit':
            // Combine audit data from multiple sources
            const allPos = await dataService.findAll('purchase_orders');
            const allReceivings = await dataService.findAll('receivings');
            const allMovements = await dataService.findAll('inventory_movements');
            
            data = [];
            allPos.forEach(po => {
                data.push({
                    date: new Date(po.orderDate).toLocaleDateString(),
                    type: 'Purchase Order',
                    action: 'Created',
                    description: `PO ${po.poNumber} created`,
                    user: po.createdBy || 'System',
                    reference: po.poNumber,
                    value: po.total || 0
                });
            });
            allReceivings.forEach(gr => {
                data.push({
                    date: new Date(gr.receivedDate).toLocaleDateString(),
                    type: 'Receiving',
                    action: 'Items Received',
                    description: `${gr.totalReceived || 0} items received`,
                    user: gr.receivedBy || 'System',
                    reference: gr.receivingNumber,
                    value: gr.totalValue || 0
                });
            });
            allMovements.forEach(mov => {
                data.push({
                    date: new Date(mov.date).toLocaleDateString(),
                    type: 'Inventory',
                    action: mov.type,
                    description: `${mov.productName}: ${mov.quantity} units`,
                    user: mov.user || 'System',
                    reference: mov.referenceId || mov.reason,
                    value: (mov.quantity || 0) * (mov.unitCost || 0)
                });
            });
            
            columns = [
                { header: 'Date', key: 'date' },
                { header: 'Type', key: 'type' },
                { header: 'Action', key: 'action' },
                { header: 'Description', key: 'description' },
                { header: 'User', key: 'user' },
                { header: 'Reference', key: 'reference' },
                { header: 'Value', key: 'value' }
            ];
            fileName = 'audit_trail';
            break;
        case 'movements':
            data = await dataService.findAll('inventory_movements');
            columns = [
                { header: 'Date', value: m => new Date(m.date).toLocaleDateString() },
                { header: 'Product', key: 'productName' },
                { header: 'SKU', key: 'sku' },
                { header: 'Type', key: 'type' },
                { header: 'Quantity', key: 'quantity' },
                { header: 'Previous Balance', key: 'previousBalance' },
                { header: 'New Balance', key: 'newBalance' },
                { header: 'Change', key: 'change' },
                { header: 'Reason', key: 'reason' },
                { header: 'Reference', value: m => m.referenceId || m.referencePO || '' },
                { header: 'User', key: 'user' },
                { header: 'Unit Cost', key: 'unitCost' }
            ];
            fileName = 'stock_movements';
            break;
        case 'inventory':
            data = await dataService.findAll('products');
            columns = [
                { header: 'SKU', key: 'sku' },
                { header: 'Name', key: 'name' },
                { header: 'Stock', value: p => typeof p.stock === 'object' ? Object.values(p.stock).reduce((a, b) => a + b, 0) : parseInt(p.stock || 0) },
                { header: 'Price', value: p => parseFloat(p.price || 0).toFixed(2) },
                { header: 'Value', value: p => {
                    const qty = typeof p.stock === 'object' ? Object.values(p.stock).reduce((a, b) => a + b, 0) : parseInt(p.stock || 0);
                    return (qty * parseFloat(p.price || 0)).toFixed(2);
                } },
                { header: 'Expiration Date', value: p => p.expirationDate || '' }
            ];
            fileName = 'inventory_report';
            break;
        case 'purchase-orders':
            data = await dataService.findAll('purchase_orders');
            columns = [
                { header: 'PO #', key: 'poNumber' },
                { header: 'Supplier', key: 'supplier' },
                { header: 'Date', value: po => new Date(po.orderDate).toLocaleDateString() },
                { header: 'Total', value: po => parseFloat(po.total || 0).toFixed(2) },
                { header: 'Status', key: 'status' }
            ];
            fileName = 'po_history';
            break;
        case 'receiving':
            data = await dataService.findAll('receivings');
            columns = [
                { header: 'Receiving #', key: 'receivingNumber' },
                { header: 'Date', value: r => new Date(r.receivedDate).toLocaleDateString() },
                { header: 'PO #', key: 'poNumber' },
                { header: 'Supplier', key: 'supplier' },
                { header: 'Items Received', key: 'totalReceived' },
                { header: 'Total Value', value: r => parseFloat(r.totalValue || 0).toFixed(2) },
                { header: 'Status', key: 'status' },
                { header: 'Inspector', key: 'receivedBy' }
            ];
            fileName = 'receiving_log';
            break;
        case 'stock-transfer':
            data = await dataService.findAll('stock_transfers');
            columns = [
                { header: 'Date', value: t => new Date(t.date).toLocaleDateString() },
                { header: 'Product', key: 'productName' },
                { header: 'From', key: 'fromLocation' },
                { header: 'To', key: 'toLocation' },
                { header: 'Qty', key: 'quantity' },
                { header: 'Status', key: 'status' }
            ];
            fileName = 'transfer_history';
            break;
        case 'suppliers':
            data = await dataService.findAll('suppliers');
            columns = [
                { header: 'Company', key: 'company' },
                { header: 'Contact', key: 'contactPerson' },
                { header: 'Email', key: 'email' },
                { header: 'Phone', key: 'phone' },
                { header: 'Products', key: 'productCount' }
            ];
            fileName = 'supplier_directory';
            break;
        default:
            toast.show('Export format not supported.', 'error');
            return;
    }

    // Generate CSV String
    let csvContent = columns.map(c => c.header).join(',') + '\n';

    data.forEach(row => {
        const values = columns.map(col => {
            let val = col.value ? col.value(row) : (row[col.key] !== undefined ? row[col.key] : '');
            if (typeof val === 'string' && val.includes(',')) {
                val = `"${val}"`; // Escape commas
            }
            return val;
        });
        csvContent += values.join(',') + '\n';
    });

    // Trigger Download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${fileName}_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.show('CSV file downloaded successfully!', 'success');
}