import { DataService } from '../../assets/js/utils/data-service.js';
import { Validator } from '../../assets/js/utils/validator.js';
import { toast } from '../../assets/js/components/toast.js';
import { modal } from '../../assets/js/components/modal.js';
import { DataTable } from '../../assets/js/components/table.js';
import { store } from '../../assets/js/store.js';

const dataService = new DataService();

// --- RENDER FUNCTION ---
export async function renderSuppliers() {
    const container = document.getElementById('appContent');
    const userRole = store.getState().role;
    const canManage = userRole === 'admin' || userRole === 'manager';

    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:26px; flex-wrap:wrap; gap:16px; background:var(--bg-card); padding:22px 26px; border-radius:12px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm);">
            <div>
                <h1 class="page-title">Supplier Management</h1>
                <p class="page-subtitle">Manage your vendors, track contacts, and supply history.</p>
            </div>
            ${canManage ? `<button id="addSupplierBtn" style="background:var(--primary-red); color:white; padding:10px 20px; border:none; border-radius:8px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:8px;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
                Add Supplier
            </button>` : ''}
        </div>

        <!-- Filters -->
        <div style="display:flex; gap:16px; margin-bottom:20px; flex-wrap:wrap;">
            <input type="text" id="supplierSearch" placeholder="Search by name, contact, or email..." style="flex:1; min-width:200px; padding:10px 14px; border:1px solid var(--border-color); border-radius:8px; background:var(--bg-white); color:var(--text-primary);">
        </div>

        <!-- Table Container -->
        <div id="supplierTableContainer"></div>
    `;

    // --- LOAD DATA ---
    await loadSuppliers();

    // --- EVENT LISTENERS ---
    document.getElementById('addSupplierBtn')?.addEventListener('click', () => openSupplierForm());
    document.getElementById('supplierSearch')?.addEventListener('input', filterSupplierData);
}

// --- STATE & DATA ---
let currentSuppliers = [];
let supplierTable = null;

async function loadSuppliers() {
    try {
        const allSuppliers = await dataService.findAll('suppliers');
        // Filter out archived suppliers by default
        currentSuppliers = allSuppliers.filter(s => !s.archived);
        renderSupplierTable();
    } catch (error) {
        toast.show('Failed to load suppliers.', 'error');
        console.error(error);
    }
}

// --- RENDER TABLE ---
function renderSupplierTable(filteredData = null) {
    const dataToRender = filteredData || currentSuppliers;
    const container = document.getElementById('supplierTableContainer');
    const userRole = store.getState().role;
    const canDelete = userRole === 'admin';

    const columns = [
        { key: 'company', label: 'Company Name' },
        { key: 'contactPerson', label: 'Contact Person' },
        { key: 'email', label: 'Email' },
        { key: 'phone', label: 'Phone' },
        { key: 'productCount', label: 'Products Supplied' }
    ];

    // Map data for the table view
    const formattedData = dataToRender.map(s => ({
        ...s,
        emailRaw: s.email, // Keep original email for editing
        email: `<a href="mailto:${s.email}" style="color:var(--primary-red); text-decoration:none;">${s.email}</a>`,
        productCount: `<span style="background:var(--bg-gray); padding:4px 10px; border-radius:999px; font-size:0.8rem;">${s.productCount || 0}</span>`
    }));

    if (!supplierTable) {
        supplierTable = new DataTable('supplierTableContainer', columns, formattedData, {
            actions: true,
            onEdit: (rowData) => openSupplierForm(rowData),
            onDelete: canDelete ? (rowData) => confirmArchive(rowData) : null,
            deleteLabel: 'Archive'
        });
    } else {
        supplierTable.updateData(formattedData);
    }
}

// --- FILTER DATA ---
function filterSupplierData() {
    const searchTerm = document.getElementById('supplierSearch').value.toLowerCase();

    const filtered = currentSuppliers.filter(s => {
        return s.company.toLowerCase().includes(searchTerm) || 
               s.contactPerson.toLowerCase().includes(searchTerm) ||
               s.email.toLowerCase().includes(searchTerm);
    });

    renderSupplierTable(filtered);
}

// --- CRUD: SUPPLIER FORM ---
async function openSupplierForm(existingSupplier = null) {
    const isEdit = !!existingSupplier;
    const title = isEdit ? `Edit Supplier: ${existingSupplier.company}` : 'Add New Supplier';

    const formHTML = `
        <form id="supplierForm" style="display:grid; gap:16px;">
            <div>
                <label style="display:block; font-weight:500; margin-bottom:4px;">Company Name *</label>
                <input type="text" id="s_company" value="${isEdit ? existingSupplier.company : ''}" class="form-input" placeholder="e.g. Seoul Trading Co." required>
            </div>

            <div>
                <label style="display:block; font-weight:500; margin-bottom:4px;">Contact Person *</label>
                <input type="text" id="s_contact" value="${isEdit ? existingSupplier.contactPerson : ''}" class="form-input" placeholder="e.g. John Doe" required>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                <div>
                <label style="display:block; font-weight:500; margin-bottom:4px;">Email Address *</label>
                <input type="email" id="s_email" value="${isEdit ? (existingSupplier.emailRaw || existingSupplier.email) : ''}" class="form-input" placeholder="john@example.com" required>
                </div>
                <div>
                <label style="display:block; font-weight:500; margin-bottom:4px;">Phone Number *</label>
                <input type="text" id="s_phone" value="${isEdit ? existingSupplier.phone : ''}" class="form-input" placeholder="+1 123 456 7890" required>
                </div>
            </div>

            <div>
                <label style="display:block; font-weight:500; margin-bottom:4px;">Address</label>
                <textarea id="s_address" rows="2" class="form-input" style="resize:vertical;">${isEdit ? existingSupplier.address || '' : ''}</textarea>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                <div>
                    <label style="display:block; font-weight:500; margin-bottom:4px;">Tax ID / VAT</label>
                    <input type="text" id="s_tax" value="${isEdit ? existingSupplier.taxId || '' : ''}" class="form-input" placeholder="e.g. 12-3456789">
                </div>
                <div>
                    <label style="display:block; font-weight:500; margin-bottom:4px;">Payment Terms</label>
                    <select id="s_terms" class="form-input">
                        <option value="Net 15" ${isEdit && existingSupplier.paymentTerms === 'Net 15' ? 'selected' : ''}>Net 15</option>
                        <option value="Net 30" ${isEdit && existingSupplier.paymentTerms === 'Net 30' ? 'selected' : ''}>Net 30</option>
                        <option value="Net 60" ${isEdit && existingSupplier.paymentTerms === 'Net 60' ? 'selected' : ''}>Net 60</option>
                        <option value="COD" ${isEdit && existingSupplier.paymentTerms === 'COD' ? 'selected' : ''}>Cash on Delivery</option>
                        <option value="Prepaid" ${isEdit && existingSupplier.paymentTerms === 'Prepaid' ? 'selected' : ''}>Prepaid</option>
                    </select>
                </div>
            </div>
            
            <div>
                <label style="display:block; font-weight:500; margin-bottom:4px;">Notes</label>
                <textarea id="s_notes" rows="2" class="form-input" style="resize:vertical;">${isEdit ? existingSupplier.notes || '' : ''}</textarea>
            </div>
        </form>
    `;

    modal.open(title, formHTML, {
        confirmText: isEdit ? 'Update Supplier' : 'Add Supplier',
        onConfirm: async () => {
            // Collect Data
            const formData = {
                company: document.getElementById('s_company').value.trim(),
                contactPerson: document.getElementById('s_contact').value.trim(),
                email: document.getElementById('s_email').value.trim(),
                phone: document.getElementById('s_phone').value.trim(),
                address: document.getElementById('s_address').value.trim(),
                taxId: document.getElementById('s_tax').value.trim(),
                paymentTerms: document.getElementById('s_terms').value,
                notes: document.getElementById('s_notes').value.trim(),
                productCount: isEdit ? existingSupplier.productCount || 0 : 0
            };

            // Validate
            const rules = { company: 'required', contactPerson: 'required', email: 'required|email', phone: 'required' };
            const validation = Validator.validateForm(formData, rules);
            
            if (!validation.isValid) {
                toast.show(Object.values(validation.errors)[0], 'error');
                return;
            }

            try {
                if (isEdit) {
                    await dataService.update('suppliers', existingSupplier.id, formData);
                    toast.show('Supplier updated successfully!', 'success');
                } else {
                    await dataService.create('suppliers', formData);
                    toast.show('Supplier added successfully!', 'success');
                }
                modal.close();
                await loadSuppliers(); // Refresh table
            } catch (error) {
                toast.show('Failed to save supplier.', 'error');
            }
        }
    });
}

// --- CRUD: ARCHIVE CONFIRMATION ---
async function confirmArchive(rowData) {
    modal.open(
        `Archive ${rowData.company}?`, 
        `<p style="color:var(--text-secondary);">Are you sure you want to archive <strong>${rowData.company}</strong>? Archived suppliers will be hidden from the active list but can be restored later.</p>`,
        {
            confirmText: 'Archive Supplier',
            onConfirm: async () => {
                try {
                    // Mark supplier as archived instead of deleting
                    await dataService.update('suppliers', rowData.id, { 
                        archived: true,
                        archivedAt: new Date().toISOString(),
                        archivedBy: store.getState().user?.name || 'System'
                    });
                    toast.show('Supplier archived successfully.', 'info');
                    modal.close();
                    await loadSuppliers();
                } catch (error) {
                    toast.show('Failed to archive supplier.', 'error');
                }
            }
        }
    );
}