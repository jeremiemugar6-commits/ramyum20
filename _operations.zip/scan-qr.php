<?php
require_once __DIR__ . '/includes/auth.php';
$currentUser = require_login_page();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scan Stock Transfer QR - RAM-YUM</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        .scan-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 30px;
        }
        .scan-header {
            text-align: center;
            margin-bottom: 30px;
            background: var(--bg-card);
            padding: 30px;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
        }
        .scan-header h1 {
            color: var(--primary-red);
            margin-bottom: 8px;
        }
        .scanner-wrapper {
            background: var(--bg-card);
            padding: 30px;
            border-radius: 12px;
            box-shadow: var(--shadow-md);
            margin-bottom: 20px;
        }
        #qr-reader {
            border: 2px solid var(--border-color);
            border-radius: 8px;
            overflow: hidden;
            max-width: 500px;
            margin: 0 auto 20px;
        }
        .manual-entry {
            margin-top: 30px;
            padding: 20px;
            background: var(--bg-gray);
            border-radius: 8px;
        }
        .manual-entry input {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            margin-bottom: 12px;
        }
        .btn-scan {
            width: 100%;
            padding: 14px;
            background: var(--primary-red);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
        }
        .btn-scan:hover {
            background: var(--primary-orange);
        }
        .btn-back {
            display: inline-block;
            padding: 10px 20px;
            background: var(--bg-gray);
            color: var(--text-primary);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            text-decoration: none;
            margin-bottom: 20px;
        }
        .scanner-status {
            text-align: center;
            padding: 16px;
            margin: 16px 0;
            border-radius: 8px;
        }
        .status-info {
            background: #DBEAFE;
            color: #1E40AF;
        }
        .status-success {
            background: #D1FAE5;
            color: #065F46;
        }
        .status-error {
            background: #FEE2E2;
            color: #991B1B;
        }
    </style>
</head>
<body>
    <div class="scan-container">
        <a href="dashboard.php" class="btn-back">← Back to Dashboard</a>

        <div class="scan-header">
            <h1>📱 Scan Stock Transfer QR</h1>
            <p>Use your camera to scan the QR code on the stock transfer document</p>
        </div>

        <div class="scanner-wrapper">
            <div id="scanner-status" class="scanner-status status-info" style="display:none;">
                Initializing scanner...
            </div>

            <div id="qr-reader"></div>

            <div class="manual-entry">
                <h3 style="margin-bottom:12px;">Or Enter Token Manually</h3>
                <p style="color:var(--text-secondary); font-size:0.9rem; margin-bottom:16px;">
                    If the scanner doesn't work, enter the QR token from the transfer document
                </p>
                <input type="text" id="manual-token" placeholder="POD-XXXXXXXXXXXXX" />
                <button class="btn-scan" onclick="verifyManualToken()">Verify Token</button>
            </div>
        </div>
    </div>

    <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
    <script type="module">
        import { toast } from './assets/js/components/toast.js';

        const statusDiv = document.getElementById('scanner-status');
        let html5QrCode;

        // Initialize QR Scanner
        async function initScanner() {
            try {
                statusDiv.style.display = 'block';
                statusDiv.className = 'scanner-status status-info';
                statusDiv.textContent = 'Initializing camera...';

                html5QrCode = new Html5Qrcode("qr-reader");

                const config = {
                    fps: 10,
                    qrbox: { width: 250, height: 250 }
                };

                await html5QrCode.start(
                    { facingMode: "environment" },
                    config,
                    onScanSuccess,
                    onScanError
                );

                statusDiv.className = 'scanner-status status-success';
                statusDiv.textContent = '✓ Scanner ready. Point camera at QR code.';

            } catch (err) {
                console.error('Scanner initialization error:', err);
                statusDiv.className = 'scanner-status status-error';
                statusDiv.innerHTML = `
                    <strong>Camera access denied or unavailable</strong><br>
                    <span style="font-size:0.9rem;">Please use manual token entry below or grant camera permissions</span>
                `;
            }
        }

        function onScanSuccess(decodedText) {
            console.log('QR Code detected:', decodedText);
            
            // Stop scanner
            if (html5QrCode) {
                html5QrCode.stop().then(() => {
                    statusDiv.className = 'scanner-status status-info';
                    statusDiv.textContent = 'QR Code detected! Verifying...';
                }).catch(err => console.error('Error stopping scanner:', err));
            }

            // Extract token from URL or use direct token
            let token = decodedText;
            if (decodedText.includes('scan-pod.php?token=')) {
                const urlParams = new URL(decodedText).searchParams;
                token = urlParams.get('token');
            } else if (decodedText.includes('token=')) {
                token = decodedText.split('token=')[1].split('&')[0];
            }

            // Redirect to POD verification page
            window.location.href = `scan-pod.php?token=${encodeURIComponent(token)}`;
        }

        function onScanError(errorMessage) {
            // Ignore frequent scan errors (camera frame processing)
            // Only log actual errors
            if (!errorMessage.includes('NotFoundException')) {
                console.warn('Scan error:', errorMessage);
            }
        }

        // Manual token verification
        window.verifyManualToken = function() {
            const token = document.getElementById('manual-token').value.trim();
            
            if (!token) {
                toast.show('Please enter a token', 'error');
                return;
            }

            if (!token.startsWith('POD-')) {
                toast.show('Invalid token format. Token should start with POD-', 'error');
                return;
            }

            statusDiv.className = 'scanner-status status-info';
            statusDiv.textContent = 'Verifying token...';
            
            // Redirect to POD verification
            window.location.href = `scan-pod.php?token=${encodeURIComponent(token)}`;
        };

        // Allow Enter key for manual entry
        document.getElementById('manual-token').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                verifyManualToken();
            }
        });

        // Initialize scanner on page load
        initScanner();

        // Cleanup on page unload
        window.addEventListener('beforeunload', () => {
            if (html5QrCode) {
                html5QrCode.stop().catch(err => console.error(err));
            }
        });
    </script>
</body>
</html>
