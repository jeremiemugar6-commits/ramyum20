<?php
/**
 * Debug Transfer Not Found Issue
 * Traces transfer ID usage throughout the system
 */

require_once 'includes/auth.php';

$db = getDB();

echo "=================================================\n";
echo "  DEBUG: TRANSFER NOT FOUND ISSUE\n";
echo "=================================================\n\n";

// STEP 1: Check database structure
echo "STEP 1: Database Structure\n";
echo "-------------------------------------------------\n";

$stmt = $db->query("DESCRIBE stock_transfers");
$columns = $stmt->fetchAll();
echo "stock_transfers table columns:\n";
foreach ($columns as $col) {
    echo "  - " . $col['Field'] . " (" . $col['Type'] . ") " . ($col['Key'] === 'PRI' ? '[PRIMARY KEY]' : '') . "\n";
}

echo "\n";

// STEP 2: Check existing transfers
echo "STEP 2: Existing Transfers\n";
echo "-------------------------------------------------\n";

$stmt = $db->query("SELECT id, data, created_at FROM stock_transfers ORDER BY created_at DESC LIMIT 5");
$transfers = $stmt->fetchAll();

if (count($transfers) > 0) {
    echo "Found " . count($transfers) . " transfer(s):\n\n";
    
    foreach ($transfers as $row) {
        $data = json_decode($row['data'], true);
        echo "Database ID: " . $row['id'] . "\n";
        echo "  Transfer Number: " . ($data['transferNumber'] ?? 'N/A') . "\n";
        echo "  Data ID field: " . ($data['id'] ?? 'N/A') . "\n";
        echo "  Status: " . ($data['status'] ?? 'N/A') . "\n";
        echo "  Created: " . $row['created_at'] . "\n";
        
        // Check if database ID matches data ID
        if (isset($data['id']) && $row['id'] !== $data['id']) {
            echo "  ⚠ WARNING: Database ID != Data ID\n";
        }
        
        echo "---\n";
    }
} else {
    echo "No transfers found in database.\n";
}

echo "\n";

// STEP 3: Check API endpoint parameter usage
echo "STEP 3: API Parameter Usage\n";
echo "-------------------------------------------------\n";

$apiFile = 'api/stock-transfers.php';
if (file_exists($apiFile)) {
    $content = file_get_contents($apiFile);
    
    // Check for different parameter patterns
    $patterns = [
        'transfer_id' => preg_match_all('/\$_GET\[\'transfer_id\'\]|\$_GET\["transfer_id"\]/', $content, $matches),
        'transferId' => preg_match_all('/\$_GET\[\'transferId\'\]|\$_GET\["transferId"\]/', $content, $matches),
        'id' => preg_match_all('/\$_GET\[\'id\'\]|\$_GET\["id"\]/', $content, $matches),
        '$input[\'transferId\']' => preg_match_all('/\$input\[\'transferId\'\]/', $content, $matches),
        '$input[\'id\']' => preg_match_all('/\$input\[\'id\'\]/', $content, $matches),
    ];
    
    echo "Parameter usage in API:\n";
    foreach ($patterns as $pattern => $count) {
        if ($count > 0) {
            echo "  ✓ $pattern: used $count time(s)\n";
        }
    }
    
    // Check SQL queries
    if (preg_match_all('/WHERE id = \?/', $content, $matches)) {
        echo "  ✓ SQL 'WHERE id = ?' found: " . count($matches[0]) . " time(s)\n";
    }
    
    if (preg_match_all('/WHERE transfer_id = \?/', $content, $matches)) {
        echo "  ✓ SQL 'WHERE transfer_id = ?' found: " . count($matches[0]) . " time(s)\n";
    }
}

echo "\n";

// STEP 4: Check JavaScript parameter usage
echo "STEP 4: JavaScript Parameter Usage\n";
echo "-------------------------------------------------\n";

$jsFile = 'modules/stock-transfer/stock-transfer.js';
if (file_exists($jsFile)) {
    $content = file_get_contents($jsFile);
    
    // Check fetch patterns
    $patterns = [
        'transferId' => preg_match_all('/transferId/', $content, $matches),
        'transfer_id' => preg_match_all('/transfer_id/', $content, $matches),
        'id' => preg_match_all('/\bid\b/', $content, $matches),
    ];
    
    echo "Variable usage in JavaScript:\n";
    foreach ($patterns as $pattern => $count) {
        if ($count > 0) {
            echo "  ✓ $pattern: used $count time(s)\n";
        }
    }
    
    // Check API calls
    if (preg_match_all('/stock-transfers\.php\?action=([^&\'"\s]+)/', $content, $matches)) {
        echo "\nAPI actions called:\n";
        $actions = array_unique($matches[1]);
        foreach ($actions as $action) {
            echo "  - $action\n";
        }
    }
}

echo "\n";

// STEP 5: Simulate transfer lookup
echo "STEP 5: Test Transfer Lookup\n";
echo "-------------------------------------------------\n";

if (count($transfers) > 0) {
    $testTransfer = $transfers[0];
    $testId = $testTransfer['id'];
    $testData = json_decode($testTransfer['data'], true);
    $dataId = $testData['id'] ?? null;
    
    echo "Testing with transfer: $testId\n\n";
    
    // Test 1: Lookup by database ID
    echo "Test 1: SELECT WHERE id = '$testId'\n";
    $stmt = $db->prepare("SELECT id, data FROM stock_transfers WHERE id = ?");
    $stmt->execute([$testId]);
    $result = $stmt->fetch();
    echo "  Result: " . ($result ? "✓ FOUND" : "✗ NOT FOUND") . "\n\n";
    
    // Test 2: Lookup by data.id if different
    if ($dataId && $dataId !== $testId) {
        echo "Test 2: SELECT WHERE id = '$dataId' (from data.id)\n";
        $stmt = $db->prepare("SELECT id, data FROM stock_transfers WHERE id = ?");
        $stmt->execute([$dataId]);
        $result = $stmt->fetch();
        echo "  Result: " . ($result ? "✓ FOUND" : "✗ NOT FOUND") . "\n\n";
    }
    
    // Test 3: Lookup by transfer number
    if (isset($testData['transferNumber'])) {
        $transferNumber = $testData['transferNumber'];
        echo "Test 3: SELECT WHERE JSON_EXTRACT transferNumber = '$transferNumber'\n";
        $stmt = $db->prepare("SELECT id, data FROM stock_transfers WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.transferNumber')) = ?");
        $stmt->execute([$transferNumber]);
        $result = $stmt->fetch();
        echo "  Result: " . ($result ? "✓ FOUND" : "✗ NOT FOUND") . "\n";
        if ($result) {
            echo "  Found ID: " . $result['id'] . "\n";
        }
    }
}

echo "\n";

// STEP 6: Check for ID mismatches
echo "STEP 6: Check for ID Mismatches\n";
echo "-------------------------------------------------\n";

$stmt = $db->query("SELECT id, data FROM stock_transfers");
$allTransfers = $stmt->fetchAll();
$mismatches = 0;

foreach ($allTransfers as $row) {
    $dbId = $row['id'];
    $data = json_decode($row['data'], true);
    $dataId = $data['id'] ?? null;
    
    if ($dataId && $dbId !== $dataId) {
        echo "⚠ MISMATCH:\n";
        echo "  Database ID: $dbId\n";
        echo "  Data ID: $dataId\n";
        echo "  Transfer Number: " . ($data['transferNumber'] ?? 'N/A') . "\n";
        $mismatches++;
    }
}

if ($mismatches === 0) {
    echo "✓ No ID mismatches found\n";
} else {
    echo "\n✗ Found $mismatches mismatch(es)\n";
}

echo "\n=================================================\n";
echo "              DEBUG COMPLETE\n";
echo "=================================================\n\n";

echo "RECOMMENDATIONS:\n";
echo "1. Always use the database 'id' column as the primary identifier\n";
echo "2. Ensure data.id matches the database id column\n";
echo "3. Use consistent parameter names: 'id' or 'transferId'\n";
echo "4. Update JavaScript and PHP to use the same identifier\n";
echo "5. Fix any ID mismatches found above\n\n";
