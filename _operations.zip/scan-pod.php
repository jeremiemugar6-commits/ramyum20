<?php
require_once __DIR__ . '/includes/auth.php';
$currentUser = require_login_page();

$token = $_GET['token'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scan Proof of Delivery - RAM-YUM</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        .pod-container {
            max-width: 600px;
            margin: 40px auto;
            padding: 30px;
            background: var(--bg-card);
            border-radius: 12px;
            box-shadow: var(--shadow-md);
        }
        .pod-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .pod-header h1 {
            color: var(--primary-red);
            margin-bottom: 8px;
        }
        .transfer-details {
            background: var(--bg-gray);
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid var(--border-color);
        }
        .detail-row:last-child {
            border-bottom: none;
        }
        .detail-label {
            font-weight: 600;
            color: var(--text-secondary);
        }
        .detail-value {
            color: var(--text-primary);
            font-weight: 500;
        }
        .product-list {
            margin: 20px 0;
        }
        .product-item {
            padding: 12px;
            background: white;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            margin-bottom: 8px;
        }
        .btn-confirm {
            width: 100%;
            padding: 14px;
            background: var(--primary-red);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            margin-top: 20px;
        }
        .btn-confirm:hover {
            background: var(--primary-orange);
        }
        .btn-confirm:disabled {
            background: #ccc;
            cursor: not-allowed;
        }
        .loading {
            text-align: center;
            padding: 40px;
            color: var(--text-secondary);
        }
        .error {
            background: #FEE2E2;
            color: #991B1B;
            padding: 16px;
            border-radius: 8px;
            margin: 20px 0;
        }
        .success {
            background: #D1FAE5;
            color: #065F46;
            padding: 16px;
            border-radius: 8px;
            margin: 20px 0;
            text-align: center;
        }
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            font-family: inherit;
            resize: vertical;
        }
    </style>
</head>
<body>
    <div class="pod-container">
        <div class="pod-header">
            <h1>📦 Proof of Delivery</h1>
            <p>Scan and confirm stock transfer receipt</p>
        </div>

        <div id="podContent">
            <div class="loading">
                <div class="loading-spinner"></div>
                <p>Loading transfer details...</p>
            </div>
        </div>
    </div>

    <script type="module">
        import { toast } from './assets/js/components/toast.js';

        const token = '<?php echo htmlspecialchars($token, ENT_QUOTES); ?>';
        const container = document.getElementById('podContent');

        async function loadTransferDetails() {
            try {
                const response = await fetch(`api/proof-of-delivery.php?action=scan&token=${encodeURIComponent(token)}`);
                const result = await response.json();

                if (!result.success) {
                    throw new Error(result.error || 'Failed to load transfer details');
                }

                const { pod, transfer } = result.data;
                
                if (pod.status === 'Received') {
                    showCompletedPOD(pod, transfer);
                } else {
                    showPODForm(pod, transfer);
                }

            } catch (error) {
                container.innerHTML = `
                    <div class="error">
                        <strong>Error:</strong> ${error.message}
                    </div>
                `;
            }
        }

        function showPODForm(pod, transfer) {
            // Format products list
            const productsHTML = transfer.items.map(item => `
                <div class="product-item">
                    <div style="font-weight:600;">${item.productName}</div>
                    <div style="color:var(--text-secondary); font-size:0.9rem;">
                        Quantity: <strong>${item.quantity}</strong> ${item.unit || 'pcs'}
                    </div>
                </div>
            `).join('');

            container.innerHTML = `
                <div class="transfer-details">
                    <div class="detail-row">
                        <span class="detail-label">Transfer Number:</span>
                        <span class="detail-value">${transfer.transferNumber || 'N/A'}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">From:</span>
                        <span class="detail-value">${transfer.sourceLocationName || transfer.sourceName || transfer.sourceLocationId}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">To:</span>
                        <span class="detail-value">${transfer.destinationLocationName || transfer.destinationName || transfer.destinationLocationId}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Status:</span>
                        <span class="detail-value">${transfer.status || 'Unknown'}</span>
                    </div>
                </div>

                <div class="product-list">
                    <h3 style="margin-bottom:12px;">Products to Receive:</h3>
                    ${productsHTML}
                    <div style="margin-top:12px; padding:12px; background:#FEF3C7; border-radius:6px; font-size:0.9rem;">
                        <strong>Total Items:</strong> ${transfer.items.reduce((sum, item) => sum + item.quantity, 0)}
                    </div>
                </div>

                <div style="margin-top:20px;">
                    <label style="display:block; font-weight:600; margin-bottom:8px;">
                        Confirmation Notes (Optional):
                    </label>
                    <textarea id="confirmationNotes" rows="3" placeholder="Add any notes about the delivery condition, discrepancies, etc..."></textarea>
                </div>

                <button id="confirmBtn" class="btn-confirm">
                    ✓ Confirm Receipt
                </button>
            `;

            document.getElementById('confirmBtn').addEventListener('click', confirmDelivery);
        }

        function showCompletedPOD(pod, transfer) {
            const productsHTML = transfer.items.map(item => `
                <div class="product-item">
                    <div style="font-weight:600;">${item.productName}</div>
                    <div style="color:var(--text-secondary); font-size:0.9rem;">
                        Quantity: <strong>${item.quantity}</strong> ${item.unit || 'units'}
                    </div>
                </div>
            `).join('');

            container.innerHTML = `
                <div class="success">
                    <h2 style="margin-bottom:8px;">✓ Delivery Confirmed</h2>
                    <p>This transfer was received on ${new Date(pod.received_at).toLocaleString()}</p>
                    <p>Received by: <strong>${pod.received_by}</strong></p>
                </div>

                <div class="transfer-details">
                    <div class="detail-row">
                        <span class="detail-label">Transfer Number:</span>
                        <span class="detail-value">${transfer.transferNumber || 'N/A'}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">From:</span>
                        <span class="detail-value">${transfer.sourceLocationName || transfer.sourceName || 'N/A'}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">To:</span>
                        <span class="detail-value">${transfer.destinationLocationName || transfer.destinationName || 'N/A'}</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Status:</span>
                        <span class="detail-value">Completed</span>
                    </div>
                </div>

                <div class="product-list">
                    <h3 style="margin-bottom:12px;">Products:</h3>
                    ${productsHTML}
                </div>

                ${pod.confirmation_notes ? `
                    <div style="margin-top:16px; padding:16px; background:var(--bg-gray); border-radius:8px;">
                        <strong>Confirmation Notes:</strong><br>
                        ${pod.confirmation_notes}
                    </div>
                ` : ''}

                <div style="margin-top:20px; text-align:center;">
                    <a href="dashboard.php" style="display:inline-block; padding:12px 24px; background:var(--primary-red); color:white; text-decoration:none; border-radius:8px; font-weight:600;">
                        Return to Dashboard
                    </a>
                </div>
            `;
        }

        async function confirmDelivery() {
            const btn = document.getElementById('confirmBtn');
            const notes = document.getElementById('confirmationNotes').value;

            btn.disabled = true;
            btn.textContent = 'Confirming...';

            try {
                const response = await fetch('api/proof-of-delivery.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'confirm',
                        token: token,
                        notes: notes
                    })
                });

                const result = await response.json();

                if (!result.success) {
                    throw new Error(result.error || 'Failed to confirm delivery');
                }

                toast.show('Delivery confirmed successfully!', 'success');
                
                // Reload to show completed state
                setTimeout(() => {
                    window.location.reload();
                }, 1500);

            } catch (error) {
                toast.show(error.message, 'error');
                btn.disabled = false;
                btn.textContent = '✓ Confirm Receipt';
            }
        }

        // Load transfer details on page load
        loadTransferDetails();
    </script>
</body>
</html>
