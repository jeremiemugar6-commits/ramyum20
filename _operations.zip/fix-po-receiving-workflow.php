<?php
/**
 * FIX PO→RECEIVING WORKFLOW LINKS
 * Establish bi-directional connections between POs and Receivings
 */

require_once 'config/database.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "FIX PO→RECEIVING WORKFLOW LINKS\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

try {
    $db->beginTransaction();
    
    // 1. Get all receiving records with PO links
    echo "Step 1: Analyzing Receiving Records\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $stmt = $db->query("SELECT id, data FROM receivings WHERE JSON_EXTRACT(data, '$.poId') IS NOT NULL");
    $receivings = $stmt->fetchAll();
    
    echo "Found " . count($receivings) . " receiving records with PO references\n\n";
    
    // 2. For each receiving, update the corresponding PO
    $fixed = 0;
    $alreadyLinked = 0;
    $poNotFound = 0;
    
    echo "Step 2: Establishing Links\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    foreach ($receivings as $receiving) {
        $receivingData = json_decode($receiving['data'], true);
        $receivingId = $receiving['id'];
        $poId = $receivingData['poId'] ?? null;
        
        if (!$poId) continue;
        
        echo "\nReceiving ID: {$receivingId}\n";
        echo "  References PO: {$poId}\n";
        
        // Get the PO
        $poStmt = $db->prepare("SELECT id, data FROM purchase_orders WHERE id = ?");
        $poStmt->execute([$poId]);
        $po = $poStmt->fetch();
        
        if (!$po) {
            echo "  ✗ PO not found\n";
            $poNotFound++;
            continue;
        }
        
        $poData = json_decode($po['data'], true);
        
        // Check if already linked
        if (isset($poData['receivingId']) && $poData['receivingId'] === $receivingId) {
            echo "  ✓ Already linked\n";
            $alreadyLinked++;
            continue;
        }
        
        // Add receiving link to PO
        $poData['receivingId'] = $receivingId;
        $poData['receivedDate'] = $receivingData['receivedDate'] ?? date('Y-m-d\TH:i:s.v\Z');
        
        // Update status if needed
        if ($poData['status'] === 'Approved' || $poData['status'] === 'Pending') {
            $poData['status'] = 'Fully Received';
            echo "  → Updated status to: Fully Received\n";
        }
        
        // Add received quantities to items if they exist in receiving
        if (isset($receivingData['items']) && isset($poData['items'])) {
            foreach ($receivingData['items'] as $recItem) {
                $productId = $recItem['productId'] ?? null;
                if (!$productId) continue;
                
                // Find matching PO item
                foreach ($poData['items'] as &$poItem) {
                    if (($poItem['productId'] ?? null) === $productId) {
                        $poItem['receivedQuantity'] = floatval($recItem['quantityDelivered'] ?? $recItem['receivedQty'] ?? 0);
                        $poItem['remainingQuantity'] = max(0, floatval($poItem['quantity'] ?? 0) - $poItem['receivedQuantity']);
                    }
                }
                unset($poItem);
            }
        }
        
        $poData['lastUpdated'] = date('Y-m-d\TH:i:s.v\Z');
        
        // Update PO
        $updateStmt = $db->prepare("UPDATE purchase_orders SET data = ?, updated_at = NOW() WHERE id = ?");
        $updateStmt->execute([json_encode($poData), $poId]);
        
        echo "  ✓ Linked to PO {$poData['poNumber']}\n";
        echo "  → Added receiving link\n";
        $fixed++;
    }
    
    echo "\n";
    echo "Step 3: Verification\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    // Verify links
    $posWithReceiving = $db->query("
        SELECT COUNT(*) FROM purchase_orders
        WHERE JSON_EXTRACT(data, '$.receivingId') IS NOT NULL
    ")->fetchColumn();
    
    $receivingsWithPO = $db->query("
        SELECT COUNT(*) FROM receivings
        WHERE JSON_EXTRACT(data, '$.poId') IS NOT NULL
    ")->fetchColumn();
    
    echo "POs with receiving link: {$posWithReceiving}\n";
    echo "Receivings with PO link: {$receivingsWithPO}\n";
    
    $db->commit();
    
    echo "\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    echo "WORKFLOW FIX SUMMARY\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    
    echo "✓ Links established: {$fixed}\n";
    echo "ℹ Already linked: {$alreadyLinked}\n";
    if ($poNotFound > 0) {
        echo "⚠ PO not found: {$poNotFound}\n";
    }
    
    echo "\n";
    
    // Show sample linked PO
    echo "Sample Linked PO:\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $sampleStmt = $db->query("
        SELECT data FROM purchase_orders 
        WHERE JSON_EXTRACT(data, '$.receivingId') IS NOT NULL 
        LIMIT 1
    ");
    $sample = $sampleStmt->fetch();
    
    if ($sample) {
        $sampleData = json_decode($sample['data'], true);
        echo "PO Number: " . ($sampleData['poNumber'] ?? 'N/A') . "\n";
        echo "Status: " . ($sampleData['status'] ?? 'N/A') . "\n";
        echo "Receiving ID: " . ($sampleData['receivingId'] ?? 'N/A') . "\n";
        echo "Received Date: " . ($sampleData['receivedDate'] ?? 'N/A') . "\n";
        
        if (isset($sampleData['items']) && count($sampleData['items']) > 0) {
            echo "\nSample Item:\n";
            $item = $sampleData['items'][0];
            echo "  Product: " . ($item['productName'] ?? 'N/A') . "\n";
            echo "  Ordered: " . ($item['quantity'] ?? 0) . "\n";
            echo "  Received: " . ($item['receivedQuantity'] ?? 0) . "\n";
            echo "  Remaining: " . ($item['remainingQuantity'] ?? 0) . "\n";
        }
    }
    
    echo "\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    echo "FIX COMPLETE - Workflow links established\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    
} catch (Exception $e) {
    $db->rollBack();
    echo "\n✗ ERROR: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
    exit(1);
}
