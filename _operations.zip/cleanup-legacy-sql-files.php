<?php
/**
 * Legacy SQL Files Cleanup Script
 * Marks old SQL files as deprecated and provides new setup instructions
 */

ini_set('display_errors', 1);
ini_set('error_reporting', E_ALL);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Legacy SQL Cleanup - RAMYUM</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }
        .success { background: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .warning { background: #fff3cd; color: #856404; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .info { background: #d1ecf1; color: #0c5460; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .btn { background: #FF7A00; color: white; padding: 12px 24px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        .btn:hover { background: #e06600; }
        .btn-danger { background: #dc3545; }
        .btn-danger:hover { background: #c82333; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 4px; overflow-x: auto; }
    </style>
</head>
<body>
    <h1>🧹 Legacy SQL Files Cleanup</h1>

    <div class="info">
        <strong>Purpose:</strong> This script identifies legacy SQL files that reference the old database name 
        and provides guidance on using the new centralized database setup.
    </div>

    <?php
    $databaseDir = __DIR__ . '/database';
    $legacyFiles = [];
    $currentFiles = [];

    // Scan database directory
    if (is_dir($databaseDir)) {
        $files = scandir($databaseDir);
        foreach ($files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'sql') {
                $filePath = $databaseDir . '/' . $file;
                $content = file_get_contents($filePath);
                
                if (strpos($content, 'USE ramyum_db') !== false || strpos($content, 'ramyum_db') !== false) {
                    $legacyFiles[] = [
                        'name' => $file,
                        'path' => $filePath,
                        'size' => filesize($filePath),
                        'modified' => filemtime($filePath)
                    ];
                } else {
                    $currentFiles[] = [
                        'name' => $file,
                        'path' => $filePath,
                        'size' => filesize($filePath),
                        'modified' => filemtime($filePath)
                    ];
                }
            }
        }
    }

    echo "<h2>📊 SQL Files Analysis</h2>";
    echo "<div class='warning'>Found " . count($legacyFiles) . " legacy files and " . count($currentFiles) . " current files</div>";

    if (!empty($legacyFiles)) {
        echo "<h3>🔴 Legacy SQL Files (Reference old database)</h3>";
        echo "<table>";
        echo "<tr><th>File Name</th><th>Size</th><th>Last Modified</th><th>Action Needed</th></tr>";
        
        foreach ($legacyFiles as $file) {
            $status = "⚠️ Update references";
            if (strpos($file['name'], 'schema.sql') !== false) {
                $status = "🚫 Replaced by migrate-to-centralized.sql";
            } elseif (strpos($file['name'], 'COMPLETE') !== false || strpos($file['name'], 'SIMPLE') !== false) {
                $status = "🚫 Replaced by migration script";
            } elseif (strpos($file['name'], 'FIX') !== false) {
                $status = "✅ Issues fixed in new schema";
            }
            
            echo "<tr>";
            echo "<td>{$file['name']}</td>";
            echo "<td>" . number_format($file['size']) . " bytes</td>";
            echo "<td>" . date('Y-m-d H:i:s', $file['modified']) . "</td>";
            echo "<td>$status</td>";
            echo "</tr>";
        }
        echo "</table>";
    }

    if (!empty($currentFiles)) {
        echo "<h3>✅ Current SQL Files (Up to date)</h3>";
        echo "<table>";
        echo "<tr><th>File Name</th><th>Size</th><th>Last Modified</th><th>Status</th></tr>";
        
        foreach ($currentFiles as $file) {
            echo "<tr>";
            echo "<td>{$file['name']}</td>";
            echo "<td>" . number_format($file['size']) . " bytes</td>";
            echo "<td>" . date('Y-m-d H:i:s', $file['modified']) . "</td>";
            echo "<td>✅ Compatible with centralized database</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    ?>

    <h2>📋 New Database Setup Process</h2>
    <div class="success">
        <strong>For New Installations:</strong>
        <ol>
            <li>Use the migration script: <code>/migrate-to-centralized-db.php</code></li>
            <li>Or run: <code>mysql -u root -p &lt; database/migrate-to-centralized.sql</code></li>
        </ol>
        
        <strong>For Existing Installations:</strong>
        <ol>
            <li>Create backup: <code>mysqldump -u root -p ramyum_db > backup.sql</code></li>
            <li>Run migration tool: <code>/migrate-to-centralized-db.php</code></li>
            <li>Test functionality</li>
            <li>Clean up old files (optional)</li>
        </ol>
    </div>

    <h2>🔄 Recommended Actions</h2>
    
    <div class="info">
        <h3>Files to Keep:</h3>
        <ul>
            <li><strong>migrate-to-centralized.sql</strong> - Main setup script</li>
            <li><strong>add-products.sql</strong> - Additional products data</li>
            <li>Any custom data files you've created</li>
        </ul>
        
        <h3>Files to Archive/Remove:</h3>
        <ul>
            <li><strong>schema.sql</strong> - Replaced by migration script</li>
            <li><strong>COMPLETE-STOCK-TRANSFER-DATABASE.sql</strong> - Replaced</li>
            <li><strong>SIMPLE-STOCK-TRANSFER-DATABASE.sql</strong> - Replaced</li>
            <li><strong>FIX-DATABASE.sql</strong> - Issues fixed in new schema</li>
            <li><strong>1-schema.sql through 6-verify.sql</strong> - Multi-step setup replaced</li>
        </ul>
    </div>

    <?php if (!empty($legacyFiles)): ?>
    <form method="post">
        <h2>🗂️ Archive Legacy Files</h2>
        <div class="warning">
            <strong>Warning:</strong> This will move legacy SQL files to a backup folder. 
            Make sure you have tested the new setup first!
        </div>
        
        <input type="hidden" name="action" value="archive">
        <label>
            <input type="checkbox" name="confirm" required> 
            I have successfully tested the new centralized database setup
        </label><br><br>
        <button type="submit" class="btn btn-danger">📦 Archive Legacy SQL Files</button>
    </form>
    <?php endif; ?>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'archive' && isset($_POST['confirm'])) {
        $archiveDir = $databaseDir . '/legacy-archived-' . date('Ymd-His');
        
        if (!file_exists($archiveDir)) {
            mkdir($archiveDir, 0755, true);
        }
        
        $archivedCount = 0;
        foreach ($legacyFiles as $file) {
            $sourcePath = $file['path'];
            $targetPath = $archiveDir . '/' . $file['name'];
            
            if (rename($sourcePath, $targetPath)) {
                $archivedCount++;
            }
        }
        
        echo "<div class='success'>✅ Successfully archived $archivedCount legacy SQL files to: <code>" . basename($archiveDir) . "</code></div>";
        echo "<div class='info'>You can now use only the centralized migration script for database setup.</div>";
    }
    ?>

    <h2>📖 Database Configuration Reference</h2>
    <div class="info">
        <h3>Current Configuration (config/database.php):</h3>
        <pre>define('DB_NAME', 'ram_yum_inventory');</pre>
        
        <h3>Migration Status:</h3>
        <?php
        // Check if configuration is updated
        require_once __DIR__ . '/config/database.php';
        if (DB_NAME === 'ram_yum_inventory') {
            echo "<div class='success'>✅ Database configuration updated to centralized database</div>";
        } else {
            echo "<div class='error'>❌ Database configuration still references old database: " . DB_NAME . "</div>";
        }
        
        // Check if migration function exists
        if (function_exists('get_database_connection')) {
            echo "<div class='success'>✅ Backward compatibility function available</div>";
        } else {
            echo "<div class='error'>❌ Backward compatibility function missing</div>";
        }
        ?>
        
        <h3>Next Steps:</h3>
        <ol>
            <li>✅ Database configuration updated</li>
            <li>✅ Migration scripts created</li>
            <li>⏳ Test all application functionality</li>
            <li>⏳ Verify stock transfer operations</li>
            <li>⏳ Check user authentication</li>
            <li>⏳ Clean up legacy files (optional)</li>
        </ol>
    </div>

</body>
</html>