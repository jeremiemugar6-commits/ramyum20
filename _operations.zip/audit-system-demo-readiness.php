<?php
/**
 * Comprehensive System Demo Readiness Audit
 * Checks all modules and workflows for standalone functionality
 */

require_once 'config/database.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "RAM-YUM SYSTEM DEMO READINESS AUDIT\n";
echo "Standalone Product & Inventory Operations System\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

$report = [
    'modules_checked' => 0,
    'modules_working' => 0,
    'modules_broken' => 0,
    'issues' => []
];

// ============================================================
// 1. DATABASE TABLES CHECK
// ============================================================
echo "1. DATABASE TABLES\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$requiredTables = [
    'suppliers' => 'Supplier Master',
    'products' => 'Product Catalog',
    'categories' => 'Product Categories',
    'purchase_orders' => 'Purchase Orders',
    'receivings' => 'Receiving Records',
    'proof_of_receiving' => 'Proof of Receiving',
    'proof_of_receiving_items' => 'POR Items',
    'inventory_locations' => 'Inventory by Location',
    'inventory_movements' => 'Inventory Movements',
    'stock_transfers' => 'Stock Transfers',
    'locations' => 'Warehouse Locations',
    'users' => 'User Management'
];

$tablesExist = [];
foreach ($requiredTables as $table => $description) {
    $stmt = $db->query("SHOW TABLES LIKE '$table'");
    $exists = $stmt->fetch() !== false;
    $tablesExist[$table] = $exists;
    
    if ($exists) {
        $countStmt = $db->query("SELECT COUNT(*) as cnt FROM `$table`");
        $count = $countStmt->fetch()['cnt'];
        echo "✓ $table ($description): $count records\n";
    } else {
        echo "✗ $table ($description): MISSING\n";
        $report['issues'][] = "Table missing: $table";
    }
}

echo "\n";

// ============================================================
// 2. SUPPLIER DATA CHECK
// ============================================================
echo "2. SUPPLIER DATA\n";
echo "───────────────────────────────────────────────────────────────────────\n";

if ($tablesExist['suppliers']) {
    $stmt = $db->query("SELECT COUNT(*) as cnt FROM suppliers");
    $supplierCount = $stmt->fetch()['cnt'];
    
    echo "Total Suppliers: $supplierCount\n";
    
    if ($supplierCount >= 3) {
        echo "✓ Sufficient suppliers for demo\n";
    } else {
        echo "⚠ Need at least 3 suppliers for demo\n";
        $report['issues'][] = "Insufficient suppliers (need 3, have $supplierCount)";
    }
    
    // Check supplier data quality
    $stmt = $db->query("SELECT id, data FROM suppliers LIMIT 3");
    while ($row = $stmt->fetch()) {
        $data = json_decode($row['data'], true);
        $name = $data['company'] ?? $data['name'] ?? 'UNNAMED';
        echo "  - {$row['id']}: $name\n";
    }
}

echo "\n";

// ============================================================
// 3. PRODUCT CATALOG CHECK
// ============================================================
echo "3. PRODUCT CATALOG\n";
echo "───────────────────────────────────────────────────────────────────────\n";

if ($tablesExist['products']) {
    $stmt = $db->query("SELECT COUNT(*) as cnt FROM products");
    $productCount = $stmt->fetch()['cnt'];
    
    echo "Total Products: $productCount\n";
    
    if ($productCount >= 10) {
        echo "✓ Sufficient products for demo\n";
    } else {
        echo "⚠ Need at least 10 products for demo\n";
        $report['issues'][] = "Insufficient products (need 10, have $productCount)";
    }
    
    // Check product categories
    $stmt = $db->query("
        SELECT JSON_UNQUOTE(JSON_EXTRACT(data, '$.category')) as cat, COUNT(*) as cnt
        FROM products
        GROUP BY cat
    ");
    echo "Product Categories:\n";
    while ($row = $stmt->fetch()) {
        echo "  - {$row['cat']}: {$row['cnt']} products\n";
    }
}

echo "\n";

// ============================================================
// 4. PURCHASE ORDER WORKFLOW CHECK
// ============================================================
echo "4. PURCHASE ORDER WORKFLOW\n";
echo "───────────────────────────────────────────────────────────────────────\n";

if ($tablesExist['purchase_orders']) {
    $stmt = $db->query("SELECT COUNT(*) as cnt FROM purchase_orders");
    $poCount = $stmt->fetch()['cnt'];
    echo "Total POs: $poCount\n";
    
    // Check PO statuses
    $stmt = $db->query("
        SELECT JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) as status, COUNT(*) as cnt
        FROM purchase_orders
        GROUP BY status
    ");
    echo "PO Status Distribution:\n";
    while ($row = $stmt->fetch()) {
        echo "  - {$row['status']}: {$row['cnt']}\n";
    }
    
    // Check if POs have supplier references
    $stmt = $db->query("
        SELECT COUNT(*) as cnt
        FROM purchase_orders
        WHERE JSON_EXTRACT(data, '$.supplierId') IS NULL
    ");
    $missingSupplier = $stmt->fetch()['cnt'];
    
    if ($missingSupplier > 0) {
        echo "✗ $missingSupplier POs missing supplier reference\n";
        $report['issues'][] = "$missingSupplier POs without supplier";
    } else {
        echo "✓ All POs have supplier references\n";
    }
}

echo "\n";

// ============================================================
// 5. RECEIVING WORKFLOW CHECK
// ============================================================
echo "5. RECEIVING WORKFLOW\n";
echo "───────────────────────────────────────────────────────────────────────\n";

if ($tablesExist['receivings']) {
    $stmt = $db->query("SELECT COUNT(*) as cnt FROM receivings");
    $receivingCount = $stmt->fetch()['cnt'];
    echo "Total Receiving Records: $receivingCount\n";
    
    // Check receiving statuses
    $stmt = $db->query("
        SELECT JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) as status, COUNT(*) as cnt
        FROM receivings
        GROUP BY status
    ");
    echo "Receiving Status Distribution:\n";
    while ($row = $stmt->fetch()) {
        echo "  - {$row['status']}: {$row['cnt']}\n";
    }
    
    // Check if receivings have PO references
    $stmt = $db->query("
        SELECT COUNT(*) as cnt
        FROM receivings
        WHERE JSON_EXTRACT(data, '$.poId') IS NULL
    ");
    $missingPO = $stmt->fetch()['cnt'];
    
    if ($missingPO > 0) {
        echo "✗ $missingPO receivings missing PO reference\n";
        $report['issues'][] = "$missingPO receivings without PO reference";
    } else {
        echo "✓ All receivings have PO references\n";
    }
}

echo "\n";

// ============================================================
// 6. PROOF OF RECEIVING CHECK
// ============================================================
echo "6. PROOF OF RECEIVING (POR)\n";
echo "───────────────────────────────────────────────────────────────────────\n";

if ($tablesExist['proof_of_receiving']) {
    $stmt = $db->query("SELECT COUNT(*) as cnt FROM proof_of_receiving");
    $porCount = $stmt->fetch()['cnt'];
    echo "Total POR Records: $porCount\n";
    
    // Check POR statuses
    $stmt = $db->query("
        SELECT status, COUNT(*) as cnt
        FROM proof_of_receiving
        GROUP BY status
    ");
    echo "POR Status Distribution:\n";
    while ($row = $stmt->fetch()) {
        echo "  - {$row['status']}: {$row['cnt']}\n";
    }
    
    // Check POR-PO supplier consistency
    $stmt = $db->query("
        SELECT COUNT(*) as cnt
        FROM v_por_supplier_validation
        WHERE validation_status = 'VALID'
    ");
    $validPORs = $stmt->fetch()['cnt'];
    
    echo "✓ POR-PO Supplier Consistency: $validPORs/$porCount valid\n";
    
    if ($validPORs < $porCount) {
        $report['issues'][] = ($porCount - $validPORs) . " PORs have supplier mismatches";
    }
}

echo "\n";

// ============================================================
// 7. INVENTORY CHECK
// ============================================================
echo "7. INVENTORY MANAGEMENT\n";
echo "───────────────────────────────────────────────────────────────────────\n";

if ($tablesExist['inventory_locations']) {
    $stmt = $db->query("SELECT COUNT(*) as cnt FROM inventory_locations");
    $invCount = $stmt->fetch()['cnt'];
    echo "Total Inventory Records: $invCount\n";
    
    // Check inventory movements
    if ($tablesExist['inventory_movements']) {
        $stmt = $db->query("SELECT COUNT(*) as cnt FROM inventory_movements");
        $movCount = $stmt->fetch()['cnt'];
        echo "Total Inventory Movements: $movCount\n";
        
        // Check movement types
        $stmt = $db->query("
            SELECT JSON_UNQUOTE(JSON_EXTRACT(data, '$.movementType')) as type, COUNT(*) as cnt
            FROM inventory_movements
            GROUP BY type
        ");
        echo "Movement Types:\n";
        while ($row = $stmt->fetch()) {
            echo "  - {$row['type']}: {$row['cnt']}\n";
        }
    }
}

echo "\n";

// ============================================================
// 8. STOCK TRANSFER CHECK
// ============================================================
echo "8. STOCK TRANSFER WORKFLOW\n";
echo "───────────────────────────────────────────────────────────────────────\n";

if ($tablesExist['stock_transfers']) {
    $stmt = $db->query("SELECT COUNT(*) as cnt FROM stock_transfers");
    $transferCount = $stmt->fetch()['cnt'];
    echo "Total Stock Transfers: $transferCount\n";
    
    // Check transfer statuses
    $stmt = $db->query("
        SELECT JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) as status, COUNT(*) as cnt
        FROM stock_transfers
        GROUP BY status
    ");
    echo "Transfer Status Distribution:\n";
    while ($row = $stmt->fetch()) {
        echo "  - {$row['status']}: {$row['cnt']}\n";
    }
}

echo "\n";

// ============================================================
// 9. LOCATION/WAREHOUSE CHECK
// ============================================================
echo "9. WAREHOUSE LOCATIONS\n";
echo "───────────────────────────────────────────────────────────────────────\n";

if ($tablesExist['locations']) {
    $stmt = $db->query("SELECT COUNT(*) as cnt FROM locations");
    $locationCount = $stmt->fetch()['cnt'];
    echo "Total Locations: $locationCount\n";
    
    if ($locationCount >= 2) {
        echo "✓ Sufficient locations for stock transfer demo\n";
    } else {
        echo "⚠ Need at least 2 locations for stock transfer demo\n";
        $report['issues'][] = "Insufficient locations (need 2, have $locationCount)";
    }
    
    $stmt = $db->query("SELECT id, data FROM locations LIMIT 5");
    echo "Sample Locations:\n";
    while ($row = $stmt->fetch()) {
        $data = json_decode($row['data'], true);
        $name = $data['name'] ?? 'UNNAMED';
        echo "  - {$row['id']}: $name\n";
    }
}

echo "\n";

// ============================================================
// 10. API ENDPOINTS CHECK
// ============================================================
echo "10. API ENDPOINTS\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$apiFiles = [
    'api/data.php' => 'Generic CRUD',
    'api/users.php' => 'User Management',
    'api/login.php' => 'Authentication',
    'api/stock-transfers.php' => 'Stock Transfers',
    'api/proof-of-receiving.php' => 'Proof of Receiving',
    'api/reports.php' => 'Reporting'
];

foreach ($apiFiles as $file => $desc) {
    if (file_exists($file)) {
        echo "✓ $file ($desc)\n";
    } else {
        echo "✗ $file ($desc): MISSING\n";
        $report['issues'][] = "API file missing: $file";
    }
}

echo "\n";

// ============================================================
// 11. FRONTEND PAGES CHECK
// ============================================================
echo "11. FRONTEND PAGES\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$pages = [
    'index.php' => 'Login',
    'dashboard.php' => 'Dashboard',
    // Add more as we verify them
];

foreach ($pages as $file => $desc) {
    if (file_exists($file)) {
        echo "✓ $file ($desc)\n";
    } else {
        echo "✗ $file ($desc): MISSING\n";
        $report['issues'][] = "Page missing: $file";
    }
}

echo "\n";

// ============================================================
// 12. DATA CONSISTENCY VALIDATION
// ============================================================
echo "12. DATA CONSISTENCY VALIDATION\n";
echo "───────────────────────────────────────────────────────────────────────\n";

// Check PO → Receiving relationship
if ($tablesExist['purchase_orders'] && $tablesExist['receivings']) {
    $stmt = $db->query("
        SELECT COUNT(*) as cnt
        FROM receivings r
        LEFT JOIN purchase_orders po ON JSON_UNQUOTE(JSON_EXTRACT(r.data, '$.poId')) = po.id
        WHERE po.id IS NULL
    ");
    $orphanedReceivings = $stmt->fetch()['cnt'];
    
    if ($orphanedReceivings > 0) {
        echo "✗ $orphanedReceivings receivings reference non-existent POs\n";
        $report['issues'][] = "$orphanedReceivings orphaned receivings";
    } else {
        echo "✓ All receivings reference valid POs\n";
    }
}

// Check POR → PO relationship
if ($tablesExist['proof_of_receiving'] && $tablesExist['purchase_orders']) {
    $stmt = $db->query("
        SELECT COUNT(*) as cnt
        FROM proof_of_receiving por
        LEFT JOIN purchase_orders po ON por.purchase_order_id = po.id
        WHERE po.id IS NULL
    ");
    $orphanedPORs = $stmt->fetch()['cnt'];
    
    if ($orphanedPORs > 0) {
        echo "✗ $orphanedPORs PORs reference non-existent POs\n";
        $report['issues'][] = "$orphanedPORs orphaned PORs";
    } else {
        echo "✓ All PORs reference valid POs\n";
    }
}

echo "\n";

// ============================================================
// SUMMARY
// ============================================================
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "AUDIT SUMMARY\n";
echo "═══════════════════════════════════════════════════════════════════════\n";

echo "Total Issues Found: " . count($report['issues']) . "\n\n";

if (count($report['issues']) > 0) {
    echo "ISSUES TO RESOLVE:\n";
    foreach ($report['issues'] as $i => $issue) {
        echo ($i + 1) . ". $issue\n";
    }
    echo "\n⚠ SYSTEM NOT DEMO-READY\n";
} else {
    echo "✓✓✓ NO CRITICAL ISSUES FOUND ✓✓✓\n";
    echo "System appears to be demo-ready\n";
}

echo "═══════════════════════════════════════════════════════════════════════\n";
?>
