<?php
/**
 * POD Workflow Migration Script
 * Safely migrates database to support QR + Camera + POD workflow
 */

require_once __DIR__ . '/config/database.php';

// Only allow execution from command line or admin access
if (php_sapi_name() !== 'cli') {
    require_once __DIR__ . '/includes/auth.php';
    $currentUser = require_login_page();
    if ($currentUser['role'] !== 'admin') {
        die('Access denied. Admin privileges required.');
    }
}

echo "=================================================\n";
echo "POD WORKFLOW DATABASE MIGRATION\n";
echo "=================================================\n\n";

try {
    $db = getDB();
    
    echo "Connected to database successfully.\n\n";
    
    // Read migration SQL
    $migrationFile = __DIR__ . '/database/pod-workflow-migration.sql';
    if (!file_exists($migrationFile)) {
        throw new Exception("Migration file not found: $migrationFile");
    }
    
    $sql = file_get_contents($migrationFile);
    
    // Remove comments
    $sql = preg_replace('/^--.*$/m', '', $sql);
    
    // Split SQL into individual statements (handle multi-line CREATE TABLE)
    $statements = [];
    $currentStatement = '';
    $lines = explode("\n", $sql);
    
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;
        
        $currentStatement .= ' ' . $line;
        
        // Check if statement is complete
        if (substr(rtrim($line), -1) === ';') {
            $currentStatement = trim($currentStatement);
            if (!empty($currentStatement) && !preg_match('/^(--|SELECT.*information_schema)/i', $currentStatement)) {
                $statements[] = rtrim($currentStatement, ';');
            }
            $currentStatement = '';
        }
    }
    
    echo "Found " . count($statements) . " SQL statements to execute.\n\n";
    
    $executed = 0;
    foreach ($statements as $statement) {
        try {
            $db->exec($statement);
            $executed++;
            
            // Extract table name for display
            if (preg_match('/CREATE TABLE.*?`([^`]+)`/i', $statement, $matches)) {
                echo "✓ Created/verified table: {$matches[1]}\n";
            } elseif (preg_match('/CREATE INDEX.*?`([^`]+)`/i', $statement, $matches)) {
                echo "✓ Created index: {$matches[1]}\n";
            }
        } catch (PDOException $e) {
            // Ignore "table already exists" and "duplicate key" errors
            if (strpos($e->getMessage(), 'already exists') === false && 
                strpos($e->getMessage(), 'Duplicate key') === false) {
                echo "Warning: " . $e->getMessage() . "\n";
            }
        }
    }
    
    echo "\n=================================================\n";
    echo "MIGRATION COMPLETED SUCCESSFULLY\n";
    echo "=================================================\n";
    echo "Executed: $executed statements\n\n";
    
    // Verify tables exist
    echo "Verifying tables...\n";
    $tables = ['proof_of_delivery', 'pod_items', 'pod_photos', 'damage_evidence'];
    foreach ($tables as $table) {
        $stmt = $db->query("SHOW TABLES LIKE '$table'");
        if ($stmt->fetch()) {
            echo "✓ Table '$table' exists\n";
        } else {
            echo "✗ Table '$table' NOT FOUND\n";
        }
    }
    
    echo "\n=================================================\n";
    echo "MIGRATION LOG\n";
    echo "=================================================\n";
    echo "Date: " . date('Y-m-d H:i:s') . "\n";
    echo "Database: " . $db->query("SELECT DATABASE()")->fetchColumn() . "\n";
    echo "Status: SUCCESS\n";
    echo "=================================================\n";
    
} catch (Exception $e) {
    echo "\n=================================================\n";
    echo "MIGRATION FAILED\n";
    echo "=================================================\n";
    echo "Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . "\n";
    echo "Line: " . $e->getLine() . "\n";
    echo "=================================================\n";
    
    exit(1);
}
?>
