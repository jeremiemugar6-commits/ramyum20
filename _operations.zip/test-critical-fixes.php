<?php
/**
 * Test Script for Critical Fixes
 * RAM-YUM Operations System
 * Tests the 3 critical audit findings that were fixed
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

header('Content-Type: text/html; charset=utf-8');

$db = getDB();
$results = [];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Critical Fixes Test - RAM-YUM</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #f8fafc; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; }
        h1 { color: #1e293b; margin-bottom: 10px; }
        .subtitle { color: #64748b; margin-bottom: 30px; }
        .test-section { background: white; border-radius: 12px; padding: 24px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .test-section h2 { color: #0f172a; margin-bottom: 16px; font-size: 1.25rem; }
        .test-case { padding: 16px; background: #f8fafc; border-left: 4px solid #3b82f6; border-radius: 8px; margin-bottom: 12px; }
        .test-case h3 { color: #334155; font-size: 1rem; margin-bottom: 8px; }
        .test-result { padding: 12px; border-radius: 6px; margin-top: 8px; }
        .pass { background: #d1fae5; color: #065f46; border-left: 4px solid #10b981; }
        .fail { background: #fee2e2; color: #991b1b; border-left: 4px solid #ef4444; }
        .info { background: #dbeafe; color: #1e40af; border-left: 4px solid #3b82f6; }
        .warning { background: #fef3c7; color: #92400e; border-left: 4px solid #f59e0b; }
        pre { background: #1e293b; color: #e2e8f0; padding: 12px; border-radius: 6px; overflow-x: auto; font-size: 0.875rem; margin-top: 8px; }
        .badge { display: inline-block; padding: 4px 12px; border-radius: 12px; font-size: 0.75rem; font-weight: 600; margin-left: 8px; }
        .badge-critical { background: #fee2e2; color: #991b1b; }
        .badge-fixed { background: #d1fae5; color: #065f46; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
        .stat-card { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .stat-value { font-size: 2rem; font-weight: 700; color: #1e293b; }
        .stat-label { color: #64748b; font-size: 0.875rem; margin-top: 4px; }
        code { background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-size: 0.875rem; color: #dc2626; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔧 Critical Fixes Test Suite</h1>
        <p class="subtitle">Automated testing for QA audit critical findings</p>

        <div class="stats">
            <div class="stat-card" style="border-left: 4px solid #3b82f6;">
                <div class="stat-label">Tests Run</div>
                <div class="stat-value" id="totalTests">0</div>
            </div>
            <div class="stat-card" style="border-left: 4px solid #10b981;">
                <div class="stat-label">Passed</div>
                <div class="stat-value" id="passedTests">0</div>
            </div>
            <div class="stat-card" style="border-left: 4px solid #ef4444;">
                <div class="stat-label">Failed</div>
                <div class="stat-value" id="failedTests">0</div>
            </div>
        </div>

        <?php
        $totalTests = 0;
        $passedTests = 0;
        $failedTests = 0;

        // ==========================================
        // FIX #1: SKU UNIQUENESS CONSTRAINT
        // ==========================================
        echo '<div class="test-section">';
        echo '<h2>🔴 FIX #1: SKU Uniqueness Constraint <span class="badge badge-critical">CRITICAL</span></h2>';
        
        // Test 1.1: Check if constraint exists
        echo '<div class="test-case">';
        echo '<h3>Test 1.1: Verify unique_sku constraint exists in database</h3>';
        $totalTests++;
        
        try {
            $stmt = $db->query("
                SELECT CONSTRAINT_NAME, CONSTRAINT_TYPE 
                FROM information_schema.table_constraints
                WHERE table_schema = DATABASE()
                AND table_name = 'products'
                AND constraint_name = 'unique_sku'
            ");
            $constraint = $stmt->fetch();
            
            if ($constraint) {
                echo '<div class="test-result pass">';
                echo '✅ <strong>PASS:</strong> SKU uniqueness constraint exists<br>';
                echo 'Constraint Name: <code>' . $constraint['CONSTRAINT_NAME'] . '</code><br>';
                echo 'Type: <code>' . $constraint['CONSTRAINT_TYPE'] . '</code>';
                echo '</div>';
                $passedTests++;
            } else {
                echo '<div class="test-result fail">';
                echo '❌ <strong>FAIL:</strong> SKU uniqueness constraint not found<br>';
                echo '<em>Run the migration: database/critical-fixes-migration.sql</em>';
                echo '</div>';
                $failedTests++;
            }
        } catch (Exception $e) {
            echo '<div class="test-result fail">';
            echo '❌ <strong>ERROR:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
            $failedTests++;
        }
        echo '</div>';

        // Test 1.2: Check for duplicate SKUs
        echo '<div class="test-case">';
        echo '<h3>Test 1.2: Check for existing duplicate SKUs in database</h3>';
        $totalTests++;
        
        try {
            $stmt = $db->query("
                SELECT 
                    JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku')) as sku,
                    COUNT(*) as count,
                    GROUP_CONCAT(id) as product_ids
                FROM products
                WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku')) IS NOT NULL
                GROUP BY JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku'))
                HAVING COUNT(*) > 1
            ");
            $duplicates = $stmt->fetchAll();
            
            if (empty($duplicates)) {
                echo '<div class="test-result pass">';
                echo '✅ <strong>PASS:</strong> No duplicate SKUs found in database';
                echo '</div>';
                $passedTests++;
            } else {
                echo '<div class="test-result fail">';
                echo '❌ <strong>FAIL:</strong> Found ' . count($duplicates) . ' duplicate SKU(s)<br><br>';
                foreach ($duplicates as $dup) {
                    echo 'SKU: <code>' . htmlspecialchars($dup['sku']) . '</code> - ';
                    echo 'Count: ' . $dup['count'] . ' - ';
                    echo 'IDs: <code>' . htmlspecialchars($dup['product_ids']) . '</code><br>';
                }
                echo '<br><em>Fix: Manually resolve duplicate SKUs before applying constraint</em>';
                echo '</div>';
                $failedTests++;
            }
        } catch (Exception $e) {
            echo '<div class="test-result fail">';
            echo '❌ <strong>ERROR:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
            $failedTests++;
        }
        echo '</div>';

        // Test 1.3: Attempt to insert duplicate SKU
        echo '<div class="test-case">';
        echo '<h3>Test 1.3: Attempt to insert duplicate SKU (should fail)</h3>';
        $totalTests++;
        
        try {
            // Get an existing SKU
            $stmt = $db->query("SELECT JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku')) as sku FROM products LIMIT 1");
            $existingSKU = $stmt->fetch()['sku'] ?? 'TEST-001';
            
            // Try to insert duplicate
            $testData = json_encode([
                'id' => 'test_sku_duplicate',
                'name' => 'Test Product',
                'sku' => $existingSKU,
                'category' => 'Test',
                'price' => 100,
                'stock' => 10
            ]);
            
            $insertStmt = $db->prepare("INSERT INTO products (id, data) VALUES (?, ?)");
            $insertStmt->execute(['test_sku_duplicate', $testData]);
            
            // If we got here, constraint didn't work
            $db->exec("DELETE FROM products WHERE id = 'test_sku_duplicate'");
            echo '<div class="test-result fail">';
            echo '❌ <strong>FAIL:</strong> Duplicate SKU was allowed to be inserted<br>';
            echo 'Attempted SKU: <code>' . htmlspecialchars($existingSKU) . '</code><br>';
            echo '<em>The uniqueness constraint is not working properly</em>';
            echo '</div>';
            $failedTests++;
            
        } catch (PDOException $e) {
            // Exception is expected - constraint is working
            if (strpos($e->getMessage(), 'unique_sku') !== false || strpos($e->getMessage(), 'Duplicate entry') !== false) {
                echo '<div class="test-result pass">';
                echo '✅ <strong>PASS:</strong> Duplicate SKU insertion correctly blocked by constraint<br>';
                echo 'Attempted SKU: <code>' . htmlspecialchars($existingSKU) . '</code><br>';
                echo 'Database correctly rejected the duplicate';
                echo '</div>';
                $passedTests++;
            } else {
                echo '<div class="test-result fail">';
                echo '❌ <strong>ERROR:</strong> Unexpected database error<br>';
                echo '<pre>' . htmlspecialchars($e->getMessage()) . '</pre>';
                echo '</div>';
                $failedTests++;
            }
        }
        echo '</div>';

        echo '</div>'; // End Fix #1 section

        // ==========================================
        // FIX #2: NEGATIVE STOCK PREVENTION
        // ==========================================
        echo '<div class="test-section">';
        echo '<h2>🔴 FIX #2: Negative Stock Prevention <span class="badge badge-critical">CRITICAL</span></h2>';
        
        // Test 2.1: Check for database constraints
        echo '<div class="test-case">';
        echo '<h3>Test 2.1: Verify negative stock constraints in inventory_locations</h3>';
        $totalTests++;
        
        try {
            $stmt = $db->query("
                SELECT CONSTRAINT_NAME 
                FROM information_schema.table_constraints
                WHERE table_schema = DATABASE()
                AND table_name = 'inventory_locations'
                AND constraint_name IN ('chk_positive_quantity', 'chk_positive_available_quantity')
            ");
            $constraints = $stmt->fetchAll();
            
            if (count($constraints) >= 2) {
                echo '<div class="test-result pass">';
                echo '✅ <strong>PASS:</strong> Negative stock constraints exist<br>';
                foreach ($constraints as $c) {
                    echo '  - <code>' . $c['CONSTRAINT_NAME'] . '</code><br>';
                }
                echo '</div>';
                $passedTests++;
            } else {
                echo '<div class="test-result fail">';
                echo '❌ <strong>FAIL:</strong> Missing negative stock constraints<br>';
                echo 'Found ' . count($constraints) . ' constraint(s), expected 2<br>';
                echo '<em>Run the migration: database/critical-fixes-migration.sql</em>';
                echo '</div>';
                $failedTests++;
            }
        } catch (Exception $e) {
            echo '<div class="test-result fail">';
            echo '❌ <strong>ERROR:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
            $failedTests++;
        }
        echo '</div>';

        // Test 2.2: Check server-side validation in API
        echo '<div class="test-case">';
        echo '<h3>Test 2.2: Verify server-side stock validation in api/data.php</h3>';
        $totalTests++;
        
        try {
            $apiContent = file_get_contents(__DIR__ . '/api/data.php');
            $hasNegativeCheck = strpos($apiContent, 'stock < 0') !== false || 
                               strpos($apiContent, 'cannot be negative') !== false;
            
            if ($hasNegativeCheck) {
                echo '<div class="test-result pass">';
                echo '✅ <strong>PASS:</strong> Server-side negative stock validation found in api/data.php';
                echo '</div>';
                $passedTests++;
            } else {
                echo '<div class="test-result fail">';
                echo '❌ <strong>FAIL:</strong> No server-side negative stock validation in api/data.php<br>';
                echo '<em>Server-side validation is missing</em>';
                echo '</div>';
                $failedTests++;
            }
        } catch (Exception $e) {
            echo '<div class="test-result fail">';
            echo '❌ <strong>ERROR:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
            $failedTests++;
        }
        echo '</div>';

        // Test 2.3: Test negative stock in stock transfer
        echo '<div class="test-case">';
        echo '<h3>Test 2.3: Verify insufficient stock prevention in stock transfers</h3>';
        $totalTests++;
        
        try {
            $apiContent = file_get_contents(__DIR__ . '/api/stock-transfers.php');
            $hasInsufficientCheck = strpos($apiContent, 'Insufficient stock') !== false;
            
            if ($hasInsufficientCheck) {
                echo '<div class="test-result pass">';
                echo '✅ <strong>PASS:</strong> Insufficient stock validation found in stock-transfers.php';
                echo '</div>';
                $passedTests++;
            } else {
                echo '<div class="test-result fail">';
                echo '❌ <strong>FAIL:</strong> No insufficient stock validation in stock-transfers.php';
                echo '</div>';
                $failedTests++;
            }
        } catch (Exception $e) {
            echo '<div class="test-result fail">';
            echo '❌ <strong>ERROR:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
            $failedTests++;
        }
        echo '</div>';

        echo '</div>'; // End Fix #2 section

        // ==========================================
        // FIX #3: POD SCOPE DOCUMENTATION
        // ==========================================
        echo '<div class="test-section">';
        echo '<h2>🔴 FIX #3: POD Scope Clarification <span class="badge badge-fixed">DOCUMENTED</span></h2>';
        
        // Test 3.1: Check documentation file
        echo '<div class="test-case">';
        echo '<h3>Test 3.1: Verify POD scope clarification document exists</h3>';
        $totalTests++;
        
        if (file_exists(__DIR__ . '/POD_SCOPE_CLARIFICATION.md')) {
            $docSize = filesize(__DIR__ . '/POD_SCOPE_CLARIFICATION.md');
            echo '<div class="test-result pass">';
            echo '✅ <strong>PASS:</strong> POD scope documentation exists<br>';
            echo 'File: <code>POD_SCOPE_CLARIFICATION.md</code><br>';
            echo 'Size: ' . number_format($docSize) . ' bytes';
            echo '</div>';
            $passedTests++;
        } else {
            echo '<div class="test-result fail">';
            echo '❌ <strong>FAIL:</strong> POD scope documentation not found';
            echo '</div>';
            $failedTests++;
        }
        echo '</div>';

        // Test 3.2: Verify Stock Transfer POD implementation
        echo '<div class="test-case">';
        echo '<h3>Test 3.2: Verify POD implementation in Stock Transfers</h3>';
        $totalTests++;
        
        try {
            $podApiExists = file_exists(__DIR__ . '/api/proof-of-delivery.php');
            $scanPageExists = file_exists(__DIR__ . '/scan-pod.php');
            $qrViewExists = file_exists(__DIR__ . '/view-transfer-qr.php');
            
            $allExist = $podApiExists && $scanPageExists && $qrViewExists;
            
            if ($allExist) {
                echo '<div class="test-result pass">';
                echo '✅ <strong>PASS:</strong> All POD components exist for Stock Transfers<br>';
                echo '  - POD API: <code>api/proof-of-delivery.php</code><br>';
                echo '  - Scan Page: <code>scan-pod.php</code><br>';
                echo '  - QR View: <code>view-transfer-qr.php</code>';
                echo '</div>';
                $passedTests++;
            } else {
                echo '<div class="test-result fail">';
                echo '❌ <strong>FAIL:</strong> Missing POD components<br>';
                echo '  - POD API: ' . ($podApiExists ? '✅' : '❌') . '<br>';
                echo '  - Scan Page: ' . ($scanPageExists ? '✅' : '❌') . '<br>';
                echo '  - QR View: ' . ($qrViewExists ? '✅' : '❌');
                echo '</div>';
                $failedTests++;
            }
        } catch (Exception $e) {
            echo '<div class="test-result fail">';
            echo '❌ <strong>ERROR:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
            $failedTests++;
        }
        echo '</div>';

        // Test 3.3: Confirm NO POD in PO receiving
        echo '<div class="test-case">';
        echo '<h3>Test 3.3: Confirm POD is NOT in Purchase Order receiving (expected)</h3>';
        $totalTests++;
        
        try {
            $receivingContent = file_get_contents(__DIR__ . '/modules/receiving/receiving.js');
            $hasQRCode = strpos($receivingContent, 'qr') !== false || 
                        strpos($receivingContent, 'scan') !== false ||
                        strpos($receivingContent, 'pod') !== false;
            
            if (!$hasQRCode) {
                echo '<div class="test-result pass">';
                echo '✅ <strong>PASS:</strong> PO receiving correctly does NOT use QR/POD scanning<br>';
                echo 'This is the expected behavior - POD is only for Stock Transfers';
                echo '</div>';
                $passedTests++;
            } else {
                echo '<div class="test-result warning">';
                echo '⚠️ <strong>WARNING:</strong> Found QR/POD references in receiving.js<br>';
                echo 'This may indicate unexpected POD implementation in PO receiving';
                echo '</div>';
                $passedTests++; // Not a failure, just informational
            }
        } catch (Exception $e) {
            echo '<div class="test-result fail">';
            echo '❌ <strong>ERROR:</strong> ' . htmlspecialchars($e->getMessage());
            echo '</div>';
            $failedTests++;
        }
        echo '</div>';

        echo '</div>'; // End Fix #3 section

        ?>

        <!-- Summary -->
        <div class="test-section">
            <h2>📊 Test Summary</h2>
            <?php
            $passRate = $totalTests > 0 ? round(($passedTests / $totalTests) * 100, 1) : 0;
            $statusClass = $passRate >= 90 ? 'pass' : ($passRate >= 70 ? 'warning' : 'fail');
            ?>
            <div class="test-result <?php echo $statusClass; ?>">
                <strong>Overall Result:</strong> <?php echo $passedTests; ?> / <?php echo $totalTests; ?> tests passed (<?php echo $passRate; ?>%)
                <br><br>
                <?php if ($failedTests === 0): ?>
                    ✅ All critical fixes have been successfully applied and verified!
                <?php elseif ($failedTests <= 2): ?>
                    ⚠️ Most fixes applied successfully. <?php echo $failedTests; ?> issue(s) need attention.
                <?php else: ?>
                    ❌ Multiple issues detected. Run database migration and review failed tests above.
                <?php endif; ?>
            </div>

            <div style="margin-top: 20px;">
                <h3 style="margin-bottom: 12px;">Next Steps:</h3>
                <?php if ($failedTests > 0): ?>
                <ol style="margin-left: 20px; color: #334155;">
                    <li>Run the database migration: <code>database/critical-fixes-migration.sql</code></li>
                    <li>Review failed test cases above for specific issues</li>
                    <li>Re-run this test script to verify fixes</li>
                    <li>Test manually in the application UI</li>
                </ol>
                <?php else: ?>
                <ol style="margin-left: 20px; color: #334155;">
                    <li>✅ All automated tests passed</li>
                    <li>Perform manual testing in application UI</li>
                    <li>Try creating product with duplicate SKU (should fail)</li>
                    <li>Try creating stock transfer with insufficient stock (should fail)</li>
                    <li>Review POD_SCOPE_CLARIFICATION.md for panel defense</li>
                </ol>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <script>
        document.getElementById('totalTests').textContent = <?php echo $totalTests; ?>;
        document.getElementById('passedTests').textContent = <?php echo $passedTests; ?>;
        document.getElementById('failedTests').textContent = <?php echo $failedTests; ?>;
    </script>
</body>
</html>
